
#include <cstdio>
#include <vector>
#include <valarray>
#include <iostream>
#include <fstream>
#include <string>
#include "bGrid.h"
using namespace std;

/*******************************************

   1) Read in protein
      -- recenter: origin in center of protein?
      -- find max (min) for each axis

      _width_i = _length_i + (2*f)/r + (2*t)r

   2) Create exlusion matrix

      _width_em = 1 + (2*f)/r


*******************************************/

int main(int argc,char **argv) {

   valarray<float> prt;
   bGrid g;

   // Proof of double capabilities
   //~ for(int i=0; i<300; i += 10) {

      //~ unsigned int a = pow(2,i);
      //~ unsigned b = pow(2,i);
      //~ unsigned long c = pow(2,i);
      //~ cout << i << ": " << endl;
      //~ cout << "\t" << a << endl;
      //~ cout << "\t" << b << endl;
      //~ cout << "\t" << c << endl;
   //~ }

   g.readProtein(argv[1]);
   //g.printProtein();
   g.translateProtein();
   //g.printProtein();
   g.initializeGrid();
	g.initializeExclusion();
	g.initializeInclusion();
//~ cout << 4 << endl;
	//~ g.print3dExcl(cout);
	//~ g.print3dIncl(cout);
//~ cout << 4 << endl;
	g.excludePoints();
	g.includePoints();
	g.printPyMol();

   return 0;
}

