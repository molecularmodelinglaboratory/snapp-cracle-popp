
//~ #include <cstdio>
//~ #include <vector>
//~ #include <claVararray>
//~ #include <iostream>
//~ #include <fstream>
//~ #include <string>

#include <stdio.h>
//~ #include <string.h>
//~ #include <sys/stat.h>

#include "bDocker.h"
//~ #include "bSimplex.h"
//~ #include "bAA.h"
//~ #include "bSys.h"
#include "bSort.h"
//~ #include "bCentroid.h"

using namespace std;
using namespace bStd;


/*******************************************

   1) Read in protein
      -- recenter: origin in center of protein?
      -- find max (min) for each axis

      _width_i = _length_i + (2*f)/r + (2*t)r

   2) Create exlusion matrix

      _width_em = 1 + (2*f)/r


*******************************************/

int main( int argc, char **argv ) {

   //~ int listarr[2] = {4,1};
   //~ int* list = listarr;
   //~ for( int i=0; i < 2; ++i ) { printf("%2d ", list[i]); } printf("\n");
   //~ bSort::qsort( list, 2 );
   //~ for( int i=0; i < 2; ++i ) { printf("%2d ", list[i]); } printf("\n");
   //~ return 1;
   /* PPI Docker */
   try{ 
      bDocker d;
      d.cla(argc,argv);
      d.doItAll();
      printf("\n\tdone.\n\n");
   }
   catch( const char* e ) { printf("%s\n",e); }

   return 0;
}
