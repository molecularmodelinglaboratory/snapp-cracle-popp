#ifndef BDELTESS_H
#define BDELTESS_H

#include <deque>
//~ #include <map>
#include <stdio.h>
#include "bPoints.h"
#include "bSimplex.h"
#include "bHex.h"
#include "MersenneTwister.h"

namespace bStd { class bDelTess; };

class bStd::bDelTess {
   typedef std::deque<short> des;
   typedef std::deque<int> dei;
   typedef std::deque<bHex> deh;
   typedef std::deque<bSimplex> deX;
   typedef bHex::uint uint;
   typedef bHex::ulong ulong;
   //~ typedef std::map<char[4], char> mc3c;
   //~ typedef std::pair<char[4], char> pc3c;
   friend class bCentroid;

   private:

      // Self
      deh edges_;
      des vrtx_;
      deX simplex_;
      deh simplID_;
      dei simplTy_;

      // Sources
      bPoints* src_;
      float*   infPt_;
      des      toAdd_;
      int      numChain_;

      // Information (constantly changing)
      //~ static mc3c aa3to1_;
      float* currPt_;
      int    currPtId_;
      bHex   sick_;
      bHex   well_;
      deh    newID_;
      dei    newList_;
      dei    hullID_;
      dei    open_;

      // Flags
      bool haveType_;
      bool haveEdge_;
      bool isTrim_;
      bool isSlim_;
      bool isVerified_;

      // debugging
      int recur_;
      dei invalidS_;
      dei invalidP_;
      deX removed_;
      dei removedWhen_;

      // Extras
      MTRand rndNum_;
      FILE* debug_;
      static bool doDebug_;
      static int numInst_;

   protected:

   public:

      // Constructors
      bDelTess();
      bDelTess( const bDelTess& );
      ~bDelTess();
      bDelTess& operator=( const bDelTess& );
      void clear();
      void reset();

      bool tessellateFull( bPoints& );

      // Setup
      void link( bPoints & );
      void setSrc( bPoints& );
      void randomizePts();
      int  getRandomNumber( const int );
      void defineAA3to1();
   
      // Simplex Manipulation
      int addSimplex( const int [] );
      int addSimplex( bHex & );
      void delSimplex( const int );
   
      // Tessellation
      bool tessellate();
      void checkPoint( int );
      void checkSimplex( bSimplex& );
      void outbreak( bSimplex*, bSimplex* );
         void infectedHull( bSimplex* );
         void noInfection( bSimplex*, bSimplex* );
      void treat();
         void addNewSimplexes();
         void identifyNeighbors();
         void removeSimplexes();
      void immunize();
         void reconcile( dei&, bHex& );
      void resetHandlers();
      bool isNew( bSimplex* );
      
      // Finalization
      bool verify();
      void retry();
      void findEdges();
      void validateTet( dei & );
      void removeExcess();
      void trim( float =( (float)10.0 ) );
      bool skip( int );

      // Output
      void printTetByRes( FILE* );
      void printTetByPos( FILE* );
      void pymolDelTess( FILE*, char[], char[] =("ruby") );
      void pymolEdges( FILE*, char[], char[] );
      void status();
      void status( int );
   
      // Not Fully Tested
      void findType();
      int  findType( int );
};

#endif
