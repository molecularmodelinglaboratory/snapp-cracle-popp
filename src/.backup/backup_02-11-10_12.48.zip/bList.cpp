
#include <stdio.h>
#include <stdlib.h>

#include "bList.h"

using namespace std;
using namespace bStd;

int bList::_resizeAmt_ = 1.4;

/****** bCONF ******/

bConf::bConf()
   : sc_(0.0), next_( NULL ), prev_( NULL ), pare_(NULL), chld_(NULL)
{
   this->pp_ = NULL;
}

bConf::bConf( const bConf &rhs )
   : sc_(0.0), next_( NULL ), prev_( NULL ), pare_(NULL), chld_(NULL)
{
   this->pp_ = new bPoints( *(rhs.pp_) );
   this->sc_ = rhs.sc_;
   this->next_ = rhs.next_;
   this->prev_ = rhs.prev_;
   this->pare_ = rhs.pare_;
   this->chld_ = new bList( *(rhs.chld_) );
}

bConf::bConf( const bPoints &rhs )
   : sc_(0.0), next_( NULL ), prev_( NULL ), pare_(NULL), chld_(NULL)
{
   this->pp_ = new bPoints( rhs );
}

bConf::bConf( bPoints* rhs )
   : sc_(0.0), next_( NULL ), prev_( NULL ), pare_(NULL), chld_(NULL)
{
   this->pp_ = rhs;
}

bConf::~bConf() {
   this->sc_ = 0.0;
   this->pare_ = NULL;
   delete this->pp_; this->pp_ = NULL;
   delete this->chld_; this->chld_ = NULL;
}

void bConf::clear() {
   if( this->pp_ != NULL ) { delete this->pp_; this->pp_ = NULL; }
   this->sc_ = 0.0;
   this->next_ = NULL;
   this->prev_ = NULL;
   this->pare_ = NULL;
   if( this->chld_ != NULL ) { delete this->chld_; this->chld_ = NULL; }
   return;
}

/****** Assignment */
bConf& bConf::operator=( const bConf &rhs ) {
   if( this != &rhs ) {
      this->clear();
      this->pp_ = new bPoints( *(rhs.pp_) );
      this->sc_ = rhs.sc_;
      this->next_ = rhs.next_;
      this->prev_ = rhs.prev_;
      this->pare_ = rhs.pare_;
      this->chld_ = new bList( *(rhs.chld_) );
   }
   return *this;
}

/****** Conditional */
bool bConf::operator< ( const bConf &rhs ) { return rhs.sc_ <  this->sc_; }
bool bConf::operator> ( const bConf &rhs ) { return rhs.sc_ >  this->sc_; }
bool bConf::operator==( const bConf &rhs ) { return rhs.sc_ == this->sc_; }

/****** Get */
bConf* bConf::next() { return this->next_; }
bConf* bConf::prev() { return this->prev_; }
bConf* bConf::pare() { return this->pare_->pare_; }
bList* bConf::home() { return this->pare_; }
bList* bConf::chld() { return this->chld_; }
float bConf::score() { return this->sc_; }

/****** Set */
void bConf::next( bConf* n ) { this->next_ = n; return; }
void bConf::prev( bConf* n ) { this->prev_ = n; return; }
void bConf::pare( bList* l ) { this->pare_ = l; return; }
void bConf::chld( bList* l ) {
   if( this->chld_ != NULL ) {
      delete this->chld_;
      this->chld_ = NULL;
   }
   this->chld_ = new bList( *l );
   this->chld_->pare( this );
   return;
}
void bConf::chld( bConf* n ) {
   if( this->chld_ == NULL ) {
      this->chld_ = new bList( n );
      this->chld_->pare( this );
   }
   else { this->chld_->push_back( n ); }
   return;
}
void  bConf::score( float s ) { this->sc_ = s; return; }





/************************** bLIST ********************************************/
/************************** bLIST ********************************************/
/************************** bLIST ********************************************/
bList::bList( uint c )
   : cap_(c), num_(0), pare_(NULL), beg_(NULL), end_(NULL), list_(NULL)
{
   this->list_ = new bConf*[ this->cap_ ];
}

bList::bList( const bList &rhs, uint c )
   : cap_(c), num_(0), pare_(NULL), beg_(NULL), end_(NULL), list_(NULL)
{
   this->cap_ = rhs.num_ < rhs.cap_ ? rhs.cap_ : rhs.num_ * _resizeAmt_;
   this->num_ = rhs.num_;
   this->pare_ = rhs.pare_;

   this->list_ = new bConf*[ this->cap_ ];
   this->list_[0] = new bConf( *(rhs.list_[0]) );
   uint i=1, k=0;
   for( i=1; i < this->num_; ++i, ++k ) {
      this->list_[i] = new bConf( *(rhs.list_[i]) );
      this->list_[i]->prev_ = this->list_[k];
      this->list_[k]->next_ = this->list_[i];
      this->list_[i]->pare_ = this;
   }
   for( i=i; i < this->cap_; ++i ) {
      this->list_[i] = NULL;
   }

   this->list_[0]->prev_ = NULL;
   this->list_[0]->pare_ = this;
   this->list_[i]->next_ = NULL;
}

bList::bList( const bConf &rhs, uint c )
   : cap_(c), num_(1), pare_(NULL), beg_(NULL), end_(NULL), list_(NULL)
{
   this->list_ = new bConf*[ this->cap_ ];
   this->list_[0] = new bConf( rhs );
   this->list_[0]->pare( this );
   this->list_[0]->next( NULL );
   this->list_[0]->prev( NULL );
   this->beg_ = this->list_[0];
   this->end_ = this->list_[0];
}

bList::bList( bConf* rhs, uint c )
   : cap_(c), num_(1), pare_(NULL), beg_(rhs), end_(rhs), list_(NULL)
{
   this->list_ = new bConf*[ this->cap_ ];
   this->list_[0] = rhs;
   this->list_[0]->pare( this );
   this->list_[0]->next( NULL );
   this->list_[0]->prev( NULL );
}

bList::~bList() {
   bConf* curr = this->beg_;
   bConf* next = NULL;
   for( uint i=0; i < this->num_; ++i ) {
      next = curr->next();
      delete curr;
      curr = next;
   }
   delete [] this->list_;
   this->list_ = NULL;
   
   this->cap_ = 0;
   this->num_ = 0;
   this->pare_ = NULL;
   this->beg_ = NULL;
   this->end_ = NULL;
}


void bList::clear() {
   bConf* next;
   bConf* curr = this->beg_;
   while( curr != this->end_ ) {
      next = curr->next_;
      curr->clear();
      delete curr;
      curr = next;
   }
}

bConf& bList::operator[]( uint x ) {
   bConf* access = NULL;
   if( x < this->cap_ ) { access = this->list_[x]; }
   else {
      uint pos = this->cap_; --pos;
      access = this->list_[pos]->next();
      while( ++pos != x ) {
         access = access->next();
      }
   }
   return *access;
}


bool bList::empty() { return (this->num_ = 0) ? true : false; }

/*** GET */
bConf* bList::pare() { return this->pare_; }
bConf* bList::beg()  { return this->beg_; }
bConf* bList::end()  { return this->end_; }
uint   bList::cap()  { return this->cap_; }
uint   bList::num()  { return this->num_; }
uint   bList::size() { return this->num_; }
void bList::resize( uint rs ) {
   if( this->list_ != NULL ) { delete [] this->list_; this->list_ = NULL; }

   // Make sure it's big enough
   if( rs < this->num_ ) { rs = this->num_; rs *= _resizeAmt_; }
   this->list_ = new bConf*[rs];
   this->cap_ = rs;

   // Repopulate the list
   bConf* access = this->beg_;
   for( uint i=0; i < this->num_; ++i ) {
      this->list_[i] = access;
      access = access->next();
   }

   // Ensure null-ness
   for( uint i=this->num_; i < rs; ++i ) {
      this->list_[i] = NULL;
   }
   return;
}


/*** SET */
void bList::pare( bConf* n ) { this->pare_ = n; return; }
void bList::cap( uint n ) { this->resize( n ); return; }

/*** MODIFY */
void bList::push_back( bConf &n ) {
   bConf* c = new bConf( n );
   c->pare( this );

   // Resize if needed
   int tooBig = this->cap_; tooBig *= _resizeAmt_;
   if( this->num_ > this->cap_ ) { this->resize( tooBig ); }

   // Save in array if room
   if( this->num_ < this->cap_ ) {
      this->list_[ this->num_ ] = c;
   }

   // Maintain integrity
   bConf* access = this->end_;
   access->next( c );
   c->prev( access );
   this->end_ = c;

   return;
}

void bList::push_back( bConf* n ) {

   // Resize if needed
   int tooBig = this->cap_; tooBig *= _resizeAmt_;
   if( this->num_ > this->cap_ ) { this->resize( tooBig ); }

   // Save in array if room
   if( this->num_ < this->cap_ ) {
      this->list_[ this->num_ ] = n;
   }

   // Maintain integrity
   bConf* access = this->end_;
   access->next( n );
   n->prev( access );
   this->end_ = n;

   return;
}

void bList::del( uint pos ) {
   // Remove from pointers
   bConf* access = &((*this)[ pos ]);
   access->next()->prev( access->prev() );
   access->prev()->next( access->next() );

   // Check for extremeties
   if( pos == 0 ) { this->beg_ = access->next(); }
   else if ( pos == this->num_ - 1 ) { this->end_ = access->prev(); }
   else {}

   // Maintain the list
   bConf* toDel = access;
   while( pos < this->cap_ && pos < this->num_ ) {
      access = access->next();
      this->list_[pos] = access;
      ++pos;
   }

   // Delete element
   delete toDel;
   toDel = NULL;
   access = NULL;
   return;
}

void bList::insert( bConf &n ) {
   return;
}

/****** Sort */
void bList::sort( bool rev ) {
   if( this->num_ > this->cap_ ) { this->resize( this->num_ * _resizeAmt_ ); }
   rev ? this->_sortRev( 0, this->num_ - 1 ) : this->_sort( 0, this->num_ - 1);
   return;
}
void bList::_sortRev( int left, int right ) {
   if( left == right ) { return; } // return if we're done
   else if( (left + 1) == right ) { return; }
   else {}
   
   int pivot = (right + left) >> 1; // get the pivot (i.e. the middle point)
   float pivotVal = this->list_[pivot]->sc_; // save the value
   if( this->list_[left]->sc_ == pivotVal || this->list_[right]->sc_ == pivotVal ) { return; }

   swap( pivot, right ); // move the pivot element to the end  (temporarily)
   pivot = right;

   int store = left; // start at the left 
   for(int i = left; i < right; ++i) {
      if( this->list_[i]->sc_ >= pivotVal) {    // if less than pivot
         swap( i, store );  // swap points
         ++store;  // move the store pointer
      }
   }

   swap( pivot, store ); // put the pivot back in place
   _sortRev( left, store ); // recursively iterate through both sides
   _sortRev( store, right );

   return;
}

void bList::_sort( int left, int right ) {
   if( left == right ) { return; } // return if we're done
   else if( (left + 1) == right ) { return; }
   else {}
   
   int pivot = (right + left) >> 1; // get the pivot (i.e. the middle point)
   float pivotVal = this->list_[pivot]->sc_; // save the value
   if( this->list_[left]->sc_ == pivotVal || this->list_[right]->sc_ == pivotVal ) { return; }

   swap( pivot, right ); // move the pivot element to the end  (temporarily)
   pivot = right;

   int store = left; // start at the left 
   for(int i = left; i < right; ++i) {
      if( this->list_[i]->sc_ <= pivotVal) {    // if less than pivot
         swap( i, store );  // swap points
         ++store;  // move the store pointer
      }
   }

   swap( pivot, store ); // put the pivot back in place
   _sort( left, store ); // recursively iterate through both sides
   _sort( store, right );

   return;
}

void bList::swap( int a, int b ) {
   if( a == b ) { return; }
   else if( this->list_[a] == this->list_[b] ) { return; }
   else {
   }

   bConf* x = this->list_[a];
   bConf* y = this->list_[b];
   bPoints* t;
   float s;

   t = x->pp_;
   x->pp_ = y->pp_;
   y->pp_ = t;

   s = x->sc_;
   x->sc_ = y->sc_;
   y->sc_ = s;
   
   // Note: probably just move the score and the pep ptr -- most likely less operations
      
   return;
}
