#ifndef BCONF_H
#define BCONF_H

#include "bPoints.h"
#include "bDelTess.h"
#include "bHex.h"

namespace bStd { class bConf; };

class bStd::bConf {
   friend class bDocker;
   friend class bMC;

   private:
   //~ bHex* id_;
   bPoints* pp_;
   bPoints* nb_;
   //~ bDelTess* dt_;
   
   float sc_;
   //~ bMC* mc_;
   bConf* pare_;
   bConf** chld_;
   uint numChld_;
   static uint cnt_;

   public:
   bConf();
   bConf( const bConf& );
   ~bConf();


   bConf& operator=( const bConf& );
   bool   operator<( const bConf& );

};

#endif