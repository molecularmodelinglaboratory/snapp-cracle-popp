
#include <stdio.h>
#include <valarray>
#include "bSimplex.h"
#include "bHex.h"
using namespace std;
using namespace bStd;

/* Static Declarations */
short bSimplex::count_ = 0;
slice bSimplex::cSlc_[3] = { // coordinate slices [x,y,z]
   slice( 1, 4, 5 ),
   slice( 2, 4, 5 ),
   slice( 3, 4, 5 ) };

slice bSimplex::pSlc_[4]= {  // point slices [3x1]
   slice( 1, 3, 1 ),
   slice( 6, 3, 1 ),
   slice( 11, 3, 1 ),
   slice( 16, 3, 1 ) };

slice bSimplex::sSlc_[4] = { // simplex slices [5x1]
   slice( 0, 5, 1 ),
   slice( 5, 5, 1 ),
   slice( 10, 5, 1 ),
   slice( 15, 5, 1 ) };

/**/
/****** Constructors */
/* Default */
bSimplex::bSimplex() {
   for( int i=0; i < 5; ++i ) {
      this->vrtx_[i] = 0;
      this->det_[i] = 0;
   }
   for( int i=5; i < 20; ++i ) {
      this->vrtx_[i] = 0;
   }
   for( int i=0; i < 4; ++i ) { this->nghbr_[i] = NULL; }
}

/* Copy */
bSimplex::bSimplex( const bSimplex &rhs ) {

   this->id_ = rhs.id_;
   for( int i=0; i <  5; ++i ) { this->det_[i] = rhs.det_[i]; }
   for( int i=0; i < 20; ++i ) { this->vrtx_[i] = rhs.vrtx_[i]; }
   for( int i=0; i <  4; ++i ) { this->nghbr_[i] = rhs.nghbr_[i]; }
   
}

/* Destructor */
bSimplex::~bSimplex() {
   for( int i=0; i < 4; ++i ) { this->nghbr_[i] = NULL; }
   //~ --bSimplex::count_;
}

/**/
/****** Assignment Operators */
bSimplex& bSimplex::operator=( const bSimplex &rhs ) {
   if( this == &rhs ) { return *this; }

   this->id_ = rhs.id_;
   for( int i=0; i < 5; ++i ) {
      this->vrtx_[i] = rhs.vrtx_[i];
      this->det_[i] = rhs.det_[i];
   }
   for( int i=5; i < 20; ++i ) {
      this->vrtx_[i] = rhs.vrtx_[i];
   }
   for( int i=0; i < 4; ++i ) { 
      this->nghbr_[i] = NULL;
      this->nghbr_[i] = rhs.nghbr_[i];
   }
   
   return *this;
}

bSimplex& bSimplex::operator=( const vaf &rhs ) {
   
   // Save point coordinates
   int vrtIndx = 0;
   int rhsIndx = 0;
   for( int i=0; i < 4; ++i ) {
      vrtIndx = i * 5;
      this->vrtx_[vrtIndx] = 1.0;
      ++vrtIndx;
      for( int k=1; k < 4; ++k ) {
         this->vrtx_[vrtIndx] = rhs[rhsIndx];
         ++vrtIndx;
         ++rhsIndx;
      }
   }
   
   // Calculate p_q
   vaf dbl( rhs );
   dbl *= dbl;
   for( int i=0; i < 4; ++i ) {
      vrtx_[i*5+4] = vaf(dbl[ slice( i*3, 3, 1 ) ]).sum();
   }
   
   return *this;
}
bSimplex& bSimplex::operator=( const float* rhs ) {
   // Unrolled the loops -- not dynamic and called often enough.

   // Save point coordinates
   this->vrtx_[0]  = 1.0; this->vrtx_[1]  = rhs[0]; this->vrtx_[2]  = rhs[1];  this->vrtx_[3]  = rhs[2];
   this->vrtx_[5]  = 1.0; this->vrtx_[6]  = rhs[3]; this->vrtx_[7]  = rhs[4];  this->vrtx_[8]  = rhs[5];
   this->vrtx_[10] = 1.0; this->vrtx_[11] = rhs[6]; this->vrtx_[12] = rhs[7];  this->vrtx_[13] = rhs[8];
   this->vrtx_[15] = 1.0; this->vrtx_[16] = rhs[9]; this->vrtx_[17] = rhs[10]; this->vrtx_[18] = rhs[11];

   // Calculate p_q
   float a = 0.0;
   a = rhs[0]; a *= a; this->vrtx_[4] = a;
   a = rhs[1]; a *= a; this->vrtx_[4] += a;
   a = rhs[2]; a *= a; this->vrtx_[4] += a;
   
   a = rhs[3]; a *= a; this->vrtx_[9] = a;
   a = rhs[4]; a *= a; this->vrtx_[9] += a;
   a = rhs[5]; a *= a; this->vrtx_[9] += a;

   a = rhs[6]; a *= a; this->vrtx_[14] = a;
   a = rhs[7]; a *= a; this->vrtx_[14] += a;
   a = rhs[8]; a *= a; this->vrtx_[14] += a;

   a = rhs[9];  a *= a; this->vrtx_[19] = a;
   a = rhs[10]; a *= a; this->vrtx_[19] += a;
   a = rhs[11]; a *= a; this->vrtx_[19] += a;

   return *this;
}

/**/
/****** Conditional Operators */
/* Equal */
bool bSimplex::operator==( const bSimplex &rhs ) {   
   valarray<bool> eqTest(this->vrtx_ == rhs.vrtx_);
   bool isEqual = true;
   for( int i=0; i < 20 && isEqual; ++i ) {
      isEqual &= eqTest[i];
   }
   return isEqual;
}

/* Not Equal */
bool bSimplex::operator!=( const bSimplex &rhs ) {
   return !( *this == rhs );
}

/* In Sphere */
short bSimplex::inSphere( const vaf &testPt ) {
   vaf test( 1.0, 5 );
   
   if( testPt.size() == 3 ) { 
      test[slice( 1, 3, 1 )] = testPt;
      vaf tmp( testPt );
      tmp *= tmp;
      test[4] = tmp.sum();
   }
   else { test = testPt; }
   
   for( int i=0; i < 5; ++i ) {
      test[i] *= this->det_[i];
   }
   float sum = test.sum();
   
   if( sum < 0 ) { return -1; }
   else if( sum > 0 ) { return 1; }
   else {}
   return 0;
}

short bSimplex::inSphere( const float* testPt ) {
   //~ vaf test( 1.0, 5 );
   float test[5] = { 1.0, testPt[0], testPt[1], testPt[2], 0.0 };
   double r = testPt[0]; r *= r; test[4] += (float)r;
          r = testPt[1]; r *= r; test[4] += (float)r;
          r = testPt[2]; r *= r; test[4] += (float)r;

   r = 0.0;
   test[0] *= this->det_[0]; r += test[0];
   test[1] *= this->det_[1]; r += test[1];
   test[2] *= this->det_[2]; r += test[2];
   test[3] *= this->det_[3]; r += test[3];
   test[4] *= this->det_[4]; r += test[4];

   if( r < 0 ) { return -1; }
   else if( r > 0 ) { return 1; }
   else {}
   return 0;
}

/**/
/****** Setup */
/* Construct Simplex, Given Coordinates */
void bSimplex::setup( const float* pnts ) {
   *this = pnts;
   
   this->id_ = count_; // Setup ID
   ++count_;

   try{ this->orient(); } // make sure we have CCW (+) orientation
   catch( const char* e ) { throw e; }
   
   this->calcDet();

   return;
}

/* Re-Orient to Right-Handed Screw */
void bSimplex::orient() {
   // find minimum y coordinate
   float minx = this->vrtx_[1];
   float miny = this->vrtx_[2];
   float minz = this->vrtx_[3];
   
   //~ print(stdout);
   bool swap = false;
   int row = 0;
   for( int i=1; i < 4; ++i ) {
      int indx = i*5 + 2;
      
      if( miny > this->vrtx_[ indx ] ) {
         swap = true;
      }
      else if( miny == this->vrtx_[ indx ] ) {
         if( minx > this->vrtx_[ indx - 1 ] ) {
            swap = true;
         }
         else if( minx == this->vrtx_[ indx - 1] ) {
            if( minz > this->vrtx_[ indx + 1 ] ) {
               swap = true;
            }
            else if( minz == this->vrtx_[ indx + 1 ] ) {
               this->print();
               throw "[bSimplex] Same points in tetrahedral?\n";
            }
            else{}
         }
         else{}
      }
      else{}
      
      if( swap ) {
         miny = this->vrtx_[ indx ];
         minx = this->vrtx_[ indx - 1 ];
         minz = this->vrtx_[ indx + 1 ];
         row = i;
      }
   }
   
   // swap these rows
   this->swapRow( this->vrtx_, 0, row, 5 );
   ++row; // = 1
   
   vaf pts( this->vrtx_, 20 );
   vaf mat( 1.0, 16 );
   for( int i=0; i < 4; ++i ) {
      mat[ slice( i*4 + 1, 3, 1 ) ] = pts[ pSlc_[i] ];
   }
   vaf detV( 4 );
   //~ float det = detByGauss( mat, 4 );
   detByMinors( detV, mat, 4 );
   float det = detV.sum();
   if( det < 0 ) {
      swapRow( this->vrtx_, 1, 2, 5 );
   }
   else if( det < 0.0001 && det > 0.0 ) {
      this->print();
      throw "[bSimplex] Unknown...co-planar?\n";
   }
   else if( det > 0 ) {
      
   }
   else {}
   return;
   
   // ORIENT -- variables
   //~ int det[3];
   //~ int test = 0;
   //~ int indx = 0;
   //~ int colin = 0;
   //~ bool swap = false;
   //~ int numChange = 1;
   
   //~ // ORIENT
   //~ while( numChange > 0 ) {
      
      //~ numChange = 0;
      //~ for( int i=2; i < 4; ++i ) {
         //~ int axI = (i - 1) * 5 + 1;
         //~ int bxI = i * 5 + 1;
         //~ int axbx = this->vrtx_[bxI] - this->vrtx_[axI];
         //~ int ayby = this->vrtx_[bxI + 1] + this->vrtx_[axI + 1];
         
         //~ printf( "Simplex %d\n", this->id_ );
         //~ printf( "( %.2f - %.2f ) * ( %.2f + %.2f )\n", 
            //~ this->vrtx_[bxI],
            //~ this->vrtx_[axI],
            //~ this->vrtx_[bxI+1],
            //~ this->vrtx_[axI+1] );
         //~ printf( "( %d ) * ( %d )\n", axbx, ayby );
         
         //~ if( ayby == 0 ) { // special consideration for infty pts
            //~ printf(" %d => ",ayby);
            //~ ayby = 1;
            //~ printf("%d\n",ayby);
         //~ }
         //~ ayby *= axbx;
         //~ printf(" = %d\n", ayby );
         //~ if( ayby > 0 ) {
            //~ swapRow( this->vrtx_, i, i-1, 5 );
            //~ ++numChange;
         //~ }
      //~ }
   //~ }
   
   //~ // Check last point
   //~ vaf coord( this->vrtx_, 20 );
   //~ vaf facePt( 1.0, 16 );
   //~ size_t start = 0;
   //~ size_t length[] = { 4,4 };
   //~ size_t stride[] = { 5,1 };
   //~ valarray<size_t> len( length,2 ), str( stride,2 );
   //~ facePt = coord[ gslice( start, len, str ) ];
   //~ float det = detByGauss( facePt, 4 );
   //~ if( det < 0 ) {
      //~ swapRow( this->vrtx_, 2, 3, 5 );
   //~ }
   
   // ORIENT 
   //~ while( numChange > 0 && row < 4 ) {
      //~ colin = 0;
      //~ numChange = 0;
      //~ indx = row * 5 + 1;
      
      //~ // calculate minor determinants
      //~ det[0] = this->vrtx_[1] * this->vrtx_[row + 1]; // ax * by
      //~ det[0] -= this->vrtx_[row] * this->vrtx_[2]; // - bx * ay
      //~ det[1] = this->vrtx_[row + 1] - this->vrtx_[2]; // bx - ax
      //~ det[2] = this->vrtx_[row] - this->vrtx_[1]; // bx - ax
      
      //~ // loop through remaining points
      //~ for( int i=row+1; i < 4; i++ ) {
         
         //~ // calculate the full determinant
         //~ indx = i * 5 + 1;
         //~ test = 1 * det[0]; // ch * |AB|
         //~ test -= this->vrtx_[indx] * det[1]; // cx * |AB|
         //~ test += this->vrtx_[indx + 1] * det[2]; // cy * |AB|
      
         //~ if( test == 0 ) { // colinear
            //~ ++colin;
            //~ if( colin > 1 ) { return false; } // check for co-planarity
            //~ if( det[2] < 0 ) { swap = true; } // swap these two
         //~ }
         //~ else if( test < 0 ) { swap = true; } // CW
         //~ else {} // CCW
            
         //~ if( swap ) {
            //~ swapRow( this->vrtx_, row, i, 5 );
            //~ row = i;
            //~ ++numChange;
         //~ }
      //~ }
      
      //~ if( numChange < 0 ) { // no changes, progress
         //~ ++row;
      //~ }
      //~ else { // changes, recheck
         //~ row = 1;
      //~ }
   //~ }
   
   return;
}

/**/
/****** Calculation Methods */
/* Determinant */
void bSimplex::calcDet( bool byMinor ) {
   // map vertices onto 5x5 determinant matrix
   vaf prtMat( this->vrtx_, 20 );
   vaf detMat( 1.0, 25 ); // 5x5
   detMat[ slice( 0, 20, 1 ) ] = prtMat;

   // temp valarray for calculations
   vaf det( 5 );

   // calculate the determinant
   if( byMinor ) { // by minors
      this->detByMinors( det, detMat, 5 );
      for( int i=0; i < 5; ++i ) {
         this->det_[i] = det[i];
      }
   }
   else { // by Gauss
      // break down into four matrices
      // calculate det for each
   }
   
   return;
}

/* Determinant by Minors */
void bSimplex::detByMinors( vaf &det, vaf &mat, int dim ) {
   if( dim < 3 ) {
      det[0] = (mat[0] * mat[3]); // ad - bc
      det[1] = -(mat[1] * mat[2]);
      return;
   }

   // SETUP MINORS
   int minDim = dim - 1;
   vaf minMat( 0.0, minDim * minDim );
   vaf minDet( 0.0, minDim );
   valarray<bool> detMsk( false, dim );
   
   // CALCULATE MINORS -- RECURSIVE!!
   for( int i=0; i<dim; ++i ) {
      
      // initialize minor
      std::valarray<bool> minMsk( 1,mat.size() ); // declare mask
      minMsk[ slice(i,dim,dim) ] = 0; // set masked column
      minMsk[ slice( dim*minDim, dim, dim ) ]; // set masked row (always the last)
      minMat = mat[ minMsk ];
      
      // recursively calculate the minor
      detByMinors( minDet, minMat, minDim );
      det[i] = minDet.sum();
   }
   
   // ADJUST MINOR DETERMINANTS (i.e., mult by -1 if needed)
   int isOdd = dim & 1; // 1 if odd, 0 if even
   for( int i=isOdd; i < dim; i += 2 ) {
      det[i] *= -1.0;
   }
   det *= vaf( mat[ slice( dim*minDim, dim, 1 ) ]);
   
   return;
}

/* Determinant by Gaussian */
float bSimplex::detByGauss( vaf &matRef, int dim ) {
   float det = 1.0;
   int row = dim, col = dim;
   int i = 0, j = 0;
   vaf mat( matRef );
   vaf tmp1( 0.0, dim );
   vaf tmp2( 0.0, dim );
   
   while( i < row && j < col ) {
      int maxi = i;
      
      for( int k=i+1; k < row; ++k ) {
         if( abs(mat[ k*col+j ]) > abs(mat[ maxi*col+j ]) ) {
            maxi = k;
         }
      }
      
      if( mat[ maxi*col+j ] != 0 ) {
         if(i != maxi) { swapRow( mat, i, maxi, col ); }
         tmp1 = mat[ slice( i*col, col, 1 ) ];
         tmp1 /= mat[ i*col+j ];
         for( int l=i+1; l < row; ++l ) {
            tmp2 = tmp1;
            tmp2 *= mat[ l*col+j ];
            mat[ slice( l*col, col, 1 ) ] -= tmp2;
         }
         ++i;
      }
      ++j;
   }
   
   for( int k=0; k < dim; ++k ) {
      det *= mat[k*col + k];
   }
   
   return det;
}

/* Swap Row -- needed for detByGauss */
void bSimplex::swapRow( vaf &d, int a, int b, int s ) {
   if( a == b ) { return; }
   vaf temp( 0.0, s);
   a *= s;
   b *= s;
   temp = d[ slice(a,s,1) ];
   d[ slice(a,s,1) ] = d[ slice(b,s,1) ];
   d[ slice(b,s,1) ] = temp;
   return;
}


/* Swap Row -- array */
void bSimplex::swapRow( float mat[], int a, int b, int dim ) {
   if( a == b ) { return; }
   float temp = 0.0;
   int aI = a * dim, bI = b * dim;
   for( int i=0; i < dim; ++i ) {
      temp = mat[ aI ];
      mat[ aI ] = mat[ bI ];
      mat[ bI ] = temp;
      ++aI;
      ++bI;
   }
   return;
}

/**/
/****** Internals */

/**/
/****** Output */
/* Print */
void bSimplex::print( FILE* op ) {
   
   int index = 0;
   for( int i=0; i < 4; ++i ) {
      fprintf(op, "[");
      for( int k=0; k < 5; ++k ) {
         fprintf(op, "%#2.2f, ",this->vrtx_[index]);
         ++index;
      }
      fprintf(op, "]\n");
   }
   
   fprintf(op, "|");
   for( int i=0; i < 5; ++i ) {
      fprintf(op, "%#2.2f ", this->det_[i]);
   } fprintf(op, "|\n\n");
   
   return;
}

void bSimplex::printDet( vaf &det ) {
   printf("det: ");
   for( uint i=0; i < det.size(); ++i ) {
      printf("%.2f, ", det[i]);
   }
   printf(" = %.2f\n", det.sum() );
   return;
}

void bSimplex::pymolSimplex( FILE *op, char name[], char color[] ) {
   for( int i=1; i < 20; i += 3 ) {    // print each atom
      fprintf(op,"cmd.pseudoatom(\"%s%d\",pos=[", name, this->id_);
      fprintf(op,"%.2f,", this->vrtx_[i]); ++i;
      fprintf(op,"%.2f,", this->vrtx_[i]); ++i;
      fprintf(op,"%.2f]", this->vrtx_[i]);
      fprintf(op,",name=\"%d\")\n", ((i-3)/5) );
   }
      
   for( int i=0; i < 4; ++i ) {        // print each bond
      for( int k=i+1; k < 4; ++k ) { 
         fprintf(op,"cmd.bond(\"%s%d////%d\",\"%s%d////%d\")\n",
            name, this->id_, i,
            name, this->id_, k );
      }
   }

   fprintf(op,"cmd.color(\"%s\",\"%s%d\")\n",color, name, this->id_); // color the simplex
   return;
}

void bSimplex::printMatrix( vaf &mat, int dim ) {
   int index = 0;
   printf("[");
   for( int i=0; i < dim; ++i ) {
      //~ printf("{");
      for( int k=0; k < dim; ++k ) {
         printf("%.2f",mat[index]);
         if( k == dim - 1 && i == dim - 1 ) { printf("]\n"); }
         else if( k == dim - 1 ) { printf("; "); }
         else { printf(" "); }
         ++index;
      }
   }
   return;
}


