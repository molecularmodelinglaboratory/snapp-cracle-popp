//~ #include <iostream>
#include <fstream>
#include <cmath>
#include <valarray>
#include <string>
#include <sstream>
#include <iomanip>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>
#include "bPoints.h"
using namespace std;
using namespace bStd;

const int DEBUG_COUNT=-1;

/* */
/***** Constructor and Destructor */
bPoints::bPoints() : pnts_(NULL), tets_(NULL), aaSeq_(NULL) {
   // set flags
   isInRes_ = 0;
   isInPos_ = 0;
   numPnts_ = 0;
   numTets_ = 0;
   capPnts_ = 0;
   havePnts_ = false;
   haveTets_ = false;
   haveMM_ = false;

   // allocate memory
   memset( pntFile_, '\0', sizeof(char) * 64 );
   memset( tetFile_, '\0', sizeof(char) * 64 );
   memset( pntPath_, '\0', sizeof(char) * 64 );

   //~ this->pnts_ = NULL;
   //~ this->tets_ = NULL;
   //~ this->aaSeq_ = NULL;

   this->min_[0] = 0.0; this->max_[0] = 0.0;
   this->min_[1] = 0.0; this->max_[1] = 0.0;
   this->min_[2] = 0.0; this->max_[2] = 0.0;

   this->fit_ = 0.0;
   this->thk_ = 0.0;
   this->res_ = 0.0;
   this->offset_ = 0.0;
}

bPoints::bPoints( const bPoints &c ) : pnts_(NULL), tets_(NULL), aaSeq_(NULL) {
   // copy flags
   this->havePnts_ = c.havePnts_;
   this->haveTets_ = c.haveTets_;
   this->isInRes_ = c.isInRes_;
   this->isInPos_ = c.isInPos_;
   this->haveMM_ = c.haveMM_;

   // Counters
   this->numPnts_ = c.numPnts_;
   this->numTets_ = c.numTets_;
   this->capPnts_ = c.capPnts_;

   // Copy meta data
   for(int i=0; i<3; ++i) {
      this->min_[i] = c.min_[i];
      this->max_[i] = c.max_[i];
      this->planeDisplacement_[i] = c.planeDisplacement_[i];
   }

   // Copy data
   this->pnts_ = new float[ this->capPnts_ * 3 ];
   for( int i=0; i < this->capPnts_ * 3; ++i ) {
      this->pnts_[i] = c.pnts_[i];
   }
   this->tets_ = new float[ this->numTets_ * 3 ];
   for( int i=0; i < this->numTets_ * 3; ++i ) {
      this->tets_[i] = c.tets_[i];
   }

   // Copy grid parameters
   this->fit_ = c.fit_;
   this->thk_ = c.thk_;
   this->res_ = c.res_;
   this->offset_ = c.offset_;
}

bPoints::~bPoints() {
   if( this->pnts_ != NULL ) {
      delete [] this->pnts_;
      this->pnts_ = NULL;
   }

   if( this->tets_ != NULL ) {
      delete [] this->tets_;
      this->tets_ = NULL;
   }

   if( this->aaSeq_ != NULL ) {
      delete [] this->aaSeq_;
      this->aaSeq_ = NULL;
   }
}

/***** ASSIGNMENT OPERATORS */

bPoints& bPoints::operator=( const bPoints &rhs ) {
   if(this == &rhs ) { return *this; }// check for self assignment
   
   // copy flags
   this->havePnts_ = rhs.havePnts_;
   this->haveTets_ = rhs.haveTets_;
   this->isInRes_ = rhs.isInRes_;
   this->isInPos_ = rhs.isInPos_;
   this->haveMM_ = rhs.haveMM_;

   // Counters
   this->numPnts_ = rhs.numPnts_;
   this->numTets_ = rhs.numTets_;
   this->capPnts_ = rhs.capPnts_;

   // Copy meta data
   for(int i=0; i<3; ++i) {
      this->min_[i] = rhs.min_[i];
      this->max_[i] = rhs.max_[i];
      this->planeDisplacement_[i] = rhs.planeDisplacement_[i];
   }

   // delete previous data
   delete [] this->pnts_;
   this->pnts_ = NULL;
   
   // Copy data
   this->pnts_ = new float[ this->numPnts_ * 3 ];
   for( int i=0; i < this->numPnts_ * 3; ++i ) {
      this->pnts_[i] = rhs.pnts_[i];
   }
   this->tets_ = new float[ this->numTets_ * 3 ];
   for( int i=0; i < this->numTets_ * 3; ++i ) {
      this->tets_[i] = rhs.tets_[i];
   }

   this->fit_ = rhs.fit_; // copy grid parameters
   this->thk_ = rhs.thk_;
   this->res_ = rhs.res_;
   this->offset_ = rhs.offset_;

   return *this;
}

void bPoints::clear() {
   this->resize( this->capPnts_ );
   this->haveMM_ = false;
   return;
}

/****** FILE HANDLING */
void bPoints::setSrc( const char base[], const char path[] ) {
   strcpy( this->pntBase_, base );
   strcpy( this->pntPath_, path );
   strcat( this->pntPath_, base );
   strcat( this->pntPath_, "/"  );
   
   strcpy( this->pntFile_, this->pntPath_ );
   strcat( this->pntFile_, this->pntBase_ );
   
   strcpy( this->tetFile_, this->pntFile_ );
   
   strcat( this->pntFile_, ".out" );
   strcat( this->tetFile_, "_CENTROIDS.out" );

   printf("[bPoints] Files:\n\tPath: %s\n\tProtein: %s\n\tTetrahedrals: %s\n", this->pntPath_, this->pntFile_, this->tetFile_ );
   return;
}


/* Read in Protein from File */
bool bPoints::readPoints() {

   if( !(this->havePnts_) ) {
      if( this->fileExists( this->pntFile_ ) ) {
         this->numPnts_ = this->_readPoints( this->pntFile_, this->pnts_ );
         this->havePnts_ = this->numPnts_ > 0 ? true : false;
      }
      else { throw "[bPoints] Unable to open protein file."; }
   }

   if( this->fileExists( this->tetFile_ ) && !(this->haveTets_) ) {
      this->numTets_ = this->_readPoints( this->tetFile_, this->tets_ );
      this->haveTets_ = this->numTets_ > 0 ? true : false;
   }
   //~ else { throw "[bPoints] Unable to open tetrahedral file."; }

   if( DEBUG_COUNT != -1) {
      numPnts_ = DEBUG_COUNT;
      numTets_ = DEBUG_COUNT;
   }

   this->capPnts_ = this->numPnts_;
   //~ printf("nP: %d\n", this->numPnts_ );
   this->getSeq();
   //~ for( int i=0; i < this->numPnts_; ++i ) { printf("%c ",this->aaSeq_[i]); } printf("\n"); exit(1);
   return this->havePnts_;
}

/* Handle Protein Points Only */
bool bPoints::readPoints(char *file) {
   //~ this->_saveFilenameNoExt(pntPath_,file);           // save the filename (no extension)
   //~ this->_saveFilename(pntFile_,file);                // save the filename
   //~ this->numPnts_ = _readPoints( file, this->pnts_ ); // save the protein points
   //~ this->havePnts_ = this->numPnts_ > 0 ? true : false;

   //~ if(DEBUG_COUNT != -1) numPnts_ = DEBUG_COUNT;
   return havePnts_;
}

/* Handle Protein and Tetrahedral Points */
bool bPoints::readPoints(char *f1, char *f2) {
   if(!pntPath_) { this->_saveFilenameNoExt( pntPath_, f1 ); }
   if(!pntFile_) { this->_saveFilename( pntFile_, f1 ); }
   if(!tetFile_) { this->_saveFilename( tetFile_, f2 ); }
   this->numPnts_ = _readPoints( f1, pnts_ );  // save the protein points
   this->numTets_ = _readPoints( f2, tets_ ); // save the centroid points
   this->havePnts_ = this->numPnts_ > 0 ? true : false;
   this->haveTets_ = this->numTets_ > 0 ? true : false;
   
   if(DEBUG_COUNT != -1) {
      numPnts_ = DEBUG_COUNT;
      numTets_ = DEBUG_COUNT;
      printf("DEBUG: ");
   }
   
   //~ printf("pp|%d :: tp|%d\n",numPnts_,numPnts_);
   return (havePnts_ & haveTets_);
}

/* Read Points from a File */
int bPoints::_readPoints(char* file, float* &pntSet) {

   // open the file
   ifstream ip;
   ip.open(file, ifstream::in);
   if(!ip) { return 0; }

   // read in the file... not the most efficient, but we need the size
   // -- we read in w/o doing anything to get a cound of the residues
   deque<string> data;
   string bffr;
   uint i = 0;
   for( i = 0; getline( ip, bffr ); ++i ) { data.push_back(bffr); }
   ip.close();

   // resize the array and prepare the stream
   // -- this is an unfortunate side effect of using the valarray
   // => it clears everything upon resize =/
   //~ pntSet.resize(data.size()*3);
   pntSet = new float[ i * 3 ];

   // loop through each line and save the coordinates
   int index = 0;
   for( i = 0; i < data.size(); ++i ) {
      istringstream ss(data[i]);
      float flt;

      // loop through each value on the line
      for(int j = 0; ss >> flt; ++j) {
         pntSet[index] = flt;
         ++index;
      }
   }

   return i;
}

bool bPoints::fileExists( char* file ) {
   // modified from <http://www.techbytes.ca/techbyte103.html>
   struct stat info;
   bool exists = false;
   int status;

   /* Get attrib */ status = stat( file, &info );
   /* Does exist */ if( status == 0 ) { exists = true; }
   /* May not    */ else {}
  return exists;
}

/* Save the filename (minus the extension) */
void bPoints::_saveFilename( char saveAs[], char file[] ) {
   strcpy(saveAs,file);
   return;
}
void bPoints::_saveFilenameNoExt( char saveAs[], char file[] ) {
   strncpy(saveAs,file,strrchr(file,'.')-file);
   return;
}

/****** ADD POINTS */
void bPoints::addPoint( float newPt[], int pos ) {
   if( pos > this->capPnts_ ) { throw "[addPoint] At capacity."; return; }
   if( pos == -1 ) { pos = this->numPnts_*3; }
   else {
      pos -= 1; // position to index
      pos *= 3; // 
   }
   //~ printf("[bPoints::add] "); printPoint( newPt );
   this->pnts_[pos] = newPt[0];
   this->pnts_[++pos] = newPt[1];
   this->pnts_[++pos] = newPt[2];
   //~ for( int i=0; i < 3; ++i ) { this->pnts_[ pos + i ] = newPt[i]; }
   ++this->numPnts_;
   //~ printf("[addPoint] "); this->printPoint( newPt );
   this->haveMM_ = false;
   return;
}

void bPoints::addPoints( float newPts[], int num ) {
   if( this->numPnts_ + num > capPnts_ ) { throw "[addPoint] At capacity."; return; }
   int pos = this->numPnts_ * 3;
   int last = num * 3;
   for( int i=0; i < last; ++i ) { 
      this->pnts_[ pos + i ] = newPts[i];
   }
   this->numPnts_ += num;
   return;
}

/****** SIZE AND SPACE */
//~ void bPoints::setGridParam( float r, float f, float t, float o ) {
   //~ this->fit_ = f; // copy grid parameters
   //~ this->thk_ = t;
   //~ this->res_ = r;
   //~ this->offset_ = o;
   //~ return;
//~ }

void bPoints::setGridParam( float r, float f, float t, float o, float b ) {
   float mod = isInRes_ ? r : 1;
   this->res_ = r;
   this->fit_ = f * mod;
   this->thk_ = t * mod;
   this->offset_ = o * mod;
   this->buffer_ = b * mod;
   return;
}

int  bPoints::size() {
   return this->numPnts_;
}

void bPoints::resize( int num ) {
   if( this->pnts_ != NULL ) {
      delete [] this->pnts_;
      this->pnts_ = NULL;
   }
   
   this->numPnts_ = 0;
   this->capPnts_ = num;
   this->pnts_ = new float[this->capPnts_ * 3];
   
   for( int i=0; i < this->capPnts_ * 3; ++i ) { this->pnts_[i] = 0; } // init to 0

   this->haveMM_ = false;
   return;
}

void bPoints::resizeCopy( int num ) {
   if( this->pnts_ == NULL ) { this->resize( num ); return; }

   int sizePnt = this->capPnts_ * 3;
   float tempPnt[ sizePnt ];

   // Save, Erase, Resize, Rewrite :: Pnts
   for( int i=0; i < sizePnt; ++i ) { tempPnt[i] = this->pnts_[i]; } // save
   delete [] this->pnts_;
   this->pnts_ = NULL;
   this->pnts_ = new float[ num * 3 ];
   for( int i=0; i < sizePnt; ++i ) { this->pnts_[i] = tempPnt[i]; } // reload
   for( int i=sizePnt; i < num * 3; ++i ) { this->pnts_[i] = 0; } // init to 0
   this->capPnts_ = num;

   return;
}

void bPoints::sizeAndSpace( int nP, const bPoints &f ) {
   // set no. pnts; no tets yet
   //~ this->numPnts_ = nP;
   //~ this->numTets_ = 0;
   
   //~ if( this->pnts_ != NULL ) {
      //~ delete [] this->pnts_;
      //~ this->pnts_ = NULL;
   //~ }
   
   //~ // resize accordingly
   //~ nP *= 3;
   //~ printf("[sizeAndSpace] resizing to %d\n", nP);
   //~ this->pnts_ = new float[nP];

   this->resize( nP );
   this->set2SameSpace( f );
   return;
}

void bPoints::set2SameSpace(const bPoints &c) {
   if(this == &c ) { return; }// check for self assignment

   // just initializing -- no points yet
   this->havePnts_ = true;
   this->haveTets_ = false;

   // we assume that we're already in docking space
   this->isInRes_ = true;
   this->isInPos_ = true;

   // Data
   for(int i=0; i<3; ++i) { // copy values
      this->planeDisplacement_[i] = c.planeDisplacement_[i];
   }

   // Copy data
   this->fit_ = c.fit_; // copy grid parameters
   this->thk_ = c.thk_;
   this->res_ = c.res_;

   return;
}

/* */
/****** COMMAND LINE ARGUEMENTS */
bool bPoints::cla(int numArg, char** argArray) {
   
   // loop through all given parameters (i=1 to skip command)
   for(int i=1; i<numArg; ++i) {

      // catches a filename...not the best
      // but this allows for no flags at all
      if((argArray[i][0] != '-' && i == 1) || !strcmp(argArray[i],"-d")) {
         this->_saveFilename(argArray[++i],pntFile_);
         this->_saveFilenameNoExt(argArray[i],pntPath_);
         if(i+1 < numArg && argArray[i+1][0] != '-') {
            this->_saveFilename(argArray[++i],tetFile_);
         }
      }
      // bad command line input...
      else {
         printf("Usage: ./main.e [-i] <prot file> [<tet file>] [options]\n");
         printf("\tr: resolution [1.0,0.5]\n");
         printf("\tf: fit; defines exclusion radius\n");
         printf("\tt: thickness; defines thickness of grid\n\n");
         exit(1);
      }
   }
   
   return 1;
}



/***** MEASUREMENTS */

/* Find Min and Max */
void bPoints::_findMinMax() {
   
   for( int i=0; i < 3; ++i ) {
      this->min_[i] = this->pnts_[i];
      this->max_[i] = this->pnts_[i];
   } // reset max and min
   
   int index = 0;
   for( int i=0; i < this->numPnts_; ++i ) {
      for( int k=0; k < 3; ++k ) {
         if( this->min_[k] > this->pnts_[index] )
            this->min_[k] = this->pnts_[index];
         if( this->max_[k] < this->pnts_[index] )
            this->max_[k] = this->pnts_[index];
         ++index;
      } // loop through axes
   } // loop through points

   this->haveMM_ = true;
   return;
}

/* Calculate Point Distances */
float bPoints::pointDistance(float* a, float* b) {
   float c[3] = { 0, 0, 0 };
   float sum = 0;
   for( int i=0; i < 3; ++i ) {
      c[i] = a[i] - b[i];
      c[i] *= c[i];
      sum += c[i];
   }
   return sqrt( sum );
}

void bPoints::getSeq() {
   if( !this->pntPath_ ) { throw "[getSeq] Path not set.\n"; return; }

   //~ char seq[this->numPnts_];
   this->aaSeq_ = new char[ this->numPnts_ + 1 ];
   char file[64];
   memset( file, '\0', 64 );
   memmove( file, this->pntPath_, 64 );
   strcat( file, this->pntBase_ );
   strcat( file, ".seq" );
   ifstream ip;
   ip.open( file, ifstream::in );
   string bffr;

   for( int i = 0; getline( ip, bffr ); ++i ) {
      istringstream ss( bffr );
      char code[4];
      ss >> code;
      this->aaSeq_[i] = res3to1( code );
      //~ printf("%s|%c ",code, aaSeq_[i]);
   }
   //~ printf("\n"); exit(1);
   ip.close();
   return;
}

char bPoints::res3to1( char res[] ) {
   char one = NULL;
   //~ printf("%c\n",damn);
   //~ damn = 'B';

   //~ return damn;
   switch( toupper( res[0] ) ) {
      case 'A': 
         switch( toupper( res[1] ) ) {
            case 'L': /* Alanine */
               one = 'A'; break;
            case 'R': /* Arginine */
               one = 'R'; break;
            case 'S':
               switch( toupper( res[2] ) ) {
                  case 'N': /* Asparagine */
                     one = 'N'; break;
                  case 'P': /* Aspartic Acid */
                     one = 'D'; break;
                  default: break;
               }
            default: break;
         }
         break;
      case 'C': /* Cysteine */
         one = 'C'; break;
      case 'G':
         switch( toupper( res[2] ) ) {
            case 'N': /* Glutamine */
               one = 'Q'; break;
            case 'U': /* Glutamic Acid */
               one = 'E'; break;
            case 'Y': /* Glycine */
               one = 'G'; break;
            default: break;
         }
         break;
      case 'H': /* Histidine */
         one = 'H'; break;
      case 'I': /* Isoleucine */
         one = 'I'; break;
      case 'L':
         switch( toupper( res[1] ) ) {
            case 'E': /* Leucine */
               one = 'L'; break;
            case 'Y': /* Lysine */
               one = 'K'; break;
            default: break;
         }
         break;
      case 'M': /* Methionine */
         one = 'M'; break;
      case 'P':
         switch( toupper( res[1] ) ) {
            case 'H': /* Phenylalanine */
               one = 'F'; break;
            case 'R': /* Proline */
               one = 'P'; break;
            default: break;
         }
         break;
      case 'S': /* Serine */
         one = 'S'; break;
      case 'T':
         switch( toupper( res[1] ) ) {
            case 'H': /* Threonine */
               one = 'T'; break;
            case 'R': /* Tryptophan */
               one = 'W'; break;
            case 'Y': /* Tyrosine */
               one = 'Y'; break;
            default: break;
         }
         break;
      case 'V': /* Valine */
         one = 'V'; break;
      default: break;
      
   }
   return one;
}

/* Move all points into the resolution space for docking

>> Description of problem

  -2  -1   0   1   2   3 (in angstroms)
           0 1 2 3 4 5 6 (in angstroms/[res_=0.5])
   |---|---|---|---|---|
    *[-1.75]     *[1.5]
1) <--(f+t)              : pointDisplacement = min - buffer
   pD = -1.75 - ([fit=1] + [thk=1]) = -3.75
2) (pD)-->   (pD)-->     : shift all points by pD
3)                       : put in resolution
  -2  -1   0   1   2   3   4   5     (in angstroms)
           0 1 2 3 4 5 6 7 8 9 A B   (in angstroms/[res_=0.5])
   |---|---|---|---|---|---|---|---|
                   *[2~4]       *[5.25~10.5]
4)                       : place point in a box of size 2*buffer
  -2  -1   0   1   2   3   4   5     (in angstroms)
           0 1 2 3 4 5 6 7 8 9 A B C D E F  (in angstroms/[res_=0.5])
   |---|---|---|---|---|---|---|---|---|---|
                   *_           *
           |---|---|_|---|---|  _
             t   f     |---|---|_|---|---|
5)                       : min = (int)pointMin - (t+f)
                         : max = (int)pointMax + (t+f) + 1
   min = 2 - (1+1) | 4 - (2+2) = 0
   max != [5 + (1+1) | 10 + (2+2) = 14] ~> 15!
   
   It is important to wait until in resolution to get the min/max.
   Also important to add one to the value of max
   Remember: max is the last needed index!
*/

bool bPoints::setToDockingSpace() {

   // check to see if we're already in a positive plane
   if(isInPos_) { return 0; }

   // make sure we have the protein data
   if(havePnts_) {

      this->_findMinMax(); // get the min and max of the point set

      for(int i=0; i<3; ++i) {
         // calculate the amount required to move into the positive plane for each axis
         // NOTE: we don't adjust fit or thk b/c bGrid should not have put them in resolution yet!!
         planeDisplacement_[i] = this->min_[i] - (this->offset_ + this->buffer_);
      } // adjust min and max to encompass the grid, not just the protein

      // move the data points for protein and tetrahedrals
      this->_translatePointPlane();
      
      // change to resolution space and then find the min and max
      // -- we're in the positive plane
      // -- must change to resolution space BEFORE getting max and min
      this->_changePointSpace();
      this->_findMinMax();
      printf("[bPoints] min: "); this->printPoint( this->min_ );
      printf("[bPoints] max: "); this->printPoint( this->max_ );
      
   }
   // make note of the shift
   //~ isInPos_ = true;
   return (this->havePnts_ & this->haveTets_);
}

/* Set to Normal Space */
bool bPoints::setToNormalSpace(std::deque<bPoints> &p, int nC) {
   for(int i=0; i < nC; ++i) { // loop through all point sets
      setToNormalSpace(p[i]);
   }
   return true;
}
bool bPoints::setToNormalSpace(bPoints &p) {
   if(p.isInRes_) {
      //~ printf("[bPoints] Changing point space...\n");
      p._changePointSpace();
      //~ bPoints::printPoints( p.pnts_, p.numPnts_ );
      
   }
   if(p.isInPos_) {
      //~ printf("[bPoints] Translating point plane...\n");
      p._translatePointPlane();
      //~ bPoints::printPoints( p.pnts_, p.numPnts_ );
   }
   p._findMinMax();
   return true;
}


/* Translate points back and forth while in normal space */
bool bPoints::_translatePointPlane() {
   // skip if we're in resolution
   if( isInRes_ ) return isInPos_;

   // if we're in the positive plane, go to the original & vice versa
   int direction = 1;
   if( isInPos_ ) { direction = -1; }
   for( int i=0; i < 3; ++i ) {
      this->planeDisplacement_[i] *= direction;
   } // redirect displacement

   // move each axis
   int index = 0;
   for( int i=0; i < this->numPnts_; ++i ) {
      for( int k=0; k < 3; ++k ) {
         this->pnts_[index] -= planeDisplacement_[k];
         ++index;
      } // axis loop
   } // point loop
   if( this->haveTets_ ) {
      index = 0;
      for( int i=0; i < this->numTets_; ++i ) {
         for( int k=0; k < 3; ++k ) {
            this->tets_[index] -= planeDisplacement_[k];
            ++index;
         } // axis loop
      } // point loop
   }

   for( int i=0; i < 3; ++i ) {
      this->planeDisplacement_[i] *= direction;
   } // reset displacement
   
   // flip the bit and return
   isInPos_ ^= 1;
   return isInPos_;
}

/* Diffract points from normal to resolution space and back */
bool bPoints::_changePointSpace() {

   // doint do this unless we're in the positive plane
   if(!this->isInPos_) { return this->isInRes_; }

   // go to resolution space, unless we're there already
   float diffraction = 1 / this->res_;
   if(this->isInRes_) { diffraction = this->res_; }

   // diffract / refract....whatever...
   for( int i=0; i < this->numPnts_ * 3; ++i ) {
      this->pnts_[i] *= diffraction;
   }
   if( this->haveTets_ ) {
      for( int i=0; i < this->numTets_*3; ++i ) {
         this->tets_[i] *= diffraction;
      }
   }

   // flip the bit and return
   this->isInRes_ ^= 1;
   return isInRes_;
}


/****** ROTATE */
bool bPoints::rotateTheta( float point[], int theta ) {
   // Rotate Theta -- inclination
   register double t = theta * PI / 180; // adjust to radians
   valarray<float> rotMat(0.0,9); // declare rotation matrix
   rotMat[0] = cos(t); // initialize rotation matrix
   rotMat[1] = -sin(t);
   rotMat[3] = -rotMat[1];
   rotMat[4] = rotMat[0];
   rotMat[8] = 1;

   valarray<float> ptCopy( point, 3 ); // copy the point
   valarray<float> temp(0.0,3);
   for( int i=0; i < 3; ++i ) {
      int index = i * 3;
      temp = rotMat[ slice(index,3,1) ]; // copy the row
      temp *= ptCopy; // multiply rotMat row w/ point col
      point[i] = (float)temp.sum(); // sum
   }

   return true;
}

bool bPoints::rotatePhi( float point[], int phi) {
   // Rotate Phi -- Azimuth 
   register float t = phi * PI / 180; // adjust to radians
   valarray<float> rotMat(0.0,9); // declare rotation matrix
   rotMat[0] = cos(t); // initialize rotation matrix
   rotMat[2] = sin(t);
   rotMat[4] = 1;
   rotMat[6] = -rotMat[2];
   rotMat[8] = rotMat[0];

   valarray<float> ptCopy( point, 3 ); // copy the point
   valarray<float> temp(0.0,3);
   for( int i=0; i < 3; ++i ) {
      int index = i * 3;
      temp = rotMat[ slice(index,3,1) ]; // copy the row
      temp *= ptCopy; // multiply rotMat row w/ point col
      point[i] = (float)temp.sum(); // sum
   }

   return true;
}

bool bPoints::rotateThetaPhi( float point[], int theta, int phi) {
   register float t = phi * PI / 180; // adjust to radians
   std::valarray<float> rotMatP(0.0,9); // declare rotation matrix
   rotMatP[0] = cos(t); // initialize rotation matrix
   rotMatP[2] = sin(t);
   rotMatP[4] = 1;
   rotMatP[6] = -rotMatP[2];
   rotMatP[8] = rotMatP[0];

   t = theta * PI / 180; // adjust to radians
   std::valarray<float> rotMatT(0.0,9); // declare rotation matrix
   rotMatT[0] = cos(t); // initialize rotation matrix
   rotMatT[1] = -sin(t);
   rotMatT[3] = -rotMatT[1];
   rotMatT[4] = rotMatT[0];
   rotMatT[8] = 1;

   // create the dual rotation matrix
   std::valarray<float> rotMat(0.0,9);
   std::valarray<float> temp(0.0,3);
   for(int i=0; i<3; ++i) {
      int iIndex = i*3;
      std::slice row = std::slice(iIndex,3,1);
      for(int k=0; k<3; ++k) {
         int kIndex = iIndex+k;
         std::slice col = std::slice(k,3,3);
         temp = (std::valarray<float>)rotMatT[row] * (std::valarray<float>)rotMatP[col];
         rotMat[kIndex] = temp.sum();
      }
   }

   std::valarray<float> ptCopy( point, 3 ); // copy the point
   temp = 0;
   for(int i=0; i<3; ++i) {
      int index = i*3;
      std::slice row = std::slice(index,3,1); // std::slice by row
      temp = rotMat[row]; // copy the row
      temp *= ptCopy; // multiply rotMat row w/ point col
      point[i] = (float)temp.sum(); // sum
   }

   return true;
}

bool bPoints::rotatePhiTheta( float point[], int theta, int phi ) {
   register float t = phi * PI / 180; // adjust to radians
   std::valarray<float> rotMatP(0.0,9); // declare rotation matrix
   rotMatP[0] = cos(t); // initialize rotation matrix
   rotMatP[2] = sin(t);
   rotMatP[4] = 1;
   rotMatP[6] = -rotMatP[2];
   rotMatP[8] = rotMatP[0];

   t = theta * PI / 180; // adjust to radians
   std::valarray<float> rotMatT(0.0,9); // declare rotation matrix
   rotMatT[0] = cos(t); // initialize rotation matrix
   rotMatT[1] = -sin(t);
   rotMatT[3] = -rotMatT[1];
   rotMatT[4] = rotMatT[0];
   rotMatT[8] = 1;

   // create the dual rotation matrix
   std::valarray<float> rotMat(0.0,9);
   std::valarray<float> temp(0.0,3);
   for(int i=0; i<3; ++i) {
      int iIndex = i*3;
      std::slice row = std::slice(iIndex,3,1);
      for(int k=0; k<3; ++k) {
         int kIndex = iIndex+k;
         std::slice col = std::slice(k,3,3);
         temp = (std::valarray<float>)rotMatT[col] * (std::valarray<float>)rotMatP[row];
         rotMat[kIndex] = temp.sum();
      }
   }

   std::valarray<float> ptCopy( point, 3 ); // copy the point
   temp = 0;
   for(int i=0; i<3; ++i) {
      int index = i*3;
      std::slice row = std::slice(index,3,1); // std::slice by row
      temp = rotMat[row]; // copy the row
      temp *= ptCopy; // multiply rotMat row w/ point col
      point[i] = (float)temp.sum(); // sum
   }

   return true;
}



/****** Conversion Functions */
bool bPoints::c2s( float* pt ) {
   float t[3] = { pt[0], pt[1], pt[2] };
   t[0] *= t[0]; t[1] *= t[1]; t[2] *= t[2];
   t[0] = t[0] + t[1] + t[2]; t[0] = sqrt( t[0] );
   pt[2] = atan2( pt[2], pt[0] );
   pt[1] = asin( pt[1] / t[0] );
   pt[0] = t[0];
   pt[1] *= 180 / PI;
   pt[2] *= 180 / PI;
   //~ pt[std::slice(1,2,1)] = std::valarray<float>(pt[std::slice(1,2,1)]) * 180 / PI; // convert from radians
   return true;
}

bool bPoints::s2c( float* pt ) {
   pt[1] *= PI / 180;
   pt[2] *= PI / 180;
   float t[3] = { pt[0], pt[1], pt[2] };
   pt[0] = t[0] * cos(t[1]) * cos(t[2]);
   pt[1] = t[0] * sin(t[1]);
   pt[2] = t[0] * cos(t[1]) * sin(t[2]);
   return true;
}

/****** PyMol */
void bPoints::_pymolPoints( FILE *op, float* pnts, int numPnts, char name[] ) {
   char color[6] = "green";
   float size = 0.2;
   _pymolPoints( op, pnts, numPnts, name, color, size );
   return;
}
void bPoints::_pymolPoints( FILE *op, float* pnts, int numPnts, char name[], char color[], float size) {
   fprintf(op,"%s = [\n",name);
   //~ fprintf(op,"\tCOLOR, %1.1f, %1.1f, %1.1f,\n",color[0],color[1],color[2]);
   for( int i=0; i < numPnts; ++i ) {
      int index = i*3;
      fprintf(op,"\tSPHERE, %.2f, %.2f, %.2f, %.2f,\n",
         pnts[index], pnts[index+1], pnts[index+2], size);
   }
   fprintf(op,"\t]\n");
   fprintf(op,"cmd.load_cgo(%s,'%s')\n",name,name);
   fprintf(op,"cmd.color( \"%s\", \"%s\" )\n", color, name );
   return;
}
void bPoints::_pymolConnectedPoints( FILE *op, float* pnts, int numPnts, char name[], char color[], float size ) {
   fprintf(op,"%s = [\n",name);
   fprintf(op,"\tCOLOR, %s\n", color);
   for(int i=0; i<numPnts; ++i) {
      int index = i*3;
      fprintf(op,"\tSPHERE, %.2f, %.2f, %.2f, %.2f,\n",
         pnts[index], pnts[index+1], pnts[index+2], size);
      //~ fprintf(op,"\tCOLOR, %1.1f, %1.1f, %1.1f,\n",color[0],color[1],color[2]);
   }
   fprintf(op,"\tLINEWIDTH, 2.0,\n");
   fprintf(op,"\tBEGIN, LINES,\n");
   fprintf(op,"\tCOLOR, %s\n", color);
   for(int i=1; i<numPnts; ++i) {
      int index = i*3;
      fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",pnts[index],pnts[index+1],pnts[index+2]);
      fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",pnts[index-3],pnts[index-2],pnts[index-1]);
   }
   fprintf(op,"\tEND\n");
   fprintf(op,"\t]\n");
   fprintf(op,"cmd.load_cgo(%s,'%s')\n",name,name);
   return;
}
void bPoints::_pymolConnectedPseudoatoms( FILE *op, char name[], char color[] ) {
   this->_pymolConnectedPseudoatoms( op, this->pnts_, this->numPnts_, name, color );
   return;
}
void bPoints::_pymolConnectedPseudoatoms( FILE *op, float* pnts, int numPnts, char name[], char color[] ) {

   // set parameters
   fprintf(op,"cmd.set(\"auto_show_spheres\", \"on\")\n");
   fprintf(op,"cmd.set(\"sphere_scale\", .25)\n");
   fprintf(op,"cmd.set(\"auto_show_lines\", \"on\")\n");

   // print points
   fprintf(op,"cmd.pseudoatom(\"%s\",pos=[%.2f,%.2f,%.2f],name=\"p%d\")\n", name, pnts[0], pnts[1], pnts[2], 0);
   for( int i=1; i < numPnts; ++i ) {
      int index = i * 3;
      fprintf(op,"cmd.pseudoatom(\"%s\",pos=[%.2f,%.2f,%.2f],name=\"p%d\")\n",
         name, pnts[index], pnts[index+1], pnts[index+2], i);
      fprintf(op,"cmd.bond(\"%s////p%d\",\"%s////p%d\")\n", name, i, name, i-1 );
   }
   fprintf(op,"cmd.color(\"%s\",\"%s\")\n",color,name); // color peptide
   fprintf(op,"cmd.color(\"gray80\",\"%s////p0\")\n",name); // color first residue
   //~ (void)fprintf(op,"cmd.show(\"sticks\", \"%s\")\n", name );

   //~ fprintf(op,"cmd.clip(\"slab\",100)\n");
   return;
}

/* FindNearbyPoints */
void bPoints::findNearbyPoints( bPoints &searchPnts, bPoints &nearby ) {

   // Calculate the box dimensions
   if( !(this->haveMM_) ) { this->_findMinMax(); }
   float ma[3], mi[3];
   for( int i=0; i < 3; ++i ) {
      mi[i] = this->min_[i] - (this->fit_ * 1.8);
      ma[i] = this->max_[i] + (this->fit_ * 1.8);
   }

   // Identify which points in the search space are nearby
   // -- Test bounds of each point (per axis) and save the index if valid
   deque<int> found;
   int index = 0;
   for( int i=0; i < searchPnts.numPnts_; ++i ) {
      bool isValid = true;
      index = i * 3;
      for(int k=0; k < 3 && isValid; ++k) {
         if( searchPnts.pnts_[index + k] > ma[k] ) { isValid = false; continue; }
         else if( searchPnts.pnts_[index + k] < mi[k] ) { isValid = false; continue; }
         else {}
      } // loop axis
      if( isValid ) { found.push_back( i ); }
   } // loop points
   
   // Prepare nearby
   nearby.sizeAndSpace( (this->numPnts_ + found.size()), *this );

   // Save reference points
   nearby.addPoints( this->pnts_, this->numPnts_ );

   // Save search points
   for( uint k=0; k < found.size(); ++k ) {
      int fpos = found[k] * 3;
      float npt[3];
      for( uint m=0; m < 3; ++m ) {
         npt[m] = searchPnts.pnts_[ fpos + m ];
      } // loop axis
      nearby.addPoint( npt );
   } // loop points

   return;
}

void bPoints::_pymolPseudoatoms( FILE* op, char name[], char color[] ) {
   this->_pymolPseudoatoms( op, this->pnts_, this->numPnts_, name, color );
   return;
}
void bPoints::_pymolPseudoatoms( FILE *op, float* pnts, int numPnts, char name[], char color[] ) {

   // set parameters
   fprintf(op,"cmd.set(\"auto_show_spheres\", \"on\")\n");
   fprintf(op,"cmd.set(\"sphere_scale\", .25)\n");
   fprintf(op,"cmd.set(\"auto_show_lines\", \"on\")\n");

   // print points
   for( int i=0; i < numPnts; ++i ) {
      int index = i*3;
      fprintf(op,"cmd.pseudoatom(\"%s\",pos=[%.2f,%.2f,%.2f],name=\"p%d\")\n",
         name, pnts[index],  pnts[index+1],pnts[index+2],i);      
   }
   fprintf(op,"cmd.color(\"%s\",\"%s\")\n",color,name); // color peptide
   fprintf(op,"cmd.color(\"white\",\"%s////pt0\")\n",name); // color first residue
   //~ fprintf(op,"cmd.clip(\"slab\",100)\n");
   return;
}

/****** Print functions */
void bPoints::printPoint( int* pt ) {
   for(int i=0; i<3; ++i) { printf("%d | ",pt[i]); } printf("\n");
   return;
}
void bPoints::printPoint( float* pt ) {
   for(int i=0; i<3; ++i) { printf("%.2f | ",pt[i]); } printf("\n");
   return;
}
void bPoints::printPoint( int pt ) {
   for( int i=pt*3; i < (pt*3) + 3; ++i ) {
      printf("%.2f | ",this->pnts_[i]);
   }
   printf("\n");
   return;
}


void bPoints::print() {
   printf("numPoints: %d\n", this->numPnts_);
   printf("min: "); this->printPoint( this->min_ );
   printf("max: "); this->printPoint( this->max_ );
   this->printPoints( this->pnts_, this->numPnts_ );
   return;
}
void bPoints::printPoints( float* pnts, int num ) {
   for( int i=0; i < num; ++i ) {
      printf("\t%d: ",i);
      for(int j=0; j<3; ++j) {
         int index = (i*3)+j;
         printf("%#4.2f | ",pnts[index]);
      }
      printf("\n");
   }
   printf("\n");
   return;
}



/* Print functions */
/* Print single point *
void bPoints::printPoint(valarray<float> &pt) {
   for(int i=0; i<3; ++i) {
      printf("%.2f | ",pt[i]);
   }
   printf("\n");
   return;
}

/* Print all points *
void bPoints::printPoints(valarray<float>& pnts) {
   int numPnts = pnts.size()/3;
   //~ printf("Points\n");
   for(int i=0; i<numPnts; ++i) {
      printf("\t%d: ",i);
      for(int j=0; j<3; ++j) {
         int index = (i*3)+j;
         printf("%#4.2f | ",pnts[index]);
      }
      printf("\n");
   }
   printf("\n");
   return;
}

/* END */


