#ifndef BSIMPLEX_H
#define BSIMPLEX_H

#include <stdio.h>
#include "bHex.h"

namespace bStd { class bSimplex; };

class bStd::bSimplex {
   friend class bDelTess;
   friend class bCentroid;

   private:
      
      static short count_;
      unsigned short id_;
      //~ double vrtx_[20]; // vertex coordinates [p_h, p_x, p_y, p_z, p_q]
      double det_[5]; // determinant
      bSimplex *nghbr_[4]; // pointer to neighbors

   protected:
   
   public:
      // Constructors
      bSimplex();
      bSimplex( const bSimplex& );
      ~bSimplex();
   
      // Assignment Operators
      bSimplex& operator=( const bSimplex& );
      //~ bSimplex& operator=( const vaf& );
      bSimplex& operator=( const double* );
      
      // Conditional Operators
      bool operator==( const bSimplex& );
      bool operator!=( const bSimplex& );
      //~ short  inSphere( const vaf& );
      short  inSphere( const double* );
   
      // Setup
      bool setup( const double* );
      bool orient( double* );
   
      // Calculations
      //~ void calcDet( const double*, bool =(true) ); // by minors, def
      void detByMinors( double*, const double*, int );
      //~ void detByMinors( vaf&, vaf&, int );
      //~ double detByGauss( vaf&, int );
      //~ void swapRow( vaf&, int, int, int );
      void swapRow( double[], int, int, int );
      void swapRow( double[], int, int );
   
      // Internal
      
      //Output
      void print( FILE* =(stdout) );
      void pymolSimplex( FILE*, char[], char[], int =(0) );
      //~ void printMatrix( vaf&, int );
      //~ void printDet( vaf& );
   
   
};

#endif
