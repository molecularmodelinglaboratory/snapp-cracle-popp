#ifndef BSIMPLEX_H
#define BSIMPLEX_H

#include <valarray>
#include <stdio.h>
#include "bHex.h"

namespace bStd { class bSimplex; };

class bStd::bSimplex {
   typedef std::valarray<float> vaf;
   friend class bDelTess;
   friend class bCentroid;

   private:
      
      static short count_;
      short id_;
      float vrtx_[20]; // vertex coordinates [p_h, p_x, p_y, p_z, p_q]
      float det_[5]; // determinant
      bSimplex *nghbr_[4]; // pointer to neighbors

      static std::slice cSlc_[3]; // slices for each point
      static std::slice pSlc_[4]; // slices for each point
      static std::slice sSlc_[4]; // slices for each point
      
   
   protected:
      
   
   public:
      // Constructors
      bSimplex();
      bSimplex( const bSimplex& );
      ~bSimplex();
   
      // Assignment Operators
      bSimplex& operator=( const bSimplex& );
      bSimplex& operator=( const vaf& );
      bSimplex& operator=( const float* );
      
      // Conditional Operators
      bool operator==( const bSimplex& );
      bool operator!=( const bSimplex& );
      short  inSphere( const vaf& );
      short  inSphere( const float* );
   
      // Setup
      void setup( const vaf& );
      void setup( const float* );
      void orient();
   
      // Calculations
      void calcDet( bool =(true) ); // by minors, def
      void detByMinors( vaf&, vaf&, int );
      float detByGauss( vaf&, int );
      void swapRow( vaf&, int, int, int );
      void swapRow( float[], int, int, int );
   
      // Internal
      
      //Output
      void print( FILE* =(stdout) );
      void pymolSimplex( FILE*, char[], char[], int =(0) );
      void printMatrix( vaf&, int );
      void printDet( vaf& );
   
   
};

#endif
