#ifndef BSNAPP_H
#define BSNAPP_H


namespace bStd { class bSnapp; };

class bStd::bSnapp {
   typedef unsigned int uint;

   private:
      static bool isSet_;
      static char file_[64];

   public:
      static float snapp_[20][20][20][20][4];

      bSnapp();
      bSnapp( const bSnapp & );
      ~bSnapp();

      static void readSnapp( const char[] =("./SNAPP_VALUES_BALA.txt") );
      static float score( char[], int );
      static float score( int[], int );
   
      static int res2num( char );
};




#endif
