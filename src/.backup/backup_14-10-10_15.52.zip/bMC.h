#ifndef BMC_H
#define BMC_H

#include <deque>
#include <list>

#include "bHex.h"
#include "bDelTess.h"
#include "bGrid.h"
#include "bPoints.h"
#include "bConf.h"

namespace bStd { class bMC; class bMC_MetTable; };

typedef unsigned int uint;
typedef unsigned long ulong;
typedef unsigned short ushort;


class bStd::bMC {
   //~ typedef std::deque< uint > dei;
   //~ typedef std::deque< float > def;
   typedef std::deque< ulong > del;
   typedef std::deque< bHex > deH;
   typedef std::deque< bPoints > deP;
   typedef std::deque< bDelTess > deT;
   typedef std::list< bConf > liC;
   typedef std::list< ushort > lis;
   
   friend class bDocker;
   
private:


   //~ std::deque<bHex>

   //~ uint  pepLen_;
   //~ lis   px_;
   //~ del   pt_;
   liC   conf_;
   //~ deH xId_;
   //~ deH yId_;
   //~ deH zId_;
   //~ del dtId_;
   
   
   bool   havePerturbSchema_;
   int**  perturbSchema_;
   ushort numOpt_;
   int    perturbRangeMin_[3];
   int    perturbRangeMax_[3];
   std::deque< std::list< ushort > > perturbDone_;

   float  threshold_;
   ushort numIter_;
   //~ deP   confPe_;
   //~ del   confId_;
   //~ deP   confNb_;
   //~ deT   confDt_;
   //~ float* confSc_;
   //~ uint* confOr_;

   bGrid*  grd_;
   bPoints orgSrc_;
   bPoints orgPep_;
   
   uint currPnt_;
   uint currPtb_;
   
   static bool haveGradient_;


public: 
   bMC( bGrid* =(NULL) );
   bMC( const bMC& );
   ~bMC();

   void clear();
   void save( const bPoints&, const bPoints& );

   bool metropolis( const bPoints&, const bPoints&, const float score );
   bool metropolis( const float score );
   ulong savePepId( const bPoints* );
   
   void setupPerturb( const int[3], const int[3] );
   bool perturb( bConf& );

   void pymol( FILE*, char[], char[] );
};

/****************************** MetTable */
class bStd::bMC_MetTable{
   
private:
   float* delt_;
   float* prob_;
   ushort size_;

public:
   bMC_MetTable();
   ~bMC_MetTable();

   float operator[]( float );

   void read( char[] );

   
};

#endif
