#ifndef BDOCKER_H
#define BDOCKER_H

//~ #include <valarray>
#include <vector>
#include <deque>
#include "bGrid.h"
#include "bPoints.h"
#include "bDelTess.h"
#include "MersenneTwister.h"

namespace bStd { class bDocker; };

class bStd::bDocker {
   typedef unsigned int uint;

public:
   bDocker();
   ~bDocker();
   
   // Command Line Arguements
   const char* usage();
   bool cla( int, char** );

   // Peptides
   void initializePeptides( int, int );
   void findNearbyPoints(  bPoints&, bPoints&, bPoints& );

   // Random Point generators
   int getRandomNumber( int );
   bool generateRandomGridPoint( bGrid&, bGrid&, bPoints&, int );
   bool generateDisplacedRandomGridPoint( bGrid&, bGrid&, bPoints&, int, float[] );
   bool generateRandomChain( bGrid&, bPoints&, float[], int=1, int=-1 );
   bool generateChains( bGrid&, std::vector<bPoints>&, float[], int=-1, int=-1 );

   // PyMol
   void printPyMol();
   static void _pymolHeader( FILE*, int=0 );
   void _pymolPdb( FILE*, char* );
   void _pymolOrigin( FILE* );
   static void _pymolTrueOrigin( FILE*, int );
   void _pymolGridLines( FILE* );
   void _pymolMovie( FILE* );
   void _pymolOptions( FILE* );

   // Temporary
   void doItAll();
      
protected:
   // Counters
   int numConf_;

   // Sources
   bGrid grd_;
   bGrid pepGrd_;
   bPoints prt_;
   std::vector<bPoints> pep_;
   bDelTess dt_;
   bPoints test_;
   MTRand rndNum_;
   std::deque<bGrid> tempGrd_;

   // Flags
   bool makeMovie_;
   bool haveGrd_;
   bool havePrt_;
   bool havePep_;
   bool haveDT_;

   //~ bStamp ext_;

private:

};




#endif
