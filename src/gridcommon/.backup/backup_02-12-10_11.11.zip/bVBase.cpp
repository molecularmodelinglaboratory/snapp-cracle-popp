
#include <stdio.h>

#include "bVBase.h"

using namespace std;
using namespace bStd;

/* Write PyMol Header */
void bVBase::pymolHeader(FILE* op,int white) {
   (void)fprintf(op,"from pymol import cmd\n");
   (void)fprintf(op,"from pymol.cgo import *\n");
   (void)fprintf(op,"\n");
   if(white) {
      (void)fprintf(op,"cmd.bg_color(\"white\")\n");
   }
   (void)fprintf(op,"\n");
   
   // set parameters
   (void)fprintf(op,"cmd.set(\"auto_show_spheres\", \"on\")\n");
   (void)fprintf(op,"cmd.set(\"sphere_scale\", .25)\n");
   (void)fprintf(op,"cmd.set(\"auto_show_lines\", \"on\")\n");
   (void)fprintf(op,"cmd.set(\"label_position\",(1.5,1.5,1.5))\n");
   (void)fprintf(op,"cmd.set(\"label_size\",8)\n");
   (void)fprintf(op,"\n");

   return;
}