#ifndef BHEX_H
#define BHEX_H

namespace bStd { class bHex; };

class bStd::bHex {
   public:
      typedef unsigned long ulong;
      typedef unsigned int uint;
      typedef unsigned short ushort;
      typedef ulong* uhex;
      static unsigned int hamming_[65536];
      static bool isHamRdy_;
   
      bHex();
      bHex( int );
      bHex( const bHex& );
      ~bHex();
   
      bHex& operator=( const bHex& );
      bHex& operator=( const int );
      bHex& operator|=( const bHex& );
      bHex& operator|=( const int );
      bHex& operator&=( const bHex& );
      bHex& operator&=( const int );
      bHex& operator^=( const bHex& );
      bHex& operator^=( const int );
      bHex& flipBits();
      int adjust( int& );
   
      bool operator==( const bHex& );
      bool operator!=( const bHex& );
      //~ bool operator&( const bHex& );
      const bHex operator&( const bHex& );
      const bHex operator|( const bHex& );
      const bHex operator^( const bHex& );
      
      bool operator==( const ulong );
      bool operator!=( const ulong );
      bool operator&( const int );
      
      bool operator&( const ulong );

      void assign( const ulong, int );
      void filter( const ulong, int );
      void remove( const ulong, int );
      void compare( const bHex & );
      bool empty();
      void erase();

      int size() const;
      void resize();
      void resize( int );
      void print( FILE* =(stdout) );
      void _printHex( ulong, FILE* =(stdout) );
      
      ulong getRow( int );
      int getNumFlip();
      int* getActive();
      //~ void findNumFlip();
      //~ void findActive();
      static void getActive( ulong, int [] );
      
      static void setupHammingTable();
      static int calculateHammingWeight( int );
      static int getHammingWeight( ulong );
      int getHammingWeight();
   
   protected:
      
   private:
      int size_;
      int numBits_;
      int numFlip_;

      uhex hex_;
      int* active_;

      // flags
      bool haveActive_;
      bool haveNumFlip_;
      bool isVerified_;
};



#endif
