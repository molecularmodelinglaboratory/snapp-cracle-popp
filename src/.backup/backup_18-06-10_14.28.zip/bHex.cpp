#include <stdio.h>
#include "bHex.h"
using namespace std;
using namespace bStd;

unsigned int bHex::hamming_[65536]; // 16-bit hamming table
bool bHex::isHamRdy_;

/* Constructors */
/* default */
bHex::bHex() : size_( 0 ), numBits_(0), numFlip_(0), hex_(NULL), active_(NULL) {
   this->resize(0);
   this->isVerified_ = false;
   this->haveActive_ = false;
   this->haveNumFlip_ = false;
}

/* somewhat default */
bHex::bHex(int nB) : size_( 0 ), numBits_(0), numFlip_(0), hex_(NULL), active_(NULL) {
   //~ this->numBits_ = s;
   this->resize(nB);
   this->isVerified_ = false;
   this->haveActive_ = false;
   this->haveNumFlip_ = false;
}


/* deep copy constructor */
bHex::bHex( const bHex &h ) : size_( 0 ), numBits_(0), numFlip_(0), hex_(NULL), active_(NULL) {
   this->size_ = h.size_;
   this->numBits_ = h.numBits_;
   this->numFlip_ = h.numFlip_;
   
   this->hex_ = (h.size_ == 0) ? NULL : new ulong[h.size_];
   //~ this->active_ = )h.numFlip_ == 0) ? NULL : new int[h.numFlip_];
   
   for( int i=0; i < h.size_; ++i ) {
      this->hex_[i] = h.hex_[i];
   }
   
   this->isVerified_ = false;
   this->haveActive_ = false;
   this->haveNumFlip_ = false;
   this->getActive();
   //~ for( int i=0; i < h.numFlip_; ++i ) {
      //~ this->active_[i] = h.active_[i];
   //~ }
}

/* Destructor */
bHex::~bHex() {
   delete [] this->hex_;
   this->hex_ = NULL;
   delete [] this->active_;
   this->active_ = NULL;
}

/* Assignment operators [Copy] */
bHex& bHex::operator=( const bHex &rhs ) {
   if( this == &rhs ) { return *this; }
   
   delete [] this->hex_;
   this->hex_ = NULL;
   
   delete [] this->active_;
   this->active_ = NULL;
   
   this->size_ = rhs.size_;
   this->numBits_ = rhs.numBits_;
   this->numFlip_ = rhs.numFlip_;
   
   this->hex_ = rhs.size_ == 0 ? NULL : new ulong[rhs.size_];
   //~ this->active_ = rhs.numFlip_ == 0 ? NULL : new int[rhs.numFlip_];
   
   for( int i=0; i < rhs.size_; ++i ) {
      this->hex_[i] = rhs.hex_[i];
   }
   
   this->isVerified_ = false;
   this->haveActive_ = false;
   this->haveNumFlip_ = false;
   this->getActive(); 
   return *this;
}
void bHex::erase() {
   //~ if( this->empty() ) { return; }
   //~ printf("b4 erase: "); print();
   for( int i=0; i < this->size_; ++i ) { this->hex_[i] &= 0x0; }
   this->numFlip_ = 0;
   delete [] this->active_;
   this->active_ = NULL;
   this->haveActive_ = false;
   this->haveNumFlip_ = false;
   this->isVerified_ = false;
   //~ printf("after: ");print(); printf("\n");
   return;
}

bHex& bHex::operator=( const int rhs ) {
   this->erase();
   if( rhs != 0 ) {
      int n = rhs;
      int section = this->adjust( n );
      ulong translator = 1;
      translator <<= n; // *
      this->hex_[section] |= translator;
   }
   
   this->isVerified_ = false;
   return *this;
}
/* OR ASSIGNMENT operator 
   Flips a single bit at location 'n'. Allows access to higher order
   bits without a full function
*/
bHex& bHex::operator|=( const int rhs ) {
   int n = rhs;
   int section = this->adjust( n );
   
   ulong translator = 1;
   translator <<= n; // *
   this->hex_[section] |= translator;
   
   this->isVerified_ = false;
   return *this;
}

bHex& bHex::operator|=( const bHex& rhs ) {
   if( this == &rhs ) { return *this; }
   int size = this->size_ > rhs.size_ ? rhs.size_ : this->size_;
   for( int i=0; i < size; ++i )
      this->hex_[i] |= rhs.hex_[i];
   
   this->isVerified_ = false;
   return *this;
}


/* AND ASSIGNMENT */
bHex& bHex::operator&=( const int rhs ) {
   int n = rhs;
   int section = this->adjust( n );
   
   ulong translator = 1;
   translator <<= n; // *
   this->hex_[section] &= translator;
   
   this->isVerified_ = false;
   return *this;
}

bHex& bHex::operator&=( const bHex& rhs ) {
   if( this == &rhs ) { return *this; }
   int size = this->size_ > rhs.size_ ? rhs.size_ : this->size_;
   for( int i=0; i < size; ++i ) {
      this->hex_[i] &= rhs.hex_[i];
   }
   this->isVerified_ = false;
   return *this;
}

/* XOR ASSIGNMENT */
bHex& bHex::operator^=( const int rhs ) {
   int n = rhs;
   int section = this->adjust( n );
   
   ulong translator = 1;
   translator <<= n; // *
   this->hex_[section] ^= translator;
   this->isVerified_ = false;
   return *this;
}

bHex& bHex::operator^=( const bHex& rhs ) {
   if( this == &rhs ) { return *this; }
   int size = this->size_ > rhs.size_ ? rhs.size_ : this->size_;
   for( int i=0; i < size; ++i ) {
      this->hex_[i] ^= rhs.hex_[i];
   }
   this->isVerified_ = false;
   return *this;
}

/* NOT ASSIGNMENT */
bHex& bHex::flipBits() {
   //~ if( this == &rhs ) { return *this; }
   for( int i=0; i < this->size_; ++i ) {
      this->hex_[i] = ~this->hex_[i];
   }
   this->isVerified_ = false;
   return *this;
}

/* ADJUST */
int bHex::adjust( int &adj ) {
   int section = 0;
   while( adj > 63 ) {
      adj -= 64;
      ++section;
   }
   return section;
}



/* Comparison operator */
bool bHex::operator==( const bHex &h ) {
   bool equal = false;
   if( this->size_ != h.size_ ) { return equal; }
   for( int i=0; i < this->size_; ++i ) {
      equal = ( this->hex_[i] == h.hex_[i] );
   }
   return equal;
}
bool bHex::operator!=( const bHex &h ) {
   return !( *this == h );
}

bool bHex::operator==( const ulong rhs ) {
   return (this->hex_[0] == rhs);
}
bool bHex::operator!=( const ulong rhs ) {
   return !( *this == rhs );
}

bool bHex::operator&( const bHex &h ) {
   int size = this->size_ > h.size_ ? h.size_ : this->size_;
   bool isSame = true;
   bool overall = true;
   for( int i=0; i < size; ++i ) {
      //~ ulong
      if( h.hex_[i] == 0 ) { continue; }
      isSame = this->hex_[i] & h.hex_[i];
      overall &= isSame;
   }
   return overall;
}

bool bHex::operator&( const ulong rhs ) {
   return this->hex_[0] & rhs;
}

bool bHex::operator&( const int num ) {
   int section = 0;
   int n = num;
   while( n > 63 ) {
      n -= 64;
      ++section;
   }
   
   
   ulong translator = 1;
   translator <<= n; // *
   return this->hex_[section] & translator;
}




int bHex::size() const {
   return this->numBits_; // tad confusing; meant to work with resize
}


/* OR
   -- Performs the expected | function by assigning multiple bits
   This implementation allows for higher order access
*/
void bHex::assign( const ulong num, int depth ) {
   if( num == 0 ) { return; }
   
   int section = adjust( depth );
   //~ int d = depth; // - 64 * section; // in adjust
   ulong n1 = num;
   ulong n2 = num;
   
   
   n1 <<= depth;
   this->hex_[section] |= n1;

   //~ this->print();
   //~ this->_printHex( num );
   //~ printf("\tdepth: %d\n", depth);
   
   if( depth != 0 ) {
      int rev = 64 - depth;
      n2 >>= rev;
      ++section;
      //~ printf("size: %d\tsection: %d\t%#lx\n", size_, section, this->hex_[section] );
      if( this->size_ >= section && n2 > 0 ) { this->hex_[section] |= n2; }
   }
   this->isVerified_ = false;
   return;
}

void bHex::filter( const ulong num, int depth ) {
   int section = adjust( depth );
   //~ int d = depth; // - 64 * section;
   ulong n1 = num;
   ulong n2 = num;
   
   int pre = 0;
   while( pre < section ) {
      this->hex_[pre] = 0;
      ++pre;
   }
   
   n1 <<= depth;
   this->hex_[section] &= n1;
   
   if( depth != 0 ) {
      int rev = 64 - depth;
      n2 >>= rev;
      this->hex_[++section] &= n2;
   }
   
   while( ++section < this->size_ ) {
      this->hex_[section] = 0;
   }
   this->isVerified_ = false;
   return;
}

void bHex::remove( const ulong num, int depth ) {
   int section = adjust( depth );
   //~ int d = depth - 64 * section;
   ulong n1 = num;
   ulong n2 = num;
   
   n1 <<= depth;
   this->hex_[section] |= n1;
   this->hex_[section] ^= n1;
   
   if( depth != 0 ) {
      int rev = 64 - depth;
      n2 >>= rev;
      this->hex_[++section] |= n2;
      this->hex_[++section] ^= n2;
   }
   this->isVerified_ = false;
   return;
}

/* Resize */
void bHex::resize( int needBits ) {
   if( this->numBits_ >= needBits ) { return; } // don't resize if we don't need to

   int numSec = 1;
   while( needBits > 63 ) {
      needBits -= 64;
      ++numSec;
   }

   if( this->hex_ == NULL ) {
      this->hex_ = new ulong[numSec];
      for(int i=0; i < numSec; ++i) { this->hex_[i] = 0x0; }
   }
   else {
      bHex t(*this);
      delete [] this->hex_; // fixed this with a new copy constructor
      delete [] this->active_;
      this->hex_ = NULL;
      this->active_ = NULL;

      this->hex_ = new ulong[numSec];
      for( int i=0; i < t.size_; ++i ) { this->hex_[i] = t.hex_[i]; }

      //~ this->findActive();
      //~ this->active_ = new int[this->numFlip_];
      //~ for( int i=0; i < t.numFlip_; ++i ) {
         //~ this->active_[i] = t.active_[i];
      //~ }
      
   }

   this->numBits_ = 64 * numSec; // do we need a last used?
   --this->numBits_; // last index
   this->size_ = numSec;

   this->isVerified_ = false;
   return;
}

/* Compare */
void bHex::compare( const bHex &h ) {
   //~ int size = this->size_ > h.size_ ? h.size_ : this->size_;
   bool isSame = true;
   bool overall = true;
   for( int i=0; i < size_; ++i ) {
      if( h.hex_[i] == 0 ) { continue; }
      printf( "this: %d: %#18lx\t", i, this->hex_[i] );
      this->_printHex( this->hex_[i] );
      printf("\n");
      
      printf( "cmpr: %d: %#18lx\t", i, h.hex_[i] );
      this->_printHex( h.hex_[i] );
      
      isSame = this->hex_[i] & h.hex_[i];
      overall &= isSame;
      printf( "\t& %u\n", isSame );
   }
   
   printf( "overall: %u\n\n", overall );
   return;
}


/* Empty */
bool bHex::empty() {
   for( int i=0; i < this->size_; ++i ) {
      if( this->hex_[i] != 0 ) {
         return false;
      }
   }
   return true;
}

/* Print */
void bHex::print( FILE* op ) {
   if(!isHamRdy_) { setupHammingTable(); }
   for( int i=0; i < this->size_; ++i ) {
      if( this->hex_[i] == 0 ) { continue; }
      fprintf(op,  "%d: %#18lx\t", i, this->hex_[i] );
      this->_printHex( this->hex_[i], op);
      fprintf(op, "\n");
   }
   
   return;
}

void bHex::_printHex( ulong t, FILE* op ) {
   int amt = 64;
   
   while(t && amt > 0) {
      int cnt = bHex::getHammingWeight( t );
      --t;
      cnt -= bHex::getHammingWeight( t );
      cnt *= -1;
      cnt += 2; // +2 to account for the space needed for '1'
      fprintf(op, "%0*d",cnt,1);
      t >>= cnt;
      amt -= cnt;
   }
   
   if( amt > 0 ) {
      fprintf(op, "%0*d",amt,0);
   }
   
   return;
}



/* Count Number of Flipped Bits */
int bHex::getNumFlip() {
   if( this->isVerified_ && this->haveNumFlip_ ) { return this->numFlip_; }
   int flipped = 0;
   for( int i=0; i < this->size_; ++i) {
      flipped += getHammingWeight( this->hex_[i] );
   }
   this->numFlip_ = flipped;
   
   this->haveNumFlip_ = true;
   this->isVerified_ = true;
   return this->numFlip_;
}

bHex::ulong bHex::getRow( int i ) {
   return this->hex_[i];
}

/* List Active
>> Description
   Returns a reference to an array listing the active indices
*/
int* bHex::getActive() {
   if( this->isVerified_ && this->haveActive_ ) { return this->active_; }
   if(!isHamRdy_) { setupHammingTable(); }
   if( this->active_ != NULL ) {
      delete [] this->active_;
      this->active_ = NULL;
   }

   if( this->getNumFlip() == 0 ) { return NULL; }
   this->active_ = new int[ this->numFlip_ ];
   
   // find all positions
   int pos = 0;
   for( int i=0; i < this->size_; ++i ) {
      ulong t = this->hex_[i];
      int correction = i*64;
      while(t) {
         int cnt = bHex::getHammingWeight( t ); // num of ones
         ulong init = t; // save old value of t
         --t;        // flip bits up to and incl lowest
         cnt -= bHex::getHammingWeight( t ); // recount
         cnt *= -1;  // get positive
         ++cnt;      // increment for position
         t &= init;  // erase previous
         
         this->active_[pos] = cnt + correction;
         ++pos;
      }
   }
   
   this->isVerified_ = true;
   this->haveActive_ = true;
   return this->active_;
}

void bHex::getActive( ulong ul, int active[] ) {
   if(!isHamRdy_) { setupHammingTable(); }
   int pos = 0;
   while( ul ) {
      int cnt = bHex::getHammingWeight( ul ); // num of ones
      ulong init = ul; // save old value of t
      --ul;        // flip bits up to and incl lowest
      cnt -= bHex::getHammingWeight( ul ); // recount
      cnt *= -1;  // get positive
      ++cnt;      // increment for position
      ul &= init;  // erase previous
      
      active[pos] = cnt;
      ++pos;
   }
   return;
}

/* Setup Hamming Table
>> Description
   If we can store a lookup table of the hamming function of every 16 bit integer, we can do the following to compute the Hamming weight of every 32 bit integer.
      static unsigned char wordbits[65536] = { bitcounts of ints between 0 and 65535 };
      static int popcount( unsigned int i )
      {
          return( wordbits[i&0xFFFF] + wordbits[i>>16] );
      }
*/
void bHex::setupHammingTable() {
   register int a = 65536;
   for(int i =0; i<a; ++i) {
      bHex::hamming_[i] = calculateHammingWeight(i);
   }
   bHex::isHamRdy_ = true;
   return;
}

/*	Calculate Hamming Weight */
int bHex::calculateHammingWeight(int x) {
   int i=0;
   while(x) {
      x &= x-1;
      ++i;
   }
   return i;
}

/*	Get Hamming Weight for 64 bit numbers */
int bHex::getHammingWeight(unsigned long x) {
   int weight = 0;
   for(int i=0; i<4 && x > 0; ++i) {
      weight += bHex::hamming_[int(x & 0xFFFF)];
      x >>= 16;
   }
   return weight;
}

int bHex::getHammingWeight() {
   this->numFlip_ = 0;
   for( int i=0; i < this->size_; ++i) {
      this->numFlip_ += getHammingWeight( this->hex_[i] );
   }
   return this->numFlip_;
}




/* EOF */


