#include <deque>
#include <fstream>
#include <sstream>
#include <string>
#include <string.h>
#include <stdio.h>
#include "bCentroid.h"
#include "bDelTess.h"
#include "bAA.h"
#include "bSys.h"
using namespace std;
using namespace bStd;

std::deque<float>  bCentroid::centroids;
std::deque<string> bCentroid::residues;
std::deque<uint>   bCentroid::residuesPos;
std::deque<uint>   bCentroid::chainPos;
std::deque<uint>   bCentroid::chainSize;

bCentroid::bCentroid() {
   
}
bCentroid::bCentroid( char base[], char path[] ) {
   strcpy( this->fileBase_, base );
   strcpy( this->filePath_, path );
}
bCentroid::bCentroid( const bCentroid &rhs ) {
   
}

bCentroid::~bCentroid() {
   
}

void bCentroid::setSrc( char base[], char path[] ) {
   strcpy( this->fileBase_, base );
   strcpy( this->filePath_, path );
   return;
}

bool bCentroid::pdb2Centroids() { return pdb2Centroids( this->fileBase_, this->filePath_ ); }
bool bCentroid::pdb2Centroids( char fileBase[], char filePath[], char pathOut[] ) {


   // Open the file
   ifstream ip;
   char* file = new char[96];
   strcpy( file, filePath );
   strcat( file, fileBase );
   //~ if( memcmp( file + strlen(file) - 4, ".pdb", 4 ) != 0 ) strcat( file, ".pdb" );
   printf("[bC] file: %s\n", file);
   //~ ip.open(file, ifstream::in);
   //~ if(!ip) { throw "[bCentroid] Bad file."; return false; }

   // Print centroids
   bool haveCent = _pdb2Centroids( fileBase, filePath );

   if( haveCent ) {
      //~ printf("have centroids\n");

      if( pathOut != NULL ) {
         strcpy( file, pathOut );
         strcat( file, fileBase );
         if( memcmp( file + strlen(file) - 4, ".pdb", 4 ) != 0 ) strcat( file, ".pdb" );
      }

      int size = strlen(file);
      memmove( file + size - 4, ".out", 4 );
      FILE* op = fopen( file, "w" );
      for( uint i=0; i < centroids.size(); ++i ) {
         fprintf( op, "%.3f ", centroids[i] );
         ++i; fprintf( op, "%.3f ", centroids[i] );
         ++i; fprintf( op, "%.3f\n", centroids[i] );
      }
      fclose( op );
      
      // Print sequence
      memmove( file + size - 4, ".seq", 4 );
      op = fopen( file, "w" );
      for( uint i=0; i < residues.size(); ++i ) {
         fprintf( op, "%s %d\n", residues[i].c_str(), residuesPos[i] );
      }
      fclose( op );
   }

   delete [] file;
   file = NULL;
   return haveCent;
}

bool bCentroid::pdb2Centroids( bPoints** &chainPtr, int &numChain, char fileBase[], char filePath[] ) {
   bool haveCent = _pdb2Centroids( fileBase, filePath );
   if( haveCent ) {
      numChain = chainSize.size();
      chainPtr = new bPoints*[ numChain ];
      uint cX = 0;
      uint pX = 0;
      for( int i=0; i < numChain; ++i ) {
         chainPtr[i] = new bPoints;
         float pntSave[ 3 * chainSize[i] ];
         char  seqSave[ chainSize[i] + 1 ];
         pX = 0;
         for( uint k=0; k < chainPos[i]; ++k ) {
            pntSave[pX] = centroids[cX];
            pntSave[++pX] = centroids[++cX];
            pntSave[++pX] = centroids[++cX];
            ++pX; ++cX;
            //~ memmove( ugh, residues[k].c_str
            seqSave[k] = bAA::aa3to1( residues[k].c_str() );
         }
         chainPtr[i]->addPoints( pntSave, chainSize[i] );
         chainPtr[i]->setSeq( seqSave );
      }
   }

   return haveCent;
}

bool bCentroid::_pdb2Centroids( char fileBase[], char filePath[] ) {
   centroids.clear();
   residues.clear();
   residuesPos.clear();
   chainPos.clear();
   chainSize.clear();

   // Make sure the path works
   char* file = new char[96];
   strcpy( file, filePath );
   strcat( file, fileBase );
   if( ! bSys::fileExists( file ) ) {
      strcat( file, ".pdb" );
      if( ! bSys::fileExists( file ) ) { throw "[bC::pdb2C] Invalid File."; return false; }
   }
   //~ if( memcmp( file + strlen(file) - 4, ".pdb", 4 ) != 0 ) strcat( file, ".pdb" );

   // Open the file
   ifstream ip;
   ip.open(file, ifstream::in);
   if(!ip) { throw "[bCentroid] Bad file."; return false; }

   // Storage
   //~ deque<float>  centroids;
   //~ deque<string> residues;
   //~ deque<uint>   residuesPos;
   //~ deque<uint>   chainPos;
   //~ deque<uint>   chainSize;
   string        bffr;

   // Read (in order)
   string type;
   int    posAtom;
   string atom;
   string res;
   char   chain;
   int    posRes;
   float  coord[3] = { 0.0, 0.0, 0.0 };

   // Data handling
   float  centr[3] = { 0.0, 0.0, 0.0 };
   int    prevPos = 0;
   bool   prevCa = false;
   bool   prevCCarbonyl = false;
   int    cntAtom = 0;
   char   currChain = '\0';
          //~ numChain = 0;
   uint   numRes = 0;

   // Line by line
   for( uint i = 0; getline( ip, bffr ); ++i ) { 
      istringstream ss( bffr );

      // Skip unless it's an atom
      ss >> type;
      if( type.compare("ATOM") ) { continue; }

      // Read up to coordinates
      ss >> posAtom;
      ss >> atom;
      ss >> res;
      ss >> chain;
      ss >> posRes;

      // Check for backbone N (new residue, handle at Ca)
      if( !atom.compare("N") && posRes != prevPos ) {
         prevPos = posRes;
         //~ printf("\t\tNITROGEN!\n");
         continue;
      }

      // Check for C-alpha (new residue!)
      else if( !atom.compare("Ca") || !atom.compare("CA") ) {
         //~ printf("\t\tALPHA CARBON!");

         // Check for new chain
         if( chain != currChain ) {
            if( currChain != '\0' ) {
               chainPos.push_back( residues.size() );
               chainSize.push_back( numRes );
               numRes = 0;
               //~ ++chain;
            }
            currChain = chain;
         }

         // Save the residue
         ++numRes;
         residues.push_back( res );
         residuesPos.push_back( posRes );
         prevCa = true;

         if( cntAtom != 0 ) {
            // Calculate the centroid, save, & reset
            centr[0] /= cntAtom;
            centr[1] /= cntAtom;
            centr[2] /= cntAtom;
            centroids.push_back( centr[0] );
            centroids.push_back( centr[1] );
            centroids.push_back( centr[2] );
            centr[0] = 0.0;
            centr[1] = 0.0;
            centr[2] = 0.0;
            cntAtom = 0;
         }
      }

      // Check for backbone C
      else if( !atom.compare("C") && prevCa ) {
         prevCa = false;
         prevCCarbonyl = true;
         //~ printf("\t\tCARBONYL!\n");
         continue;
      }

      // Check for backbone C
      else if( !atom.compare("O") && prevCCarbonyl ) {
         prevCCarbonyl = false;
         //~ printf("\t\tCARBONYL!\n");
         continue;
      }

      // Ignore extra carboxylate atom
      else if( !atom.compare("OXT") ) {
         continue;
      }

      else {}
      //~ printf("\n");

      // Weight
      float weight = 1.0;

      // Save the coordinates
      cntAtom += weight;
      ss >> coord[0];
      ss >> coord[1];
      ss >> coord[2];
      coord[0] *= weight;
      coord[1] *= weight;
      coord[2] *= weight;

      centr[0] += coord[0];
      centr[1] += coord[1];
      centr[2] += coord[2];
   }
   ip.close();

   // Save last centroid
   if( numRes != 0 ) {
      chainPos.push_back( residues.size() );
      chainSize.push_back( numRes );
   }


   if( cntAtom != 0 ) {
      // Calculate the centroid, save, & reset
      centr[0] /= cntAtom;
      centr[1] /= cntAtom;
      centr[2] /= cntAtom;
      centroids.push_back( centr[0] );
      centroids.push_back( centr[1] );
      centroids.push_back( centr[2] );
   }

   return (centroids.size() > 0) ? true : false;
}


uint bCentroid::dt2Centroids( bDelTess &dt ) {

   //~ deque<float> centroids;
   centroids.clear();
   float centroid[3] = { 0.0, 0.0, 0.0 };
   for( uint i=0; i < dt.simplex_.size(); ++i ) {
      if( dt.skip( i ) ) { continue; }

      centroid[0] = dt.simplex_[i].vrtx_[1];
      centroid[0] += dt.simplex_[i].vrtx_[6];
      centroid[0] += dt.simplex_[i].vrtx_[11];
      centroid[0] += dt.simplex_[i].vrtx_[16];

      centroid[1] = dt.simplex_[i].vrtx_[2];
      centroid[1] += dt.simplex_[i].vrtx_[7];
      centroid[1] += dt.simplex_[i].vrtx_[12];
      centroid[1] += dt.simplex_[i].vrtx_[17];

      centroid[2] = dt.simplex_[i].vrtx_[3];
      centroid[2] += dt.simplex_[i].vrtx_[8];
      centroid[2] += dt.simplex_[i].vrtx_[13];
      centroid[2] += dt.simplex_[i].vrtx_[18];

      centroid[0] /= 4;
      centroid[1] /= 4;
      centroid[2] /= 4;

      centroids.push_back( centroid[0] );
      centroids.push_back( centroid[1] );
      centroids.push_back( centroid[2] );
   }

   return centroids.size() / 3;
}

uint bCentroid::dt2Centroids( bDelTess &dt, bPoints* &tet ) {
   uint numCentroids = dt2Centroids( dt );

   // Save centroids
   if( tet == NULL ) { tet = new bPoints; }
   else { tet->clear(); }
   float pntSave[ 3 * numCentroids ];
   uint pX = 0;
   for( uint k=0; k < numCentroids; ++k ) {
      pntSave[pX] = centroids[pX]; ++pX;
      pntSave[pX] = centroids[pX]; ++pX;
      pntSave[pX] = centroids[pX]; ++pX;
   }
   tet->addPoints( pntSave, numCentroids );

   return numCentroids;
}

uint bCentroid::dt2Centroids( bDelTess &dt, char base[], char path[] ) {
   uint numCentroids = dt2Centroids( dt );

   // Print centroids
   char file[64];
   strcpy( file, path );
   strcat( file, base );
   strcat( file, "_CENTROIDS.out.test" );
   FILE* op = fopen( file, "w" );
   for( uint i=0; i < centroids.size(); ++i ) {
      fprintf( op, "%.4f ", centroids[i] );
      ++i; fprintf( op, "%.4f ", centroids[i] );
      ++i; fprintf( op, "%.4f\n", centroids[i] );
   }
   fclose( op );

   return numCentroids;
}


