#include <valarray>
#include <deque>
//~ #include <map>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "bHex.h"
#include "bPoints.h"
#include "bSimplex.h"
#include "bDelTess.h"
#include "bSort.h"
#include "MersenneTwister.h"

#include "bDocker.h"

using namespace std;
using namespace bStd;

/****** Constructor */

/* Default */
bDelTess::bDelTess() {
   this->simplex_.resize(0);
   this->infPt_.resize( 12 );

   this->isVerified_ = false;
   this->isSlim_ = false;
   this->isTrim_ = false;
   this->haveEdge_ = false;
   this->haveType_ = false;

   doDebug_ = false;
   if( doDebug_ ) debug_ = fopen("debug.txt", "w");
}

/* Copy */
bDelTess::bDelTess( const bDelTess &bdt ) {
   infPt_.resize( 12 );
}

/* Destructor */
bDelTess::~bDelTess() {

   // self
   vrtx_.clear();
   simplex_.clear();
   simplID_.clear();
   edges_.clear();

   // sources
   src_ = NULL;
   infPt_.resize(0);
   toAdd_.clear();

   // Information (constantly changing)
   currPt_.resize(0);
   newID_.clear();
   newList_.clear();
   hullID_.clear();
   open_.clear();

   // debugging
   invalidS_.clear();
   invalidP_.clear();
   removed_.clear();
   removedWhen_.clear();
   if( doDebug_ ) fclose( debug_ );
}

/**/
/****** Internal */
/* Set Source [bPoints] */
void bDelTess::setSrc( bPoints &ptSrc ) {
   this->src_ = &ptSrc;
   if( !(this->src_->haveMM_) ) { this->src_->_findMinMax(); }

   // Resize appropriately
   int size = this->src_->numPnts_;
   toAdd_.resize( size );
   size += 4;
   this->edges_.resize( size * size );

   // setup points at 'infinity' and add infty pts to vrtx
   // four lower points on a cube
   int max = this->src_->max_[0];
   if( max < this->src_->max_[1] ) { max = this->src_->max_[1]; }
   if( max < this->src_->max_[2] ) { max = this->src_->max_[2]; }
   max = max * 2.5;
   for( int i=0; i < 3; ++i ) {
      infPt_[(i+1)*3+i] = max;
      this->vrtx_.push_front( -1 * (i+1) );
   }
   this->vrtx_.push_front( -4 );

   return;
}

/* Uses the Mersenne Twister algorithm to get a random number
   -- uses the nextInt method from Java to constrain w/in [0-range]
*/
int bDelTess::getRandomNumber( const int range ) {
   if(range <= 0) { // check range...we could let it be lower than zero; just adjust
      return -1;
   }

   if((range & -range) == range) { // re[ar]range
      return (int)((range*(long)rndNum_.randInt()) >> 31);
   }

   int bits = 0; // put in range...longer implementation
   int val = 0;
   do {
      bits = rndNum_.randInt();
      val = bits % range;
   } while(bits - val + (range-1) < 0);

   return val;
}

/* Randomize Point Order */
void bDelTess::randomizePts() {
   rndNum_.seed((unsigned int)time(NULL)); // seeds the Mersenne Twister RNG
   
   // create unaltered point list
   deque<short> ptList( this->src_->numPnts_ );
   for( int i=0; i < this->src_->numPnts_; ++i ) { ptList[i] = i; }
   
   // generate random numbers and add index 
   int rndm = 0;
   int last = this->src_->numPnts_ - 1;
   for( int i=0; i < this->src_->numPnts_ - 1; ++i ) {
      rndm = this->getRandomNumber( last );
      while( rndm > (int)ptList.size() ) { rndm = this->getRandomNumber( last ); }
      if( i > (int)toAdd_.size() ) { printf("[toAdd] i too big: %d > %ld\n", i, toAdd_.size() ); exit(1); }
      toAdd_[i] = ptList[rndm];
      ptList.erase( ptList.begin() + rndm );
      --last;
   }
   
   toAdd_.back() = ptList.front();
   
   return;
}

/**/
/****** Simplex Handling */
/* Add */
int bDelTess::addSimplex( const int pt[] ) {
   // pt holds the indexes as listed by vrtx_, not src_

   // SIMPLEX :: variables
   bHex id( this->src_->numPnts_ );
   //~ valarray<bool> msk( this->src_->pnts_.size() );
   vaf ptSet( 12 );

   // Mask points to be included
   // Save points at infinity at the end
   // Create the simplex ID
   int index = 0;
   int start = 0;
   for(int i=0; i < 4; ++i ) {
      id |= pt[i];
      if( pt[i] > 3 ) { // i.e., not an infinity point
         index = vrtx_[ pt[i] ] * 3;
         start = i * 3;
         for( int k=0; k < 3; ++k ) { ptSet[start + k] = this->src_->pnts_[index + k]; }
      }
      else { // special handling for infinity points
         index = pt[i] * 3;
         ptSet[ slice( i * 3, 3, 1 ) ] = this->infPt_[ slice( index, 3, 1 ) ];
      }
   }

   // Create the simplex
   bSimplex s;
   try { s.setup( ptSet ); }
   catch( const char *e ) { throw e; }

   // Add to data structures
   int pos = 0;
   if( this->open_.empty() ) { // add a new simplex if no open spots
      pos = this->simplex_.size();
      this->simplex_.push_back( s );
      this->simplID_.push_back( id );
   }
   else { // overwrite an old simplex
      pos = this->open_.front();
      this->simplex_[ this->open_.front() ] = s;
      this->simplID_[ this->open_.front() ] = id;
      this->simplex_[ this->open_.front() ].id_ = this->open_.front();
      this->open_.pop_front();
   }

   return pos;
}

int bDelTess::addSimplex( bHex &id ) {
   int *plist = id.getActive();
   int pos;
   try{ pos = this->addSimplex( plist ); }
   catch( const char* e ) { throw e; }
   this->isVerified_ = false;
   return pos;
}

/* Remove */
void bDelTess::delSimplex( const int pos ) {
   // Debugging
   this->removed_.push_back( this->simplex_[pos] );
   int i = this->vrtx_.size() - 1;
   this->removedWhen_.push_back( i );
   
   // Clear
   this->open_.push_back( pos );
   this->simplID_[pos] = 0; // Clear ID
   --bSimplex::count_;
   for( int i=0; i < 4; ++i ) { // Remove all references to this simplex
      if( this->simplex_[pos].nghbr_[i] != NULL ) {
         for( int k=0; k < 4; ++k ) {
            if( this->simplex_[pos].nghbr_[i]->nghbr_[k] == &(this->simplex_[pos]) ) {
               this->simplex_[pos].nghbr_[i]->nghbr_[k] = NULL;
               k = 4;
            }
            else {}
         }
      }
      this->simplex_[pos].nghbr_[i] = NULL;
   }
   return;
}

/* Tessellate */
void bDelTess::tessellate() {
   printf("[bDelTess] Tessellating protein...\n");

   // Reset simplex counter
   bSimplex::count_ = 0;
   
   // Create first simplex
   bSimplex tet;
   int pts[4] = { 0, 1, 2, 3 };
   this->addSimplex( pts );
   
   // Prep
   this->currPt_.resize( 3 );
   this->resetHandlers();

   // Add each point
   bool isValid = true;
   while( !this->toAdd_.empty() ) {

      // Reset if we had a bad run...it happens...eventually I fix it
      if( !isValid ) {
         isValid = true;
         while( this->vrtx_.size() > 4 ) {
            this->toAdd_.push_back( this->vrtx_.back() );
            this->vrtx_.pop_back();
         }
         this->clear();
      }
      
      // Declare
      this->vrtx_.push_back( this->toAdd_.front() );
      this->toAdd_.pop_front();

      // Debug -- print current point
      //~ printf("Adding point %3lu...%d\n", this->vrtx_.size(), this->vrtx_.back() );
      if(doDebug_) fprintf(debug_, "Adding point...%d\n", this->vrtx_.back() );

      // Reset Handlers
      try {
         this->checkPoint( this->vrtx_.size() - 1 );
         status();
         //~ this->immunize();
         this->resetHandlers();
         this->newList_.clear();
         if(doDebug_) fprintf(debug_, "\n");
      }
      catch( const char *e ) { printf("%s\n\tRetrying...", e); isValid = false; }
   } // end while loop

   //~ this->findEdges();
   return;
}

/* Check All Simplexes Against Single Point */
void bDelTess::checkPoint( int ptId ) {
   if(doDebug_) fprintf(debug_, "checkPoint %d (%d)\n",ptId,vrtx_[ptId]);
   this->currPtId_ = ptId;
   for( int i=0; i < 3; ++i ) { this->currPt_[i] = this->src_->pnts_[ ( i + (this->vrtx_[ptId]*3) ) ]; }
   for( uint i=0; i < this->simplex_.size(); ++i ) {
      if( this->simplID_[i].empty() ) { continue; } // deleted simplex (open)
      if( this->simplID_[i] & this->currPtId_ ) { continue; } // simplex uses point
      
      if(doDebug_) fprintf(debug_, "\tloop: cP simplex[%d]\n", i);
      
      int isIn = this->simplex_[i].inSphere( this->currPt_ );
      if( isIn == 1 ) {} // outside
      else if( isIn == 0 || isIn == -1 ) {
         try{ 
            this->outbreak( NULL, &(this->simplex_[i]) );
            this->treat();
         }
         catch( const char *e ) { throw e; }
         break; // should have found all sick simplexes
      }
      else {}
   }
   return;
}

/* Check All Points Against Single Simplex */
void bDelTess::checkSimplex( bSimplex &sx ) {
   if(doDebug_) fprintf(debug_, "checkSimplex %d\n",sx.id_);
   vaf pt( 3 );
   for( uint i=4; i < this->vrtx_.size(); ++i ) {
      if( this->simplID_[ sx.id_ ] & (int)i ) { continue; } // simplex uses point
      this->currPtId_ = i;

      fprintf(debug_, "\tloop: cS point %d (%d) from %d\n",i,this->vrtx_[i], sx.id_);
      fprintf(debug_, "current pt: %d\nvrtx: %d\nnum pts: %d\n", i, this->vrtx_[i], this->src_->numPnts_);

      for( int k=0; k < 3; ++k ) { this->currPt_[k] = this->src_->pnts_[ ( k + this->vrtx_[i] ) ]; }
      int isIn = sx.inSphere( this->currPt_ );
      if( isIn == 1 ) {} // outside
      else if( isIn == -1 || isIn == 0 ) {
         throw "[checkSimplex] we do need the immunization\n";
         try {
            this->outbreak( NULL, &(sx) );
            this->treat();
         }
         catch( const char *e ) { throw e; }
         break; // if infected, it'll already be deleted
      }
      else {}
   }
   return;
}

/* Outbreak */
void bDelTess::outbreak( bSimplex *prev, bSimplex *curr ) {
   if(prev == NULL) {
      if(doDebug_) fprintf(debug_, "outbreak NULL-> %d\n", curr->id_);
   }
   else {
      if(doDebug_) fprintf(debug_,"outbreak %d -> %d\n", prev->id_, curr->id_);
   }
   if( this->sick_ & curr->id_ ) { return; }

   this->sick_ |= curr->id_;
   int numNull = 0;
   for( int i=0; i < 4; ++i ) { // check neighbors
      if(doDebug_) fprintf(debug_, "\tloop: outbreak neighbor %d",i);

      // Check simplex validity
      if( curr->nghbr_[i] == NULL ) {
         if(doDebug_) fprintf(debug_, " (NULL)\n");
         if( numNull > 0 ) {
            bHex test( this->simplID_[ curr->id_ ] );
            test.filter( (ulong)0xF, 0 );
            if( test.getNumFlip() < 4 ) {
               throw "[outbreak] Too many null neighbors.";
            }
         }
         else {
            try{ this->infectedHull( curr ); }
            catch( const char * e ) { throw e; }
            ++numNull;
         }
         continue;
      } // no neighbor
      else if( curr->nghbr_[i] == prev ) {
         if(doDebug_) fprintf(debug_, "(prev)\n");
         continue;
      } // previous simplex
      else{}
         
      if(doDebug_) fprintf(debug_, " (%d)\n",curr->nghbr_[i]->id_);

      // Check simplex point containment
      int isIn = curr->nghbr_[i]->inSphere( this->currPt_ );
      if( this->simplID_[ curr->nghbr_[i]->id_ ] & this->currPtId_ ) {
         isIn = 0;
      }

      // Check
      if( isIn == 1 ) { 
         try{ this->noInfection( curr, curr->nghbr_[i] ); }
         catch( const char * e ) { throw e; }
      } // outside
      else if( isIn == -1 || isIn == 0 ) {
         try{ this->outbreak( curr, curr->nghbr_[i] ); }
         catch( const char * e ) { throw e; }
      } // inside | edge
      else {} // shouldn't get here
   } // end neighbor loop

   return;
}

/* Infected Hull */
void bDelTess::infectedHull( bSimplex *curr ) {
   if(doDebug_) {
      fprintf(debug_, "infectedHull: %d\n", curr->id_);
      simplID_[ curr->id_ ].print( debug_);
   }
   
   bHex similarity( this->simplID_[ curr->id_ ] ); // copy the infected id
   similarity.filter( (ulong)0xF, 0 ); // identify hull points (infinity points)
   similarity |= this->currPtId_; // add current point
   if( similarity.getNumFlip() < 4 ) {
      throw "[infectedHull] Will create invalid simplex.";
   } // throw if we don't have a simplex
   else if( similarity.getNumFlip() == 5 ) {
      for( int i=0; i < 4; ++i ) {
         similarity ^= i;
         this->newID_.push_back( similarity );
         similarity |= i;
      }
   } // handle the very first simplex
   else {
      this->newID_.push_back( similarity ); // add to list to create
   } // typical handling
   return;
}

/* No Infection */
void bDelTess::noInfection( bSimplex *prev, bSimplex *curr ) {
   if(doDebug_) fprintf(debug_, "noInfection (%d -> %d, %d)\n", prev->id_, curr->id_, currPtId_);
   this->well_ |= curr->id_;
   bHex similarity( this->simplID_[ prev->id_ ] ); // copy previous id
   similarity &= this->simplID_[ curr->id_ ]; // identify common points
   similarity |= this->currPtId_; // add the current point
   if( similarity.getNumFlip() != 4 ) {
      throw "[noInfection] Will create invalid simplex.";
   } // throw if we don't have a simplex
   this->newID_.push_back( similarity ); // add to list to create
   return;
}

/* Treat */
void bDelTess::treat() {
   if(doDebug_) fprintf(debug_, "treat\n");
   try{
      this->addNewSimplexes();
      this->removeSimplexes();
      this->identifyNeighbors();
   }
   catch( const char *e ) { throw e; }
   return;
}

/* Add Simplexes in NewID */
void bDelTess::addNewSimplexes() {
   if(doDebug_) fprintf(debug_, "addNewSimplexes\n");
   bool isCoPlanar = false;
   for( uint i=0; i < this->newID_.size(); ++i ) {
      int pos;
      try { pos = this->addSimplex( this->newID_[i] ); }
      catch( const char *e ) {
         isCoPlanar = true;
         this->newList_.push_back( pos );
         break;
      }
      this->newList_.push_back( pos );
      if(doDebug_) fprintf(debug_, "\tloop: add %d (%d)\n",i, pos);
   }
   
   // If co-planar, reset
   if( isCoPlanar ) {
      for( int k=0; k < (int)this->newList_.size(); ++k ) {
         this->delSimplex( this->newList_[k] );
      } // remove each newly-added simplex
      this->toAdd_.push_back( this->vrtx_.back() ); // place point at end of list
      this->vrtx_.pop_back(); // remove from cu
      throw "[addNewSimplexes] Found co-planar simplex and removed iteration.";
   }
   return;
}

/* Remove Sick Simplexes */
void bDelTess::removeSimplexes() {
   if(doDebug_) fprintf(debug_, "removeSimplexes\n");
   int *sick = this->sick_.getActive();
   int sickFlip = this->sick_.getNumFlip();

   // Nullify sick simplexes
   for( int i=0; i < sickFlip; ++i ) {
      if(doDebug_) fprintf(debug_, "\tloop: remove %d (%d)\n",i, sick[i]);
      this->delSimplex( sick[i] );
   }
   sick = NULL;
   return;
}

/* Identify Neighbors for New Simplexes */
void bDelTess::identifyNeighbors() {
   if(doDebug_) fprintf(debug_, "identifyNeighbors\n");
   
   // Get array
   int *well = this->well_.getActive();
   int wellFlip = this->well_.getNumFlip();

   // Point to neighbors
   for( uint i=0; i < this->newList_.size(); ++i ) {
      if(doDebug_) fprintf(debug_, "LOOP: neighbor %d (%d)\n",i, newList_[i]);
      
      int nghbrCnt = 0;
      bHex similarity( this->simplID_[ this->newList_[i] ] );
      if(doDebug_) fprintf(debug_, "neighboring %d\n",this->newList_[i]);
      
      // Check for neighbors amongst other new simplexes
      if(doDebug_) fprintf(debug_, "SICK\n");
      for( uint k=(i + 1); k < this->newList_.size() && nghbrCnt < 4; ++k ) {
         
         if(doDebug_) {
            fprintf(debug_, "\tloop: neighbors %d - %d\n", newList_[i], newList_[k]);
         }
         
         similarity &= this->simplID_[ this->newList_[k] ]; // find common points
         if( similarity.getNumFlip() == 3 ) {
            if(doDebug_) {
               simplID_[ newList_[i] ].print( debug_ );
               similarity.print( debug_ );
               simplID_[ newList_[k] ].print( debug_ );
                  fprintf(debug_, "\tmatch!\n");
            }
            while( this->simplex_[ this->newList_[i] ].nghbr_[ nghbrCnt ] != NULL ) { ++nghbrCnt; }
            this->simplex_[ this->newList_[i] ].nghbr_[ nghbrCnt ] = &( this->simplex_[ this->newList_[k] ] );
            ++nghbrCnt;
            for( int m=0; m < 4; ++m ) {
               if( this->simplex_[ this->newList_[k] ].nghbr_[m] == NULL ) {
                  this->simplex_[ this->newList_[k] ].nghbr_[m] = &(this->simplex_[ this->newList_[i] ]);
                  m = 4;
               } // save neighbor in empty slot
            } // loop through neighbor's neighbors
         } // three common points
         similarity = this->simplID_[ this->newList_[i] ]; // reset similarity
      }
      
      // Check for neighbors amongst existing simplexes
      if(doDebug_) fprintf(debug_, "WELL\n");
      for( int k=0; k < wellFlip && nghbrCnt < 4; ++k ) {

         if(doDebug_) {
            fprintf(debug_, "\tloop: neighbors %d - %d\n", newList_[i], well[k]);
         }

         similarity &= this->simplID_[ well[k] ]; // find common points
         if( similarity.getNumFlip() == 3 ) { 
            if(doDebug_) {
               simplID_[ newList_[i] ].print( debug_ );
               similarity.print( debug_);
               simplID_[ well[k] ].print( debug_ );
               fprintf(debug_, "\tmatch!");
            }
            while( this->simplex_[ this->newList_[i] ].nghbr_[ nghbrCnt ] != NULL ) { ++nghbrCnt; }
            this->simplex_[ this->newList_[i] ].nghbr_[ nghbrCnt ] = &( this->simplex_[ well[k] ] );
            for( int m=0; m < 4; ++m ) {
               if(doDebug_) fprintf(debug_, " (%d -> %d, %d)=", newList_[i], well[k],m);
               if( this->simplex_[ well[k] ].nghbr_[m] == NULL ) {
                  this->simplex_[ well[k] ].nghbr_[m] = &(this->simplex_[ this->newList_[i] ]);
                  if(doDebug_) fprintf(debug_, " NULL, %d; ", simplex_[ well[k] ].nghbr_[m]->id_);
                  m = 4;
               } // save neighbor in empty slot
               else {
                  if(doDebug_) fprintf(debug_, " %d; ", simplex_[ well[k] ].nghbr_[m]->id_);
               }
            } // loop through neighbor's neighbors
            if(doDebug_) fprintf(debug_, "\n");
            ++nghbrCnt;
         } // three common points
         similarity = this->simplID_[ this->newList_[i] ]; // reset similarity
      }
   } // end neighbors

   well = NULL;
   return;
}


/* Immunize */
void bDelTess::immunize() {
   if(doDebug_) fprintf(debug_, "immunize\n");
   // Checks the validity of all new simplexes (and repairs)
   while( ! this->newList_.empty() ) {
      if(doDebug_) fprintf(debug_, "\tloop: immunizing %d\n", this->newList_.front() );
      this->resetHandlers();
      this->checkSimplex( this->simplex_[ this->newList_.front() ] );
      this->newList_.pop_front(); // remove checked simplex
      this->reconcile( this->newList_, this->sick_ ); // remove newly deleted
   } // check every new simplex -- even those just made here
   return;
}

/* Reconcile First List */
void bDelTess::reconcile( dei &list, bHex &toRemove ) {
   int *removal = toRemove.getActive();
   int numRemove = toRemove.getNumFlip();
   for( int i=0; i < numRemove; ++i ) {
      for( uint k=0; k < list.size(); ++k ) {
         if( list[k] == removal[i] ) {
            list.erase( list.begin() + k );
         }
      }
   }
}

/* Reset Handlers */
void bDelTess::resetHandlers() {
   int multiplier = this->vrtx_.size() > 80 ? 10 : 6;
   int newSize = this->vrtx_.size() * multiplier;
   this->sick_.resize( newSize );
   this->well_.resize( newSize );
   this->sick_ = 0;
   this->well_ = 0;
   this->newID_.clear();
   this->hullID_.clear();
   return;
}

void bDelTess::validateTet( dei &toValRef ) {
   dei toVal( toValRef );
   vaf test( 3 );
   this->resetHandlers();
   printf("num sick: %d\n", this->sick_.getNumFlip() );
   for( int i=0; i < (int)toVal.size(); ++i ) {
      if( skip( i ) ) { continue; }
      printf("validating [%d]\n",toVal[i]);
      for( int k=0; k < (int)this->vrtx_.size() - 1; ++k ) {
         if( this->simplID_[i] & (k) ) { continue; } // is point in simplex?
         for( int z=0; z < 3; ++z ) { this->currPt_[z] = this->src_->pnts_[ ( z + this->vrtx_[k] ) ]; }
         int isInside = this->simplex_[ toVal[i] ].inSphere( this->currPt_ );
         if( isInside != 1 ) {
            try{ this->outbreak( NULL, &this->simplex_[toVal[i]] ); }
            catch( const char * e ) { throw e; }
         }
      }
   }
   printf("num sick: %d\n", this->sick_.getNumFlip() );
   
   if( this->sick_.getNumFlip() > 0 ) {
      try{ this->addNewSimplexes(); } // add new simplexes
      catch( int e ) { printf("crap...\n"); } // throws an error if coplanar
      this->removeSimplexes(); // remove sick simplexes
      this->identifyNeighbors(); // find new and border simplex neighbors
   }
   
   return;
}

bool bDelTess::isNew( bSimplex *curr ) {
   return !(this->sick_ & curr->id_);
   return true;
}

/* Find Edges */
void bDelTess::findEdges() {

   if( !(this->edges_.empty()) ) { this->edges_.clear(); }

   bHex edge( this->vrtx_.size() );
   for( uint i=0; i < this->vrtx_.size(); ++i ) {
      this->edges_.push_back( edge );
   } // initialize edges

   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { continue; }

      bHex currID( this->simplID_[i] ); // save ID (temp)
      int *active = currID.getActive(); // get points
      if( currID.getNumFlip() < 4 ) { currID.print(); throw "[bDelTess] Found simplex with out enough bits flipped."; }
      for( uint k=0; k < 4; ++k ) {
         currID ^= active[k]; // remove current point
         this->edges_[ active[k] ] |= currID; // save
      }// loop through points
      active = NULL;
   } // loop through all ids

   // Not needed if we don't include infinity tetrahedra
   //~ for( uint i=0; i < this->edges_.size(); ++i ) {
      //~ this->edges_[i].remove( (uint)0xF, 0 );
   //~ } // remove infinity points

   this->haveEdge_ = true;
   return;
}


/* Verify Tessellation */
bool bDelTess::verify() {
   if( this->isVerified_ ) { return true; }
   printf("[bDelTess] Verifying tessellation...\n");
   if(doDebug_) fprintf(debug_, " -- VERIFICATION -- \n");
   bool validTess = true;

   // Test simplex validity
   bool missingPoints = false;
   bool validSimplex = true;
   //~ vaf test( 3 );
   float test[3] = { 0.0, 0.0, 0.0 };
   bHex missingPt( this->simplID_[0] );
   for( uint i=0; i < this->simplex_.size(); ++i ) {
      if( this->simplID_[i].empty() ) { continue; } // is this a dead simplex?
      if( this->simplID_[i] & (bHex::ulong)0xF ) { continue; } // does it have infty pnts?

      missingPt |= this->simplID_[i]; // accumulate points to test for missing

      for( uint k=4; k < this->vrtx_.size(); ++k ) {
         if( this->simplID_[i] & (int)k ) { continue; } // is point in simplex?

         for( int z=0; z < 3; ++z ) { test[z] = this->src_->pnts_[ ( z + this->vrtx_[k] * 3 ) ]; }
         short inSph = this->simplex_[i].inSphere( test );

         if( inSph == 1 ) { validSimplex= true; }
         else if( inSph == -1 ) {
            printf("\t>> simplex [%d] pt (%d:%d) inside", i, k, this->vrtx_[k]);
            if(doDebug_) fprintf(debug_, " >> simplex [%d] pt (%d:%d) inside", i, k, this->vrtx_[k]);
            validSimplex = false;
         }
         else if( inSph == 0 ) {
            printf("\t>> simplex [%d] on edge ", i);
            if(doDebug_) fprintf(debug_, " >> simplex [%d] on edge ", i);
            validSimplex = false;
         }
         else { printf("\tscrewed"); }

         if( !validSimplex ) {
            validTess = false;
            k = this->vrtx_.size();
            this->invalidS_.push_front( i );
            this->invalidP_.push_front( this->vrtx_[k] );
            printf("\t-- INVALID POINT [%d] -- \n", this->invalidP_.back() );
            if(doDebug_) fprintf(debug_, " -- INVALID POINT [%d] -- \n", this->invalidP_.back() );
         }
      } // point loop
   } // simplex loop
   
   // Find missing points
   missingPt.assign( (ulong)0xF, 0 );
   missingPt.flipBits();

   // List the missing
   int *mP = missingPt.getActive();
   int nF = missingPt.getNumFlip();
   for( int i=0; i < nF; ++i ) {
      if( mP[i] > (int)(this->vrtx_.size() - 1) ) { i = nF; }
      else {
         missingPoints = true;
         printf("\t>> point [%d,%d] not included in any simplexes\n",i,this->vrtx_[ mP[i] ]);
         fprintf(debug_, ">> point [%d,%d] not included in any simplexes\n",i,this->vrtx_[ mP[i] ]);
         this->invalidP_.push_back( this->vrtx_[ mP[i] ] );
      }
   }
   mP = NULL;

   validTess &= !missingPoints;

   if( validTess ) { this->isVerified_ = true; }
   else { printf("hmmm...not being validated...\n"); }
   return validTess;
}

/****** To Work With */

void bDelTess::removeExcess() {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   if( this->isSlim_ ) { return; }
   
   printf("[bDelTess] Removing empty and invalid simplexes...\n");
   bool remove;
   uint pos = 0;
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      remove = false;
      if( this->simplID_[i].empty() ) { remove = true; }
      else if( this->simplID_[i] & (bHex::ulong)0xF ) { remove = true; }
      else { continue; }

      if( remove ) {
         if( pos == i ) { continue; }
         this->simplex_[i] = this->simplex_[pos];
         this->simplID_[i] = this->simplID_[pos];
         this->delSimplex( pos );
         ++pos;
      }
   }

   while( this->simplID_.front().empty() ) {
      this->simplID_.pop_front();
      this->simplex_.pop_front();
   }

   this->haveType_ = false;
   this->isSlim_ = true;
   return;
}

void bDelTess::trim( float threshold ) {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   if( this->isTrim_ ) { return; }
   if( this->src_->isInRes_ ) { threshold /= this->src_->res_; }

   printf("[bDelTess] Trimming long edges...\n");
   int nPt = this->src_->numPnts_;
   vector< vector< float > > dist( nPt, vector<float>( nPt, 0.0 ) );
   float pRef[3];
   float pCmp[3];

   // Measure pt distance in all vertices
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { continue; }

      int* list = this->simplID_[i].getActive();
      for( int y=0; y < 4; ++y ) {
         for( int z=(y+1); z < 4; ++z ) {
            int yP = this->vrtx_[ list[y] ];
            int zP = this->vrtx_[ list[z] ];

            if( dist[ yP ][ zP ] == 0.0 ) {
               int yX = yP * 3;
               int zX = zP * 3;
               for( int m=0; m < 3; ++m ) {
                  pRef[m] = this->src_->pnts_[yX+m];
                  pCmp[m] = this->src_->pnts_[zX+m];
               } // EXTRACT point coordinates
               dist[yP][zP] = bPoints::pointDistance( pRef, pCmp ); 
            } // TEST if distance calculated

            if( dist[yP][zP] > threshold ) {
               this->delSimplex( i );
               y = 4;
               z = 4;
            } // DELETE simplex if edges are too long
         } // LOOP upper diagonal
      } // LOOP through vertices
   } // LOOP through simplexes
   
   this->isTrim_ = true;
   this->isSlim_ = false;
   return;
}

void bDelTess::findType() {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   if( this->haveType_ ) { return; }
   if( !(this->simplTy_.empty()) ) { this->simplTy_.clear(); }
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { this->simplTy_.push_back( -1 ); continue; }
      this->simplTy_.push_back( this->findType( i ) );
   }
   this->haveType_ = true;
   return;
}

/* Type of Tetrahedral */
int bDelTess::findType( int pos ) {
   if( this->haveType_ && this->isVerified_ ) { return this->simplTy_[pos]; }
   
   int* list = this->simplID_[pos].getActive();
   int* plist = new int[4];
   int type = 0;

   /* convert to pt pos */ plist[0] = this->vrtx_[ list[0] ];
                           plist[1] = this->vrtx_[ list[1] ];
                           plist[2] = this->vrtx_[ list[2] ];
                           plist[3] = this->vrtx_[ list[3] ];
                           bSort::qsort( plist, 4 );

   bool consec = false;
   for( int i=0; i < 3; ++i ) { // loop through all but the last
      int t = plist[i]; // store current value
      ++t;            // increment the index
      if( consec && t == plist[i+1] ) { // check for doubly consecutive indices
         type += 2;
         consec = false;
      }
      else if( t == plist[i+1] ) { // check for consecutive indices
         ++type;
         consec = true;
      }
      else { // not consecutive
         consec = false;
      }
   }

   delete [] plist;
   plist = NULL;
   return type;
}

/****** Checking */
bool bDelTess::skip( int pos ) {
   if( this->isSlim_ && this->isVerified_ ) { return false; }
   else if( this->simplID_[pos].empty() ) { return true; }
   else if( this->simplID_[pos] & (bHex::ulong)0xF ) { return true; }
   else {}
   return false;
}

/****** Output */

/* Print Tetrahedral Composition */
void bDelTess::printTetByRes( FILE* op ) {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   printf("[bDelTess] Printing tetrahedrals by residue...\n");

   if( !this->haveType_ ) { this->findType(); }

   char* aaList = new char[5];
   aaList[4] = '\0';
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { continue; }

      int* list = this->simplID_[i].getActive();
      aaList[0] = this->src_->aaSeq_[this->vrtx_[list[0]]];
      aaList[1] = this->src_->aaSeq_[this->vrtx_[list[1]]];
      aaList[2] = this->src_->aaSeq_[this->vrtx_[list[2]]];
      aaList[3] = this->src_->aaSeq_[this->vrtx_[list[3]]];
      bSort::qsort( aaList, 4 );

      fprintf(op, "%s %d\n", aaList, this->simplTy_[i] );
   }
   delete [] aaList;
   aaList = NULL;
   return;
}

void bDelTess::printTetByPos( FILE* op ) {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   printf("[bDelTess] Printing tetrahedrals by sequence position...\n");
   int* plist = new int[4];
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { continue; }

      int* list = this->simplID_[i].getActive();
      plist[0] = this->vrtx_[list[0]];
      plist[1] = this->vrtx_[list[1]];
      plist[2] = this->vrtx_[list[2]];
      plist[3] = this->vrtx_[list[3]];
      bSort::qsort( plist, 4 );
      fprintf(op, "%d %d %d %d\n", 
         plist[0],
         plist[1],
         plist[2],
         plist[3] );
   }
   delete [] plist;
   plist = NULL;
   return;
}

/* PyMol */
void bDelTess::pymolDelTess( FILE* op, char name[], char color[] ) {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }

   bool printEdges = true,  printInvalid = false,
        printValid = false, printRemoved = false,
        printInfinity = false;
   //~ if( doDebug_ ) {
      //~ printValid = true;
      //~ printInvalid = true;
      //~ printRemoved = true;
   //~ }

   //~ char colorRed[5] = "ruby";
   char colorG90[7] = "gray90";
   char colorG40[7] = "gray40";
   char colorBlu[5] = "blue";
   char colorGre[6] = "green";

   //~ char* name = new char[13];

   //~ bDocker::_pymolHeader( op, 1 );
   //~ strcpy(name,"tessellation");
   bPoints::_pymolPseudoatoms( op, src_->pnts_, src_->numPnts_, name, color );
   fprintf( op, "cmd.orient(\"%s\")\n",name );

   // Print points causing invalid simplexes
   for( int m=0; m < (int)this->invalidP_.size(); ++m ) {
      fprintf(op, "cmd.show(\"dots\",\"%s////p%d\")\n", name, this->invalidP_[m] );
   }

   /* Print Invalid */ if( printInvalid ) {
      printf("Printing invalid simplexes...\n");
      for( int m=0; m < (int)this->invalidS_.size(); ++m ) { // print invalid
         strcpy(name, "nS");
         this->simplex_[ this->invalidS_[m] ].pymolSimplex( op, name, colorBlu );
         this->simplID_[ this->invalidS_[m] ] = 0;
      }
   }

   /* Print Edges */ if( printEdges ) {
      printf("[bDelTess] Printing edges for pymol...\n");
      this->pymolEdges( op, name, color );
   }

   /* Print Simplexes */ if( printValid ) {
      printf("Printing valid simplexes [%ld]...\n", this->simplex_.size() );
      for( uint i=0; i < this->simplex_.size(); ++i ) { // print only valid
         if( skip( i ) ) { continue; }
         strcpy(name, "vS");
         this->simplex_[i].pymolSimplex( op, name, colorG40 );
      }
   }

   /* Print Infinity */ if( printInfinity ) {
      printf("Printing infinity simplexes...\n");
      for( uint i=0; i < this->simplex_.size(); ++i ) { // print only infinity simplexes
         if( skip( i ) ) { continue; }
         strcpy(name, "iS");
         this->simplex_[i].pymolSimplex( op, name, colorG90 );
      }
   }

   /* Print Removed */ if( printRemoved ) {
      printf("Printing removed simplexes [%ld,%ld]...\n", this->removed_.size(), this->removedWhen_.size() );
      for( int m=0; m < (int)removed_.size() ; ++m ) {
         strcpy(name, "rS");
         this->removed_[m].pymolSimplex( op, name, colorGre );
         fprintf(op, "cmd.disable(\"%s%d\")\n", name, this->removed_[m].id_);
      }
   }

   //~ delete [] name;
   //~ printf("done\n");
   return;
}

/* PyMol Edges */
void bDelTess::pymolEdges( FILE* op, char name[], char color[] ) {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   for( uint i=4; i < this->edges_.size(); ++i ) {
      int *active = this->edges_[i].getActive();
      for( int k=0; k < this->edges_[i].getNumFlip(); ++k ) {
         fprintf(op,"cmd.bond(\"%s////p%d\",\"%s////p%d\")\n",
            name, this->vrtx_[i],
            name, this->vrtx_[ active[k] ] );
      }
   }
   fprintf(op,"cmd.color(\"%s\",\"%s\")\n", color, name ); // color the simplex

   return;
}


void bDelTess::clear() {
   // self
   vrtx_.clear();
   simplex_.clear();
   simplID_.clear();
   edges_.clear();

   // Information (constantly changing)
   currPt_.resize(0);
   newID_.clear();
   newList_.clear();
   hullID_.clear();
   open_.clear();

   // debugging
   invalidS_.clear();
   invalidP_.clear();
   removed_.clear();
   removedWhen_.clear();
   if( doDebug_ ) fclose( debug_ );
}

/****** DEBUG */
void bDelTess::status() {
   if(!doDebug_) return;

   fprintf(debug_, "\n-- STATUS :: overall --\n");
   for( int i=0; i < (int)this->simplex_.size(); ++i ) {
       fprintf(debug_, "%d:", this->simplex_[i].id_);
      if( this->simplID_[i].empty() ) {  fprintf(debug_, "NULL\n"); }
      else {
         this->simplID_[i].print( debug_ );
         for( int k=0; k < 4; ++k ) {
             fprintf(debug_, "\tnghbr: ");
            if( this->simplex_[i].nghbr_[k] == NULL ) {
                fprintf(debug_, "NULL\n");
            }
            else {
               int nid = this->simplex_[i].nghbr_[k]->id_;
                fprintf(debug_, "%d | %d => ", nid, this->simplex_[i].nghbr_[k]->id_);
               for( int m = 0; m < 4; ++m ) {
                  if( this->simplex_[nid].nghbr_[m] == NULL ) {
                      fprintf(debug_, "NULL, ");
                  }
                  else {
                      fprintf(debug_, "%d, ", (this->simplex_[nid].nghbr_[m]->id_));
                  }
               }
                fprintf(debug_, "\n");
            }
         }
      }
   }  fprintf(debug_, "\n");
   // ~DEBUG
}

void bDelTess::status( int s ) {
   if(!doDebug_) return;
   
   fprintf(debug_, "\n--STATUS :: simplex [%d:%d]-- \n", s, this->simplex_[s].id_);
   this->simplID_[s].print( debug_ );
   this->simplex_[s].print( debug_ );
   for( int k=0; k < 4; ++k ) {
      fprintf(debug_, "\tnghbr: ");
      if( this->simplex_[s].nghbr_[k] == NULL ) {
         fprintf(debug_, "NULL\n");
      }
      else {
         fprintf(debug_, "%d => ", this->simplex_[s].nghbr_[k]->id_);
         int nid = this->simplex_[s].nghbr_[k]->id_;
         for( int m = 0; m < 4; ++m ) {
            if( this->simplex_[nid].nghbr_[m] == NULL ) {
               fprintf(debug_, "NULL, ");
            }
            else {
               fprintf(debug_, "%d, ", (this->simplex_[nid].nghbr_[m]->id_));
            }
         }
         fprintf(debug_, "\n");
      }
   }
   fprintf(debug_, " ----\n");
   return;   
}