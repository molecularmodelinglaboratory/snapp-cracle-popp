#ifndef BCENTROID_H
#define BCENTROID_H

#include "bDelTess.h"

namespace bStd { class bCentroid; };

class bStd::bCentroid {
   typedef unsigned int uint;
   
   private:
      char fileBase_[64];
      char filePath_[64];

   public:
      bCentroid();
      bCentroid( char[], char[] );
      bCentroid( const bCentroid & );
      ~bCentroid();
   
      void setSrc( char[], char[] );
   
      bool pdb2Centroids();
      static bool pdb2Centroids( char[], char[] );
   
      void dt2Centroids( bDelTess & );
      static void dt2Centroids( char[], char[], bDelTess & );

};

#endif

