#ifndef BGRID_H
#define BGRID_H

#include <vector>
#include <valarray>
#include <fstream>
using namespace std;


class bGrid {
public:
	// Construct | Destruct
	bGrid();
	~bGrid();

   void readProtein(char*);
   void translateProtein();

   void printProtein();
   void printProtein(ostream &);

   void initializeGrid();
   void initializeExclusion();
   void initializeInclusion();
	void initializeStamp(int,std::valarray<unsigned long long>&, std::vector< valarray<size_t> >&);


	float pointDistance(valarray<float>&,valarray<float>&);

	void excludePoints();
	void includePoints();
	void stampPoints(int,std::valarray<unsigned long long>&, std::vector< valarray<size_t> >&,std::valarray<unsigned long long>&);

	void print3dExcl(ostream&);
	void print3dIncl(ostream&);
	void print3dGrid(ostream&,valarray<unsigned long long>&,int);
	void print3dGrid(ostream&,valarray<unsigned long long>&,int,int);

	void printSingleHex(ostream&,unsigned long long&,int);

	void printPyMol();
	void saveFilename(char*);

	/*
	bGrid(float,float,float);


   // Protein
   void readProtein(char*);
   void readProtein(char*,valarray<float>&);
   void rezeroProtein();

   // Grid
   void initializeGrid();

   */

protected:
private:

	char *prtFile_;

   float min_[3];
   float max_[3];
   std::valarray<float> prt_;
   int residueCount_;

   std::valarray<unsigned long long> grd_;
   std::valarray<unsigned long long> tmp_;
   std::valarray<unsigned long long> exc_;
   std::valarray<unsigned long long> inc_;

   float res_;
   float fit_;
   float thk_;

	std::vector< valarray<size_t> > exsl_;
	std::vector< valarray<size_t> > insl_;

};


#endif

