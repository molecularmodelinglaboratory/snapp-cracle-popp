#include <stdio.h>
#include <string.h>
#include <ctime>
#include <cmath>
#include <stdlib.h>
#include "bDocker.h"
#include "bGrid.h"
#include "bPoints.h"
#include "bDelTess.h"
#include "MersenneTwister.h"
using namespace std;
using namespace bStd;

#define PI 3.14159265

const char* bDocker::usage() {
   string usage = "[Usage] griddock.e -p [pdb code] [options]\n";
   usage += "\t-d\t(data) pdb code, i.e., 1AWQ_alone or 1IFR\n";
   usage += "\t-p\t(path) default: ../../grid/\n\t-r\t(resolution) grid spacing; default: 0.5\u212B\n";
   usage += "\t-f\t(fit) grid proximity to protein; default: 4\u212B\n";
   usage += "\t-t\t(thickness) grid depth; default: 6\u212B\n";
   return usage.c_str();
}

/* */
/* Constructors and Destructors */
bDocker::bDocker() : makeMovie_(false) {
   // Set Flags
   haveGrd_ = false;
   havePrt_ = false;
   havePep_ = false;
   haveDT_ = false;

   rndNum_.seed((unsigned int)time(NULL)); // seeds the Mersenne Twister RNG
   pep_.resize(100);
   this->numConf_ = 0;
}
bDocker::~bDocker() {
   pep_.clear();
}

/* */
/* Handle Command Line Arguements */
bool bDocker::cla(int numArg, char** argArray) {
   
   // loop through all given parameters (i=1 to skip command)
   char* src = new char [64]; memset( src, '\0', 64 );
   char* pth = new char [64]; memset( pth, '\0', 64 );
   float param[3];
   for(int i=1; i<numArg; ++i) {
      // catches a filename...not the best
      // but this allows for no flags at all

      // check for a flag
      if(argArray[i][0] == '-') {
         switch(argArray[i][1]) {
            case 'd':
               strcpy( src, argArray[++i] );
               break;
            case 'p':
               strcpy( pth, argArray[++i] );
            case 'r':
               param[0] = atof(argArray[++i]);
               break;
            case 'f':
               param[1] = atof(argArray[++i]);
               break;
            case 't':
               param[2] = atof(argArray[++i]);
               break;
            default:
               (void)printf("\tUnknown parameter: '%s'\n\n",argArray[i]);
               throw usage();
               break;
         }
      }
      else if( i == 1 ) {
         strcpy( src, argArray[i] );
      }
      else {
         throw usage();
         //~ (void)printf("Usage: ./main.e [-i] <prot file> [<tet file>] [options]\n");
         //~ (void)printf("\tr: resolution [1.0,0.5]\n");
         //~ (void)printf("\tf: fit; defines exclusion radius\n");
         //~ (void)printf("\tt: thickness; defines thickness of grid\n\n");
         exit(1);
      }
   }

   try{ 
      if( pth == NULL ) { this->prt_.setSrc( src, pth ); }
      else { this->prt_.setSrc( src ); }
      this->grd_.setParam( param );
   }
   catch( const char* e ) { printf("%s\n",e); }
   
   delete [] src; src = NULL;
   delete [] pth; pth = NULL;

   return 1;
}


/* */
/* Do It All -- temporary Driver */
void bDocker::doItAll() {
   try{
   /* Grid */  this->grd_.setPointObject( this->prt_ );
   /* Prot */  this->havePrt_ = prt_.readPoints();
               prt_.setToDockingSpace();
   
   /* Grid */  this->grd_.initializeGrid();
               this->haveGrd_ = this->grd_.stampPoints();

   /* Tess */  this->dt_.setSrc( this->prt_ );
               this->dt_.randomizePts();

               this->dt_.tessellate();
               this->haveDT_ = this->dt_.verify();

               this->dt_.trim( 10.0 );
               this->dt_.removeExcess();
               this->dt_.findEdges();

               char name[64];
               strcpy( name, this->prt_.pntPath_ );
               strcat( name, this->prt_.pntBase_ );
               strcat( name, "_gdDT.del4" );
               FILE* op = fopen( name, "w" );
               this->dt_.printTetByPos( op );
               fclose( op );

               strcpy( name, this->prt_.pntPath_ );
               strcat( name, this->prt_.pntBase_ );
               strcat( name, "_gdDT.tet" );
               op = fopen( name, "w" );
               this->dt_.printTetByRes( op );
               fclose( op );

   /* Pep */   (void)printf("[bDocker] Generating random peptides...\n");
               float coordRestraints[3] = {0,120,0};
               int howMany = 500;
               int howLong = 8;
               this->initializePeptides( howMany, howLong );
               this->pepGrd_.overlay( this->grd_ ); // shallow copy
               this->havePep_ = this->generateChains( this->grd_, this->pep_, coordRestraints, howMany, howLong );

   /* Near */  test_.set2SameSpace( this->pep_[0] );
               findNearbyPoints( this->pep_[0], this->prt_, test_ );

   } // END try
   catch( const char* e ) { printf("%s\n",e); }

   this->printPyMol();
}

/* Set Peptide Size and Space */
void bDocker::initializePeptides( int nC, int nP ) {
   if( this->pep_.size() < (unsigned int)nC) { this->pep_.resize(nC); }
   for( int i=0; i < nC; ++i ) { this->pep_[i].sizeAndSpace( nP, this->prt_ ); }
   return;
}

/* */
/* FindNearbyPoints */
void bDocker::findNearbyPoints( bPoints &refPnts,  bPoints &searchPnts, bPoints &nearby ) {

   // Calculate the box dimensions
   refPnts._findMinMax();
   float ma[3], mi[3];
   for( int i=0; i < 3; ++i ) {
      mi[i] = refPnts.min_[i] - (refPnts.fit_ * 2);
      ma[i] = refPnts.max_[i] + (refPnts.fit_ * 2);
   }

   // Identify which points in the search space are nearby
   // -- Test bounds of each point (per axis) and save the index if valid
   deque<int> found;
   int index = 0;
   for( int i=0; i < searchPnts.numPnts_; ++i ) {
      bool isValid = true;
      index = i * 3;
      for(int k=0; k < 3 && isValid; ++k) {
         if( searchPnts.pnts_[index + k] > ma[k] ) { isValid = false; continue; }
         else if( searchPnts.pnts_[index + k] < mi[k] ) { isValid = false; continue; }
         else {}
         //~ ++index;
      } // loop axis
      if( isValid ) { found.push_back( i ); }
   } // loop points
   
   // Prepare nearby
   //~ printf("had: %d; found: %lu;\n",refPnts.numPnts_,found.size());
   nearby.resize( (refPnts.numPnts_ + found.size()) );
   //~ printf("nearby: %d | %d\n", nearby.numPnts_, nearby.capPnts_);

   // Save reference points
   nearby.addPoints( refPnts.pnts_, refPnts.numPnts_ );
   //~ printf("nearby: %d | %d\n", nearby.numPnts_, nearby.capPnts_);
   //~ for( i; i < refPnts.numPnts_ * 3; ++i ) {
      //~ nearby.pnts_[i] = refPnts.pnts_[i];
   //~ } // save refPnts to nearby

   // Save search points
   for( uint k=0; k < found.size(); ++k ) {
      //~ printf("%d) found %d\n",k,found[k]);
      int fpos = found[k] * 3;
      float npt[3];
      for( uint m=0; m < 3; ++m ) {
         npt[m] = searchPnts.pnts_[ fpos + m ];
         //~ printf("%.2f ~ %.2f\n", npt[m], searchPnts.pnts_[fpos + m]);
      } // loop axis
      nearby.addPoint( npt );
   } // loop points

   //~ printf("nearby: %d | %d\n", nearby.numPnts_, nearby.capPnts_);
   //~ bPoints::printPoints( nearby.pnts_, nearby.numPnts_ );
   return;
}


/* */
bool bDocker::generateChains(bGrid &g, std::vector<bPoints> &p, float sRestr[], int thisMany, int ofLength) {
   if( (thisMany + this->numConf_) > (int)p.size() ) {
      thisMany += numConf_;
      p.resize(thisMany);
   }
   else if(thisMany == -1) { thisMany = p.size(); }
   else { thisMany += numConf_; }

   int last = p[0].capPnts_ - 1;
   for( int i=this->numConf_; i < thisMany; ++i ) {
      int startPt = this->getRandomNumber(last) + 1; // random start point (non-index)
      generateRandomChain(g, p[i], sRestr, startPt);
      ++this->numConf_;
   }
   return true;
}
/* generate chain */
bool bDocker::generateRandomChain(bGrid &g, bPoints &p, float sRestr[], int startPt, int size) {
   if(size == -1) { size = p.capPnts_; } // default
   
   bool validPeptide = false;
   int count = 0;
   this->pepGrd_.setPointObject(p);
   this->pepGrd_.clearGrid();
   while(!validPeptide && count < 5000) {
      validPeptide = true; // set...this will change if the points fail
      p.clear(); // clear out the chain each time
      this->generateRandomGridPoint( g, pepGrd_, p, startPt ); // set initial random point

      // these two loops cover the entire chain
      // -- if point generation ever fails (i.e. not on grid w/in ~numIter)
      //    then we start over again
      for(int i=startPt+1; i<=size && validPeptide; ++i) {
         validPeptide = this->generateDisplacedRandomGridPoint( g, pepGrd_, p, i, sRestr );
      }
      for(int i=startPt-1; i>0 && validPeptide; --i) {
         validPeptide = this->generateDisplacedRandomGridPoint( g, pepGrd_, p, i, sRestr );
      }
      ++count;
   }
   //~ this->tempGrd_.push_back( this->pepGrd_ );

   return validPeptide;
}

/* Generate a random point on the grid */
bool bDocker::generateRandomGridPoint( bGrid &grd, bGrid &pgrd, bPoints &pep, int whichPoint ) {
   bool isValidPoint = false; // flag

   // randomly generate point until we get a hit
   int cnt = 0;
   float newPoint[3] = { 0, 0, 0 };
   while(!isValidPoint && cnt < 5000) {
      for(int i=0; i<3; ++i) { // randomly seed new coordinates
         newPoint[i] = this->getRandomNumber( grd.max_[i] - grd.buffer_ );
         newPoint[i] += grd.buffer_;
      }

      if( grd.isaGridPoint( newPoint ) ) { // check for validity
         isValidPoint = true;
         pep.addPoint( newPoint, whichPoint );
         pgrd._stampPoint( pgrd.fStmp_, newPoint );
      }
      ++cnt;
   }

   return isValidPoint;
}
/* Generate a Directed Random Point on the Grid
   -- note that sCoord represents [r,phi,psi]
   -- if only r!=0, assume any value of phi and psi work; use one previous point
   -- if only r!=0 && phi!=0, we assume any psi works; use two previous points
   -- not too sure what to do if given phi
*/
bool bDocker::generateDisplacedRandomGridPoint( bGrid &grd, bGrid &pgrd, bPoints &pep, int whichPoint, float sCoord[] ) {

   int capPoints = pep.capPnts_; // count number of points
   int newX = (whichPoint-1)*3; // get the point index

   // identify which direction previous points are from
   int direction = 1;

   if(whichPoint == capPoints) {
      direction = -1; // last point -- go backwards
   }
   else if(whichPoint == 1) {
      direction = 1; // first point - go forwards
   }
   else{
      int tmpIndex = newX - 3;
      int sum = pep.pnts_[ tmpIndex ];
      sum += pep.pnts_[ ++tmpIndex ];
      sum += pep.pnts_[ ++tmpIndex ];
      if( sum != 0.0 ) {
         direction = -1; // points behind -- go backwards
      }
      else {
         direction = 1; // points ahead -- go forwards
      }
      //~ else {
         //~ return generateRandomGridPoint(grd,pgrd,pnt,whichPoint); // no points...should not be here
         //~ // note: this assumes that we won't ever have a point at the origin
      //~ }
   }

   int orgX = newX + direction*3; // declare adjacent point indices
   int mrrX = newX + direction*6;

   bool have2ndPnt = false; // check for second adjacent point
   if( mrrX >= 0 && mrrX < (capPoints * 3) ) {
      float sum = pep.pnts_[mrrX] + pep.pnts_[mrrX + 1] + pep.pnts_[mrrX + 2];
      if( sum > 0.0 ) { have2ndPnt = true; }
   }

   float orgPnt[3] = { pep.pnts_[orgX], pep.pnts_[orgX + 1], pep.pnts_[orgX + 2] };
   float mrrPnt[3] = { 0, 0, 0 };
   float newPnt[3] = { 0, 0, 0 };

   if( have2ndPnt ) {
      mrrPnt[0] = pep.pnts_[mrrX]; // save point
      mrrPnt[1] = pep.pnts_[mrrX + 1];
      mrrPnt[2] = pep.pnts_[mrrX + 2];

      mrrPnt[0] -= orgPnt[0]; // translate to the origin
      mrrPnt[1] -= orgPnt[1];
      mrrPnt[2] -= orgPnt[2];
      bPoints::c2s( mrrPnt );
   }

   // set r restrictions
   if(!sCoord[0]) { sCoord[0] = ( grd.fit_ * 1.2); }

   // generate random angles until we get a valid point
   bool isValidPoint = false;
   int counter = 0;
   while(!isValidPoint && counter < 5000) {

      //~ printf("cnt: %d\n", counter);
      // set r
      newPnt[0] = sCoord[0];

      // set theta [-90,90]
      // -- we assume the adjacent point is at the origin
      // -- a second point is directly below (if we have it)
      // -- assumes the restriction is obtuse
      if(have2ndPnt && sCoord[1] != 0) { // restrict theta
         newPnt[1] = sCoord[1] - 90;
      }
      else { newPnt[1] = (float)(90 - this->getRandomNumber(180)); }
         // we don't have a second point, so randomly generate the spherical coordinates

      // set phi [-180,180]
      if(have2ndPnt && sCoord[2] != 0) { newPnt[2] = sCoord[2]; } // restrict phi
      else { newPnt[2] = (float)(180 - this->getRandomNumber(360)); }
         // we don't have a second point, so randomly generate the spherical coordinates

      bPoints::s2c( newPnt ); // convert spherical to cartesian

      if(have2ndPnt) { // rotate the coordinates if we need to (i.e. if we have a second point)
         bPoints::rotateTheta( newPnt, (90 + mrrPnt[1]) );
         bPoints::rotatePhi( newPnt, (-mrrPnt[2]) );
      }

      newPnt[0] += orgPnt[0];
      newPnt[1] += orgPnt[1];
      newPnt[2] += orgPnt[2];

      newPnt[0] = (int)newPnt[0];
      newPnt[1] = (int)newPnt[1];
      newPnt[2] = (int)newPnt[2];

      if( grd.isaGridPoint( newPnt ) && !pgrd.isaGridPoint(newPnt) ){ // check if the point is on the grid
         isValidPoint = true;
         pep.addPoint( newPnt, whichPoint );
         pgrd._stampPoint( pgrd.fStmp_, newPnt );
      }
      ++counter; // add one to bad point count
   }

   return isValidPoint;
}


/* Uses the Mersenne Twister algorithm to get a random number
   -- uses the nextInt method from Java to constrain w/in [0-range]
*/
int bDocker::getRandomNumber(int range) {
   if(range <= 0) { return -1; } // check range...we could let it be lower than zero; just adjust

   if((range & -range) == range) { // re[ar]range
      return (int)((range*(long)rndNum_.randInt()) >> 31);
   }

   int bits = 0; // put in range...longer implementation
   int val = 0;
   do {
      bits = rndNum_.randInt();
      val = bits % range;
   } while(bits - val + (range-1) < 0);

   return val;
}

/* */
/* Create PyMol Python Script */
void bDocker::printPyMol() {

   // Reset to normal space
   bPoints::setToNormalSpace(this->prt_);
   bPoints::setToNormalSpace(this->pep_,this->numConf_);

   // colors
   char colorPnk[5] = "pink";
   char colorRed[4] = "red";
   char colorOrg[7] = "orange";
   char colorMar[7] = "marine";

   // create the filename
   char *spdb = new char[64]; //(char*)malloc(sizeof(char)*64);
   char *sprt = new char[64]; //(char*)malloc(sizeof(char)*64);
   strcpy( spdb, this->prt_.pntPath_ );
   strcpy( sprt, this->prt_.pntPath_ );
   strcat( spdb, this->prt_.pntBase_ );
   strcat( sprt, this->prt_.pntBase_ );
   strcat( spdb, ".pdb" );
   strcat( sprt, "_grid.py" );
   (void)printf("[bDocker] Writing to: '%s'\n", sprt);

   // open the file and check
   FILE *op = fopen(sprt, "w");
   if(!op) {
      (void)printf("%s did not open!\n", sprt);
   }

   // Write header
   this->_pymolHeader(op,1);

   // Write pdb
   this->_pymolPdb(op,spdb);

   // Write origin
   this->_pymolOrigin(op);
   this->_pymolGridLines(op);

   /* Variables */   char *name = new char[64];
                     float size = 0.2;

   /* Protein */ if( this->havePrt_ && this->prt_.havePnts_ ) {
      strcpy(name,"proteins");
      bPoints::_pymolPoints( op, prt_.pnts_, prt_.numPnts_, name, colorRed, size );
   }

   /* Protein Centroids */ if( this->havePrt_ && this->prt_.haveTets_ ) {
      size = 0.1;
      strcpy(name,"centroids");
      bPoints::_pymolPoints( op, prt_.tets_, prt_.numTets_, name, colorPnk, size );//,color,size);
   }

   /* Tessellation */ if( this->haveDT_ ) {
      strcpy( name, "tessellation" );
      this->dt_.pymolDelTess( op, name, colorMar );
   }

   /* Grid */ if( this->haveGrd_ ) {
      strcpy(name,"grid");
      this->grd_._pymol3dGrid( op, name );
      (void)fprintf(op,"cmd.disable(\"%s\")\n",name);
   }

   /* Peptides */ if( this->havePep_ ) {
      for(int i=0; i<this->numConf_; ++i) {
         (void)sprintf(name,"peptide%d",i);
         bPoints::_pymolConnectedPseudoatoms( op, pep_[i].pnts_, pep_[i].numPnts_, name, colorOrg );
      }
   }

   // Movie -- Rotate!
   /* PyMol Movie */ if( this->makeMovie_ ) {
      this->_pymolMovie(op);
   }

   // Close the file handle
   //~ (void)fprintf(op,"cmd.clip(\"slab\",20)\n");
   //~ (void)fprintf(op,"cmd.hide(\"everything\",\"%s\")\n", this->prt_.pntBase_);
   fclose(op);
   
   delete [] spdb;
   delete [] sprt;
   delete [] name;

   // Run the command
   // ('cuz windows sucks...)
   //system("pymolwin -r \"D:\\My Dropbox\\grid\\1AWQ_alone_grid.py\"");
   return;
}

/* Write PyMol Header */
void bDocker::_pymolHeader(FILE* op,int white) {
   (void)fprintf(op,"from pymol import cmd\n");
   (void)fprintf(op,"from pymol.cgo import *\n");
   (void)fprintf(op,"\n");
   if(white) {
      (void)fprintf(op,"cmd.bg_color(\"white\")\n");
   }
   (void)fprintf(op,"\n");
   return;
}

/* Write PyMol PDB */
void bDocker::_pymolPdb(FILE* op,char* pdb) {
   (void)fprintf(op,"cmd.load(\"%s\")\n",pdb);
   (void)fprintf(op,"cmd.color(\"firebrick\", \"%s\")\n", this->prt_.pntBase_ );
   (void)fprintf(op,"cmd.hide(\"everything\", \"%s\")\n", this->prt_.pntBase_ );
   (void)fprintf(op,"cmd.show(\"cartoon\", \"%s\")\n", this->prt_.pntBase_ );
}

/* Write PyMol Origin */
void bDocker::_pymolOrigin(FILE* op) {
   float mi[3];
   float ma[3];
   for(int i=0; i<3; ++i) {
      mi[i] = grd_.min_[i]*grd_.res_ + prt_.planeDisplacement_[i];
      ma[i] = grd_.max_[i]*grd_.res_ + prt_.planeDisplacement_[i];
   }
   (void)fprintf(op,"orgn = [\n");
   (void)fprintf(op,"\tLINEWIDTH, 2.0,\n");
   (void)fprintf(op,"\tBEGIN, LINES,\n");
   (void)fprintf(op,"\tCOLOR, 0.2, 0.2, 0.2,\n");
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],mi[1],mi[2]);
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],mi[1],ma[2]);
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],mi[1],mi[2]);
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],ma[1],mi[2]);
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],mi[1],mi[2]);
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",ma[0],mi[1],mi[2]);
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",ma[0],mi[1],mi[2]);
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",ma[0],ma[1],mi[2]);
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],ma[1],mi[2]);
      (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",ma[0],ma[1],mi[2]);
   (void)fprintf(op,"\tEND\n");
   (void)fprintf(op,"\t]\n");
   (void)fprintf(op,"cmd.load_cgo(orgn,'orgn')\n");
   (void)fprintf(op,"cmd.disable(\"orgn\")\n");

   return;
}
/* Write PyMol Origin */
void bDocker::_pymolTrueOrigin(FILE* op, int max) {

   (void)fprintf(op,"orgn = [\n");
   (void)fprintf(op,"\tLINEWIDTH, 2.0,\n");
   (void)fprintf(op,"\tBEGIN, LINES,\n");
   (void)fprintf(op,"\tCOLOR, 0.0, 0.0, 0.0,\n");
      (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",0,0,0);
      (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",0,0,max);

   (void)fprintf(op,"\tCOLOR, 0.4, 0.4, 0.4,\n");
      (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",0,0,0);
      (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",0,max,0);

      (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",0,0,0);
      (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",max,0,0);
   (void)fprintf(op,"\tEND\n");
   (void)fprintf(op,"\t]\n");
   (void)fprintf(op,"cmd.load_cgo(orgn,'orgn')\n");

   return;
}
/* Write PyMol Grid */
void bDocker::_pymolGridLines(FILE* op) {
   int mi[3];
   int ma[3];
   for(int i=0; i<3; ++i) {
      mi[i] = grd_.min_[i]*grd_.res_ + prt_.planeDisplacement_[i];
      ma[i] = grd_.max_[i]*grd_.res_ + prt_.planeDisplacement_[i];
   }
   (void)fprintf(op,"gridLines = [\n");
   (void)fprintf(op,"\tLINEWIDTH, 1.5,\n");
   (void)fprintf(op,"\tBEGIN, LINES,\n");
   (void)fprintf(op,"\tCOLOR, 0.8, 0.8, 0.8,\n");
   int increment = 10;//*res_;
   for(int k=mi[1]; k<=ma[1];k=k+increment) {//ma[1]; ++k) {
      for(int i=mi[0]; i<=ma[0];i=i+increment) {//ma[0]; ++i) {
         for(int z=mi[2]; z<=ma[2];z=z+increment) {//ma[2]; ++z) {

            // extend in the z direction
            (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",i,k,mi[2]);
            (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",i,k,ma[2]);

            // extend in the x direction
            (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",mi[0],k,z);
            (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",ma[0],k,z);

            // extend in the y direction
            (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",i,mi[1],z);
            (void)fprintf(op,"\tVERTEX, %d, %d, %d, \n",i,ma[1],z);

         }
      }
   }
   //~ (void)fprintf(op,"\tCOLOR, 0.8, 0.8, 0.8,\n");
      //~ (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],mi[1],ma[2]);
      //~ (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],mi[1],mi[2]);
      //~ (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],ma[1],mi[2]);
      //~ (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],mi[1],mi[2]);
      //~ (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",ma[0],mi[1],mi[2]);
      //~ (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",ma[0],mi[1],mi[2]);
      //~ (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",ma[0],ma[1],mi[2]);
      //~ (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",mi[0],ma[1],mi[2]);
      //~ (void)fprintf(op,"\tVERTEX, %.2f, %.2f, %.2f, \n",ma[0],ma[1],mi[2]);
   (void)fprintf(op,"\tEND\n");
   (void)fprintf(op,"\t]\n");
   (void)fprintf(op,"cmd.load_cgo(gridLines,'gridLines')\n");
   (void)fprintf(op,"cmd.disable(\"gridLines\")\n");

   return;

}

/* Write PyMol Movie */
void bDocker::_pymolMovie(FILE* op) {
   // -- set up the frames
   (void)fprintf(op,"cmd.mclear()\n");

   // Rotate and zoom
   // Correct zoom depending on the grid size -- should always go just inside the grid
   (void)fprintf(op,"cmd.mset(\"1 x360\")\n");
   float zoom = ((grd_.max_[2] - grd_.min_[2])/2*11);
   zoom /= 240;

   // start out rotating
   (void)fprintf(op,"for i in range(0,60):\n");
   (void)fprintf(op,"\tcmd.mdo(i,'turn x,1; turn y,1; turn z,0')\n");

   // continue rotating; zoom in
   (void)fprintf(op,"for i in range(60,180):\n");
   (void)fprintf(op,"\tcmd.mdo(i,'turn x,1; turn y,1; turn z,0; move z,%.2f')\n",zoom);

   // continue rotating; zoom out
   (void)fprintf(op,"for i in range(180,300):\n");
   (void)fprintf(op,"\tcmd.mdo(i,'turn x,1; turn y,1; turn z,0; move z,-%.2f')\n",zoom);

   // continue rotating; no zoom
   (void)fprintf(op,"for i in range(300,360):\n");
   (void)fprintf(op,"\tcmd.mdo(i,'turn x,1; turn y,1; turn z,0')\n");
   
   // Rotate Y-axis
   (void)fprintf(op,"cmd.mset(\"1 x180\")\n");
   (void)fprintf(op,"for i in range(0,180):\n");
   (void)fprintf(op,"\tcmd.mdo(i,'turn y,2')\n");

   return;
}

/* Miscellaneous Options */
void bDocker::_pymolOptions(FILE *op) {
   //~ (void)fprintf(op,"cmd.clip(\"slab\",100)\n"); 
   return;
}
