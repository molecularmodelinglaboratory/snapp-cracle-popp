#include <deque>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "bAA.h"
#include "bHex.h"
#include "bPoints.h"
#include "bSimplex.h"
#include "bDelTess.h"
#include "bSort.h"
#include "MersenneTwister.h"
#include "bSnapp.h"

#include "bDocker.h"

using namespace std;
using namespace bStd;

int bDelTess::numInst_ = 0;
bool bDelTess::doDebug_ = false;

/****** Constructor */

/* Default */
bDelTess::bDelTess() {

   // self
   this->vrtx_.clear();
   this->simplex_.clear();
   this->simplID_.clear();
   this->simplTy_.clear();
   this->edges_.clear();
   this->max_ = 0;
   this->min_ = 0;
   this->size_ = 0;
   this->score_ = 0.0;
   memset( this->fout_, '\0', sizeof(char) * 96 );

   // sources
   this->numChains_ = 0;
   this->src_ = NULL; //new bPoints* [1];
   //~ this->src_[0] = new bPoints;
   this->toAdd_.clear();
   //~ this->infPt_ = new float[12];
   //~ this->infPt_[0] = 0.0; this->infPt_[1]  = 0.0; this->infPt_[2]  = 0.0;
   //~ this->infPt_[3] = 0.0; this->infPt_[4]  = 0.0; this->infPt_[5]  = 0.0;
   //~ this->infPt_[6] = 0.0; this->infPt_[7]  = 0.0; this->infPt_[8]  = 0.0;
   //~ this->infPt_[9] = 0.0; this->infPt_[10] = 0.0; this->infPt_[11] = 0.0;

   // Information (constantly changing)
   this->newID_.clear();
   this->newList_.clear();
   this->hullID_.clear();
   this->open_.clear();
   this->currPt_ = new float[3];
   this->currPt_[0] = 0.0; this->currPt_[1]  = 0.0; this->currPt_[2]  = 0.0;

   // flags
   this->isReady_ = false;
   this->isVerified_ = false;
   this->isSlim_ = false;
   this->isTrim_ = false;
   this->haveEdge_ = false;
   this->haveType_ = false;
   this->haveScore_ = false;

   // debugging
   this->invalidS_.clear();
   this->invalidP_.clear();
   this->removed_.clear();
   this->removedWhen_.clear();

   if( doDebug_ ) debug_ = fopen("debug.txt", "w");
   ++numInst_;
}

/* Copy */
bDelTess::bDelTess( const bDelTess &rhs, const bool saveSrc ) {

   // Copy self
   this->vrtx_ = rhs.vrtx_;
   this->simplex_ = rhs.simplex_;
   this->simplID_ = rhs.simplID_;
   this->simplTy_ = rhs.simplTy_;
   this->edges_ = rhs.edges_;
   this->max_ = rhs.max_;
   this->min_ = rhs.min_;
   this->size_ = rhs.size_;
   this->score_ = rhs.score_;
   strcpy( this->fout_, rhs.fout_ );

   // Copy sources
   if( saveSrc ) {
      this->numChains_ = rhs.numChains_;
      this->src_ = new bPoints* [this->numChains_];
      this->src_[0] = new bPoints( *(rhs.src_[0]) );
      for( int i=1; i < this->numChains_; ++i ) { this->src_[i] = rhs.src_[i]; }
      this->toAdd_ = rhs.toAdd_;
   }
   //~ this->infPt_ = new float[12];
   //~ this->infPt_[0] = rhs.infPt_[0]; this->infPt_[1] = rhs.infPt_[1]; this->infPt_[2] = rhs.infPt_[2];
   //~ this->infPt_[3] = rhs.infPt_[3]; this->infPt_[4] = rhs.infPt_[4]; this->infPt_[5] = rhs.infPt_[5];
   //~ this->infPt_[6] = rhs.infPt_[6]; this->infPt_[7] = rhs.infPt_[7]; this->infPt_[8] = rhs.infPt_[8];
   //~ this->infPt_[9] = rhs.infPt_[9]; this->infPt_[10] = rhs.infPt_[10]; this->infPt_[11] = rhs.infPt_[11];
   
   // Copy information;
   this->newID_ = rhs.newID_;
   this->newList_ = rhs.newList_;
   this->hullID_ = rhs.hullID_;
   this->open_ = rhs.open_;
   this->currPt_ = new float[3];
   this->currPt_[0] = rhs.currPt_[0]; this->currPt_[1] = rhs.currPt_[1]; this->currPt_[2] = rhs.currPt_[2];

   // Copy flags
   this->isReady_ = rhs.isReady_;
   this->isVerified_ = rhs.isVerified_;
   this->isSlim_ = rhs.isSlim_;
   this->isTrim_ = rhs.isTrim_;
   this->haveEdge_ = rhs.haveEdge_;
   this->haveType_ = rhs.haveType_;
   this->haveScore_ = rhs.haveScore_;

   // debugging
   this->invalidS_ = rhs.invalidS_;
   this->invalidP_ = rhs.invalidP_;
   this->removed_ = rhs.removed_;
   this->removedWhen_ = rhs.removedWhen_;
   if( doDebug_ ) debug_ = fopen("debug.txt", "w");

   ++numInst_;
}

/* Destructor */
bDelTess::~bDelTess() {

   // self
   this->vrtx_.clear();
   this->simplex_.clear();
   this->simplID_.clear();
   this->simplTy_.clear();
   this->edges_.clear();

   // sources
   if( this->src_ != NULL ) {
      if( this->src_[0] != NULL ) { delete this->src_[0]; }
      for( int i=0; i < this->numChains_; ++i ) { this->src_[i] = NULL; }
      delete [] this->src_;
      this->src_ = NULL;
   }
   this->toAdd_.clear();
   //~ delete [] this->infPt_;
   //~ this->infPt_ = NULL;

   // Information (constantly changing)
   this->newID_.clear();
   this->newList_.clear();
   this->hullID_.clear();
   this->open_.clear();
   delete [] this->currPt_;
   this->currPt_ = NULL;

   // debugging
   this->invalidS_.clear();
   this->invalidP_.clear();
   this->removed_.clear();
   this->removedWhen_.clear();
   if( doDebug_ ) fclose( debug_ );

   --numInst_;
}

bDelTess& bDelTess::operator=( const bDelTess& rhs ) {
   // Copy self
   this->vrtx_ = rhs.vrtx_;
   this->simplex_ = rhs.simplex_;
   this->simplID_ = rhs.simplID_;
   this->simplTy_ = rhs.simplTy_;
   this->edges_ = rhs.edges_;
   this->max_ = rhs.max_;
   this->min_ = rhs.min_;
   this->size_ = rhs.size_;
   this->score_ = rhs.score_;
   strcpy( this->fout_, rhs.fout_ );

   // Remove sources
   if( this->src_ != NULL ) {
      if( this->src_[0] != NULL ) { delete this->src_[0]; }
      for( int i=0; i < this->numChains_; ++i ) { this->src_[i] = NULL; }
      delete [] this->src_;
      this->src_ = NULL;
   }
   //~ if( this->infPt_ != NULL ) { delete [] this->infPt_; this->infPt_ = NULL; }

   // Copy sources
   this->numChains_ = rhs.numChains_;
   this->src_ = new bPoints* [this->numChains_];
   this->src_[0] = new bPoints( *(rhs.src_[0]) );
   for( int i=1; i < this->numChains_; ++i ) { this->src_[i] = rhs.src_[i]; }
   this->toAdd_ = rhs.toAdd_;
   //~ this->infPt_ = new float[12];
   //~ this->infPt_[0] = rhs.infPt_[0]; this->infPt_[1] = rhs.infPt_[1]; this->infPt_[2] = rhs.infPt_[2];
   //~ this->infPt_[3] = rhs.infPt_[3]; this->infPt_[4] = rhs.infPt_[4]; this->infPt_[5] = rhs.infPt_[5];
   //~ this->infPt_[6] = rhs.infPt_[6]; this->infPt_[7] = rhs.infPt_[7]; this->infPt_[8] = rhs.infPt_[8];
   //~ this->infPt_[9] = rhs.infPt_[9]; this->infPt_[10] = rhs.infPt_[10]; this->infPt_[11] = rhs.infPt_[11];
   
   // Copy information;
   this->newID_ = rhs.newID_;
   this->newList_ = rhs.newList_;
   this->hullID_ = rhs.hullID_;
   this->open_ = rhs.open_;
   if( this->currPt_ != NULL ) { delete [] this->currPt_; this->currPt_ = NULL; }
   this->currPt_ = new float[3];
   this->currPt_[0] = rhs.currPt_[0]; this->currPt_[1] = rhs.currPt_[1]; this->currPt_[2] = rhs.currPt_[2];

   // Copy flags
   this->isReady_ = rhs.isReady_;
   this->isVerified_ = rhs.isVerified_;
   this->isSlim_ = rhs.isSlim_;
   this->isTrim_ = rhs.isTrim_;
   this->haveEdge_ = rhs.haveEdge_;
   this->haveType_ = rhs.haveType_;
   this->haveScore_ = rhs.haveScore_;

   // debugging
   this->invalidS_ = rhs.invalidS_;
   this->invalidP_ = rhs.invalidP_;
   this->removed_ = rhs.removed_;
   this->removedWhen_ = rhs.removedWhen_;
   return *this;
}


void bDelTess::reset() {
   //~ while( this->vrtx_.size() > 4 ) {
      //~ this->toAdd_.push_back( this->vrtx_.back() );
      //~ this->vrtx_.pop_back();
   //~ }
   this->clear();
   this->vrtx_.clear();
   this->toAdd_.clear();
   //~ delete [] this->infPt_;
   //~ this->infPt_ = NULL;
   //~ this->infPt_ = new float[12];
   //~ this->setSrc( *(this->src_) );
   this->isReady_ = false;
   this->prep();
   this->randomizePts();
   
   return;
}

void bDelTess::clear() {
   // self
   while( this->vrtx_.size() > 4 ) { vrtx_.pop_back(); }
   this->simplex_.clear();
   this->simplID_.clear();
   this->simplTy_.clear();
   this->edges_.clear();
   this->score_ = 0.0;

   // flags
   this->haveType_ = false;
   this->haveEdge_ = false;
   this->isTrim_ = false;
   this->isSlim_ = false;
   this->isVerified_ = false;
   this->haveScore_ = false;

   // Information (constantly changing)
   if( this->currPt_ != NULL ) { delete [] this->currPt_; this->currPt_ = NULL; }
   this->currPt_ = new float[3];
   this->newID_.clear();
   this->newList_.clear();
   this->hullID_.clear();
   this->open_.clear();

   // debugging
   this->invalidS_.clear();
   this->invalidP_.clear();
   this->removed_.clear();
   this->removedWhen_.clear();
   if( doDebug_ ) fclose( debug_ );
}



/**/
/****** Internal */
/* Set Source [bPoints] */
//~ void bDelTess::link( bPoints &ptSrc ) {
   //~ // Note: this should only be used to RELINK tessellations
   //~ for( int i=0; i < this->numChains_; ++i ) { this->src_[i] = NULL; }
   //~ delete [] this->src_;
   //~ this->src_ = NULL;
   
   //~ this->src_ = new bPoints*[1];
   //~ this->src_[0] = &ptSrc;
   //~ this->numChains_ = 1;
   //~ return;
//~ }
void bDelTess::addSrc( bPoints &ptSrc ) {
   // Ensure ptSrc is ready
   if( ptSrc.numPnts_ == 0 ) { throw "[bDelTess] Empty point set."; }
   else if( !(ptSrc.haveMM_) ) { ptSrc._findMinMax(); }
   else {}

   bPoints** temp = NULL;
   if( this->src_ != NULL ) {
      if( this->src_[0] != NULL ) {
         delete this->src_[0];
         this->src_[0] = NULL;
      }

      if( this->numChains_ > 1 ) {
         temp = new bPoints* [this->numChains_];
         for( int i=1; i < this->numChains_; ++i ) {
            temp[i] = this->src_[i];
            this->src_[i] = NULL;
         }
      }
      delete [] this->src_;
      this->src_ = NULL;
   }
   else { ++this->numChains_; }
   ++this->numChains_;

   // New source
   this->src_ = new bPoints* [this->numChains_];
   this->src_[0] = NULL;
   if( temp != NULL ) {
      for( int i=1; i < (this->numChains_ - 1); ++i ) { 
         this->src_[i] = temp[i];
         temp[i] = NULL;
      }
      delete [] temp;
      temp = NULL;
   }
   this->src_[ (this->numChains_ - 1) ] = &ptSrc;
   

   return;
}

void bDelTess::addSrc( bPoints** ptSrc, int num ) {
   // Clear Source
   if( this->src_ != NULL ) {
      if( this->src_[0] != NULL ) {
         delete this->src_[0];
         this->src_[0] = NULL;
      }

      for( int i=1; i < this->numChains_; ++i ) {
         if( this->src_[i] != NULL ) { this->src_[i] = NULL; }
      }
      delete [] this->src_;
      this->src_ = NULL;
   }
   
   // Reset srouces
   this->numChains_ = num;
   ++(this->numChains_);
   this->src_ = new bPoints*[this->numChains_];
   this->src_[0] = NULL;
   for( int i=1; i < this->numChains_; ++i ) { this->src_[i] = ptSrc[i - 1]; }
   
   //~ printf("Info:\n");
   //~ for( int i=0; i < this->numChains_; ++i ) { 
      //~ if( this->src_[i] == 0 ) { printf("[%d] NULL\n",i); }
      //~ else { printf("[%d] %d :: %s\n", i, this->src_[i]->numPnts_, this->src_[i]->aaSeq_); }
   //~ }
   //~ printf("\n");
   
   return;
   
}

bool bDelTess::relink( bPoints* o, bPoints* n ) {
   bool found = false;
   for( int i=1; i < this->numChains_; ++i ) {
      if( (this->src_[i]) == o ) {
         this->src_[i] = NULL;
         this->src_[i] = n;
         i = this->numChains_;
         found = true;
      }
   }
   return found;
}

bool bDelTess::prep() {
   bool prep = false;
   if( this->numChains_ <= 1 ) { return prep; }
   
   // initial max and min
   int max[3] = { this->src_[1]->max_[0], this->src_[1]->max_[1], this->src_[1]->max_[2] };
   int min[3] = { this->src_[1]->min_[0], this->src_[1]->min_[1], this->src_[1]->min_[2] };
   
   // find min and max extremes
   for( int i=2; i < this->numChains_; ++i ) {
      if( max[0] < this->src_[i]->max_[0] ) { max[0] = this->src_[i]->max_[0]; }
      if( max[1] < this->src_[i]->max_[1] ) { max[1] = this->src_[i]->max_[1]; }
      if( max[2] < this->src_[i]->max_[2] ) { max[2] = this->src_[i]->max_[2]; }
      if( min[0] < this->src_[i]->min_[0] ) { min[0] = this->src_[i]->min_[0]; }
      if( min[1] < this->src_[i]->min_[1] ) { min[1] = this->src_[i]->min_[1]; }
      if( min[2] < this->src_[i]->min_[2] ) { min[2] = this->src_[i]->min_[2]; }
   }
   
   // find absolute max and min
   this->max_ = max[0]; this->min_ = min[0];
   if( this->max_ < max[1] ) { this->max_ = max[1]; }
   if( this->max_ < max[2] ) { this->max_ = max[2]; }
   if( this->min_ > min[1] ) { this->min_ = min[1]; }
   if( this->min_ > min[2] ) { this->min_ = min[2]; }
   
   // calculate infinity points
   int len = this->max_ - this->min_;
   int mid = this->min_ + len / 2;
   float infPt[12] = { mid - len * 4, mid - len * 1, mid - len * 4,
                       mid + len * 1, mid - len * 1, mid + len * 5,
                       mid + len * 0, mid + len * 4, mid + len * 0,
                       mid + len * 4, mid - len * 1, mid + len * 1
   };
   
   // Save infinity points
   if( this->src_[0] != NULL ) {
      delete this->src_[0];
      this->src_[0] = NULL;
   }
   this->src_[0] = new bPoints(4);
   this->src_[0]->addPoints( infPt, 4 );
   
   // Add first points
   ptData pt( 0, 0 );
   this->vrtx_.clear();
   this->vrtx_.push_front( pt ); pt.pos_ = 1;
   this->vrtx_.push_front( pt ); pt.pos_ = 2;
   this->vrtx_.push_front( pt ); pt.pos_ = 3;
   this->vrtx_.push_front( pt );
   
   // Randomize
   this->toAdd_.clear();
   this->randomizePts();
   
   // Filename
   memset( this->fout_, '\0', sizeof(char) * 96 );
   strcpy( this->fout_, this->src_[1]->pntPath_ );
   strcat( this->fout_, this->src_[1]->pntBase_ );
   for( int i=2; i < this->numChains_; ++i ) {
      if( this->src_[i]->pntBase_[0] == '\0' ) { continue; }
      sprintf( this->fout_, "%s_%s", this->fout_, this->src_[i]->pntBase_ );
   }
   
   //~ printf("numChains: %d\n", this->numChains_);
   //~ for( int i=0; i < this->numChains_; ++i ) {
      //~ printf("--== CHAIN %d ==--\n", i);
      //~ this->src_[i]->print();
   //~ }
   
   return true;
}

/* Uses the Mersenne Twister algorithm to get a random number
   -- uses the nextInt method from Java to constrain w/in [0-range]
*/
int bDelTess::getRandomNumber( const int range ) {
   if(range <= 0) { // check range...we could let it be lower than zero; just adjust
      return -1;
   }

   if((range & -range) == range) { // re[ar]range
      return (int)((range*(long)rndNum_.randInt()) >> 31);
   }

   int bits = 0; // put in range...longer implementation
   int val = 0;
   do {
      bits = rndNum_.randInt();
      val = bits % range;
   } while(bits - val + (range-1) < 0);

   return val;
}

/* Randomize Point Order */
void bDelTess::randomizePts() {
   rndNum_.seed((unsigned int)time(NULL)); // seeds the Mersenne Twister RNG
   this->toAdd_.clear();
   
   // create unaltered point list
   deque<ptData> ptList; //( this->src_->numPnts_ );
   this->size_ = 0;
   ptData p( 0, 0 );
   for( int i=1; i < this->numChains_; ++i ) {
      this->size_ += this->src_[i]->numPnts_;
      p.chn_ = i;
      for( int k=0; k < this->src_[i]->numPnts_; ++k ) { 
         p.pos_ = k;
         ptList.push_back( p );
      }
   }

   // generate random numbers and add index 
   int rndm = 0;
   int last = this->size_ - 1;
   //~ if( this->toAdd_.size() != this->src_->numPnts_ ) { this->toAdd_.resize()
   for( int i=0; i < (this->size_ - 1); ++i ) {
      rndm = this->getRandomNumber( last );
      while( rndm >= (int)ptList.size() ) { rndm = this->getRandomNumber( last ); }
      //~ if( i > (int)toAdd_.size() ) { printf("[toAdd] i too big: %d > %ld\n", i, toAdd_.size() ); exit(1); }
      toAdd_.push_back( ptList[rndm] );
      ptList.erase( ptList.begin() + rndm );
      --last;
   }
   
   toAdd_.push_back( ptList.front() );
   
   return;
}

/**/
/****** Simplex Handling */
/* Add */
int bDelTess::addSimplex( const int pt[] ) {
   // pt holds the indexes as listed by vrtx_, not src_

   // SIMPLEX :: variables
   bHex id( this->size_ );
   //~ printf("size: %d\n", this->size_);
   //~ valarray<bool> msk( this->src_->pnts_.size() );
   float ptSet[ 12 ];

   // Mask points to be included
   // Save points at infinity at the end
   // Create the simplex ID
   int sX = 0;
   int pX = 0;
   for(int i=0; i < 4; ++i ) {
      //~ printf("[%d] %d\n", i, pt[i]);
      id |= pt[i];
      pX = i * 3;
      
      //~ if( pt[i] > 3 ) { // i.e., not an infinity point
         sX = this->vrtx_[ pt[i] ].pos_ * 3;
         ptSet[pX]   = this->src_[ this->vrtx_[pt[i]].chn_ ]->pnts_[sX];
         ptSet[++pX] = this->src_[ this->vrtx_[pt[i]].chn_ ]->pnts_[++sX];
         ptSet[++pX] = this->src_[ this->vrtx_[pt[i]].chn_ ]->pnts_[++sX];
      //~ }
      //~ else { // special handling for infinity points
         //~ sX = pt[i] * 3;
         //~ ptSet[ pX ] = this->infPt_[ sX ];
         //~ ptSet[ ++pX ] = this->infPt_[ ++sX ];
         //~ ptSet[ ++pX ] = this->infPt_[ ++sX ];
      //~ }
   }

   // Create the simplex
   bSimplex s;
   try { s.setup( ptSet ); }
   catch( const char *e ) { throw e; }

   // Add to data structures
   int pos = 0;
   if( this->open_.empty() ) { // add a new simplex if no open spots
      pos = this->simplex_.size();
      this->simplex_.push_back( s );
      this->simplID_.push_back( id );
   }
   else { // overwrite an old simplex
      pos = this->open_.front();
      this->simplex_[ this->open_.front() ] = s;
      this->simplID_[ this->open_.front() ] = id;
      this->simplex_[ this->open_.front() ].id_ = this->open_.front();
      this->open_.pop_front();
   }

   return pos;
}

int bDelTess::addSimplex( bHex &id ) {
   int *plist = id.getActive();
   int pos;
   try{ pos = this->addSimplex( plist ); }
   catch( const char* e ) { throw e; }
   this->isVerified_ = false;
   return pos;
}

/* Remove */
void bDelTess::delSimplex( const int pos ) {
   // Debugging
   this->removed_.push_back( this->simplex_[pos] );
   int i = this->vrtx_.size() - 1;
   this->removedWhen_.push_back( i );
   
   // Clear
   this->open_.push_back( pos );
   this->simplID_[pos] = 0; // Clear ID
   --bSimplex::count_;
   for( int i=0; i < 4; ++i ) { // Remove all references to this simplex
      if( this->simplex_[pos].nghbr_[i] != NULL ) {
         for( int k=0; k < 4; ++k ) {
            if( this->simplex_[pos].nghbr_[i]->nghbr_[k] == &(this->simplex_[pos]) ) {
               this->simplex_[pos].nghbr_[i]->nghbr_[k] = NULL;
               k = 4;
            }
            else {}
         }
      }
      this->simplex_[pos].nghbr_[i] = NULL;
   }
   return;
}


/***** TESSELLATE */
bool bDelTess::tessellateFull( bPoints &ptSrc ) {
   this->addSrc( ptSrc );
   this->prep();
   
   bool isValid = false;
   try{
      isValid = this->tessellate();
      isValid &= this->verify();
   }
   catch( const char* e ) { printf("%s\n", e); }
   
   while( !isValid ) {
      try{ 
         this->randomizePts();
         isValid = this->tessellate();
         isValid &= this->verify();
      }
      catch( const char* e ) { printf("%s\n", e); }
   }
   
   try{
      this->trim( 12.0 );
      this->removeExcess();
      this->findEdges();
   }
   catch( const char* e ) { throw e; }

   char fullname[96];
   strcpy( fullname, this->fout_ );
   strcat( fullname, "_gdDT.del4" );
   FILE* op = fopen( fullname, "w" );
   this->printTetByPos( op );
   fclose( op );

   strcpy( fullname, this->fout_ );
   strcat( fullname, "_gdDT.tet" );
   op = fopen( fullname, "w" );
   this->printTetByRes( op );
   fclose( op );
   return isValid;
}

/* Tessellate */
bool bDelTess::tessellate() {
   //~ printf("[bDelTess] Tessellating protein...\n");

   // Reset simplex counter
   bSimplex::count_ = 0;
   
   // Create first simplex
   bSimplex tet;
   int pts[4] = { 0, 1, 2, 3 };
   this->addSimplex( pts );
   
   // Prep
   if( this->currPt_ != NULL ) { delete [] this->currPt_; this->currPt_ = NULL; }
   this->currPt_ = new float[3];
   this->resetHandlers();

   // Add each point
   bool isValid = true;
   while( !this->toAdd_.empty() ) {
   //~ printf(" here %d\n",++debug);

      // Declare
      this->vrtx_.push_back( this->toAdd_.front() );
      this->toAdd_.pop_front();

      // Debug -- print current point
      //~ printf("Adding point %3lu...%d\n", this->vrtx_.size(), this->vrtx_.back() );
      if(doDebug_) fprintf(debug_, "Adding point...%d:%d\n", this->vrtx_.back().pos_, this->vrtx_.back().chn_ );

      // Reset Handlers
      try {
         this->checkPoint( this->vrtx_.size() - 1 );
         status();
         this->resetHandlers();
         this->newList_.clear();
         if(doDebug_) fprintf(debug_, "\n");
      }
      catch( const char *e ) { 
         isValid = false;
         break;
      }
   } // end while loop

   //~ this->findEdges();
   //~ printf("Info:\n");
   //~ for( int i=0; i < this->numChains_; ++i ) { 
      //~ if( this->src_[i] == 0 ) { printf("[%d] NULL\n",i); }
      //~ else { printf("[%d] %d :: %s\n", i, this->src_[i]->numPnts_, this->src_[i]->aaSeq_); }
   //~ }
   //~ printf("\n");
   return isValid;
}

/* Check All Simplexes Against Single Point */
void bDelTess::checkPoint( int ptId ) {
   if(doDebug_) fprintf(debug_, "checkPoint %d (%d:%d)\n" ,ptId, this->vrtx_[ptId].pos_, this->vrtx_[ptId].chn_);
   if( this->currPt_ == NULL ) { this->currPt_ = new float[3]; }
   
   int chn = this->vrtx_[ ptId ].chn_;
   int pos = this->vrtx_[ ptId ].pos_;
   
   this->currPtId_ = ptId;
   this->currPt_[0] = this->src_[chn]->pnts_[ ( 0 + (pos * 3) ) ];
   this->currPt_[1] = this->src_[chn]->pnts_[ ( 1 + (pos * 3) ) ];
   this->currPt_[2] = this->src_[chn]->pnts_[ ( 2 + (pos * 3) ) ];
   
   for( uint i=0; i < this->simplex_.size(); ++i ) {
      if( this->simplID_[i].empty() ) { continue; } // deleted simplex (open)
      if( this->simplID_[i] & this->currPtId_ ) { continue; } // simplex uses point
      
      if(doDebug_) fprintf(debug_, "\tloop: cP simplex[%d]\n", i);
      
      int isIn = this->simplex_[i].inSphere( this->currPt_ );
      if( isIn == 1 ) {} // outside
      else if( isIn == 0 || isIn == -1 ) {
         try{ 
            this->outbreak( NULL, &(this->simplex_[i]) );
            this->treat();
         }
         catch( const char *e ) { throw e; }
         break; // should have found all sick simplexes
      }
      else {}
   }
   return;
}

/* Check All Points Against Single Simplex */
void bDelTess::checkSimplex( bSimplex &sx ) {
   if(doDebug_) fprintf(debug_, "checkSimplex %d\n",sx.id_);
   if( this->currPt_ == NULL ) { this->currPt_ = new float[3]; }
   for( uint i=4; i < this->vrtx_.size(); ++i ) {
      if( this->simplID_[ sx.id_ ] & (int)i ) { continue; } // simplex uses point
      
      if(doDebug_) fprintf(debug_, "\tloop: cS point %d (%d:%d) from %d\n",i, this->vrtx_[i].pos_, this->vrtx_[i].chn_, sx.id_);
      if(doDebug_) fprintf(debug_, "current pt: %d\nvrtx: %d:%d\nnum pts: %d\n", i, this->vrtx_[i].pos_, this->vrtx_[i].chn_, this->src_[ this->vrtx_[i].chn_ ]->numPnts_);

      int chn = this->vrtx_[ i ].chn_;
      int pos = this->vrtx_[ i ].pos_;
      this->currPtId_ = i;
      this->currPt_[0] = this->src_[chn]->pnts_[ ( 0 + (pos * 3) ) ];
      this->currPt_[1] = this->src_[chn]->pnts_[ ( 1 + (pos * 3) ) ];
      this->currPt_[2] = this->src_[chn]->pnts_[ ( 2 + (pos * 3) ) ];
      int isIn = sx.inSphere( this->currPt_ );
      if( isIn == 1 ) {} // outside
      else if( isIn == -1 || isIn == 0 ) {
         throw "[checkSimplex] we do need the immunization\n";
         try {
            this->outbreak( NULL, &(sx) );
            this->treat();
         }
         catch( const char *e ) { throw e; }
         break; // if infected, it'll already be deleted
      }
      else {}
   }
   return;
}

/* Outbreak */
void bDelTess::outbreak( bSimplex *prev, bSimplex *curr ) {
   if(prev == NULL) {
      if(doDebug_) fprintf(debug_, "outbreak NULL-> %d\n", curr->id_);
   }
   else {
      if(doDebug_) fprintf(debug_,"outbreak %d -> %d\n", prev->id_, curr->id_);
   }
   if( this->sick_ & curr->id_ ) { return; }

   this->sick_ |= curr->id_;
   int numNull = 0;
   for( int i=0; i < 4; ++i ) { // check neighbors
      if(doDebug_) fprintf(debug_, "\tloop: outbreak neighbor %d",i);

      // Check simplex validity
      if( curr->nghbr_[i] == NULL ) {
         if(doDebug_) fprintf(debug_, " (NULL)\n");
         if( numNull > 0 ) {
            bHex test( this->simplID_[ curr->id_ ] );
            test.filter( (ulong)0xF, 0 );
            if( test.getNumFlip() < 4 ) {
               throw "[outbreak] Too many null neighbors.";
            }
         }
         else {
            try{ this->infectedHull( curr ); }
            catch( const char * e ) { throw e; }
            ++numNull;
         }
         continue;
      } // no neighbor
      else if( curr->nghbr_[i] == prev ) {
         if(doDebug_) fprintf(debug_, "(prev)\n");
         continue;
      } // previous simplex
      else{}
         
      if(doDebug_) fprintf(debug_, " (%d)\n",curr->nghbr_[i]->id_);

      // Check simplex point containment
      int isIn = curr->nghbr_[i]->inSphere( this->currPt_ );
      if( this->simplID_[ curr->nghbr_[i]->id_ ] & this->currPtId_ ) {
         isIn = 0;
      }

      // Check
      if( isIn == 1 ) { 
         try{ this->noInfection( curr, curr->nghbr_[i] ); }
         catch( const char * e ) { throw e; }
      } // outside
      else if( isIn == -1 || isIn == 0 ) {
         try{ this->outbreak( curr, curr->nghbr_[i] ); }
         catch( const char * e ) { throw e; }
      } // inside | edge
      else {} // shouldn't get here
   } // end neighbor loop

   return;
}

/* Infected Hull */
void bDelTess::infectedHull( bSimplex *curr ) {
   if(doDebug_) {
      fprintf(debug_, "infectedHull: %d\n", curr->id_);
      simplID_[ curr->id_ ].print( debug_);
   }
   
   bHex similarity( this->simplID_[ curr->id_ ] ); // copy the infected id
   similarity.filter( (ulong)0xF, 0 ); // identify hull points (infinity points)
   similarity |= this->currPtId_; // add current point
   if( similarity.getNumFlip() < 4 ) {
      throw "[infectedHull] Will create invalid simplex.";
   } // throw if we don't have a simplex
   else if( similarity.getNumFlip() == 5 ) {
      for( int i=0; i < 4; ++i ) {
         similarity ^= i;
         this->newID_.push_back( similarity );
         similarity |= i;
      }
   } // handle the very first simplex
   else {
      this->newID_.push_back( similarity ); // add to list to create
   } // typical handling
   return;
}

/* No Infection */
void bDelTess::noInfection( bSimplex *prev, bSimplex *curr ) {
   if(doDebug_) fprintf(debug_, "noInfection (%d -> %d, %d)\n", prev->id_, curr->id_, currPtId_);
   this->well_ |= curr->id_;
   bHex similarity( this->simplID_[ prev->id_ ] ); // copy previous id
   similarity &= this->simplID_[ curr->id_ ]; // identify common points
   similarity |= this->currPtId_; // add the current point
   if( similarity.getNumFlip() != 4 ) {
      throw "[noInfection] Will create invalid simplex.";
   } // throw if we don't have a simplex
   this->newID_.push_back( similarity ); // add to list to create
   return;
}

/* Treat */
void bDelTess::treat() {
   if(doDebug_) fprintf(debug_, "treat\n");
   try{
      this->removeSimplexes();
      this->addNewSimplexes();
      this->identifyNeighbors();
   }
   catch( const char *e ) { throw e; }
   return;
}

/* Add Simplexes in NewID */
void bDelTess::addNewSimplexes() {
   if(doDebug_) fprintf(debug_, "addNewSimplexes\n");
   bool isCoPlanar = false;
   for( uint i=0; i < this->newID_.size(); ++i ) {
      int pos;
      try { pos = this->addSimplex( this->newID_[i] ); }
      catch( const char *e ) {
         isCoPlanar = true;
         this->newList_.push_back( pos );
         break;
      }
      this->newList_.push_back( pos );
      if(doDebug_) fprintf(debug_, "\tloop: add %d (%d)\n",i, pos);
   }
   
   //~ // If co-planar, reset
   if( isCoPlanar ) {
      for( int k=0; k < (int)this->newList_.size(); ++k ) {
         this->delSimplex( this->newList_[k] );
      } // remove each newly-added simplex
      this->toAdd_.push_back( this->vrtx_.back() ); // place point at end of list
      this->vrtx_.pop_back(); // remove from cu
      throw "[addNewSimplexes] Found co-planar simplex and removed iteration.";
   }
   return;
}

/* Remove Sick Simplexes */
void bDelTess::removeSimplexes() {
   if(doDebug_) fprintf(debug_, "removeSimplexes\n");
   int *sick = this->sick_.getActive();
   int sickFlip = this->sick_.getNumFlip();

   // Nullify sick simplexes
   for( int i=0; i < sickFlip; ++i ) {
      if(doDebug_) fprintf(debug_, "\tloop: remove %d (%d)\n",i, sick[i]);
      this->delSimplex( sick[i] );
   }
   sick = NULL;
   return;
}

/* Identify Neighbors for New Simplexes */
void bDelTess::identifyNeighbors() {
   if(doDebug_) fprintf(debug_, "identifyNeighbors\n");
   
   // Get array
   int *well = this->well_.getActive();
   int wellFlip = this->well_.getNumFlip();

   // Point to neighbors
   for( uint i=0; i < this->newList_.size(); ++i ) {
      if(doDebug_) fprintf(debug_, "LOOP: neighbor %d (%d)\n",i, newList_[i]);
      
      int nghbrCnt = 0;
      bHex similarity( this->simplID_[ this->newList_[i] ] );
      if(doDebug_) fprintf(debug_, "neighboring %d\n",this->newList_[i]);
      
      // Check for neighbors amongst other new simplexes
      if(doDebug_) fprintf(debug_, "SICK\n");
      for( uint k=(i + 1); k < this->newList_.size() && nghbrCnt < 4; ++k ) {
         
         if(doDebug_) {
            fprintf(debug_, "\tloop: neighbors %d - %d\n", newList_[i], newList_[k]);
         }
         
         similarity &= this->simplID_[ this->newList_[k] ]; // find common points
         if( similarity.getNumFlip() == 3 ) {
            while( this->simplex_[ this->newList_[i] ].nghbr_[ nghbrCnt ] != NULL ) { ++nghbrCnt; }
            if( nghbrCnt >= 4 ) { throw "[bDelTess] Too many neighbors."; }
            this->simplex_[ this->newList_[i] ].nghbr_[ nghbrCnt ] = &( this->simplex_[ this->newList_[k] ] );
            ++nghbrCnt;
            for( int m=0; m < 4; ++m ) {
               if( this->simplex_[ this->newList_[k] ].nghbr_[m] == NULL ) {
                  this->simplex_[ this->newList_[k] ].nghbr_[m] = &(this->simplex_[ this->newList_[i] ]);
                  m = 4;
               } // save neighbor in empty slot
            } // loop through neighbor's neighbors
         } // three common points
         similarity = this->simplID_[ this->newList_[i] ]; // reset similarity
      }
      
      // Check for neighbors amongst existing simplexes
      if(doDebug_) fprintf(debug_, "WELL\n");
      for( int k=0; k < wellFlip && nghbrCnt < 4; ++k ) {

         if(doDebug_) {
            fprintf(debug_, "\tloop: neighbors %d - %d\n", newList_[i], well[k]);
         }

         similarity &= this->simplID_[ well[k] ]; // find common points
         if( similarity.getNumFlip() == 3 ) { 
            if(doDebug_) {
               simplID_[ newList_[i] ].print( debug_ );
               similarity.print( debug_);
               simplID_[ well[k] ].print( debug_ );
               fprintf(debug_, "\tmatch!");
            }
            while( this->simplex_[ this->newList_[i] ].nghbr_[ nghbrCnt ] != NULL ) { ++nghbrCnt; }
            if( nghbrCnt > 4 ) { throw "[bDelTess] Too many neighbors."; }
            this->simplex_[ this->newList_[i] ].nghbr_[ nghbrCnt ] = &( this->simplex_[ well[k] ] );
            for( int m=0; m < 4; ++m ) {
               if(doDebug_) fprintf(debug_, " (%d -> %d, %d)=", newList_[i], well[k],m);
               if( this->simplex_[ well[k] ].nghbr_[m] == NULL ) {
                  this->simplex_[ well[k] ].nghbr_[m] = &(this->simplex_[ this->newList_[i] ]);
                  if(doDebug_) fprintf(debug_, " NULL, %d; ", simplex_[ well[k] ].nghbr_[m]->id_);
                  m = 4;
               } // save neighbor in empty slot
               else {
                  if(doDebug_) fprintf(debug_, " %d; ", simplex_[ well[k] ].nghbr_[m]->id_);
               }
            } // loop through neighbor's neighbors
            if(doDebug_) fprintf(debug_, "\n");
            ++nghbrCnt;
         } // three common points
         similarity = this->simplID_[ this->newList_[i] ]; // reset similarity
      }
   } // end neighbors

   well = NULL;
   return;
}


/* Immunize */
void bDelTess::immunize() {
   if(doDebug_) fprintf(debug_, "immunize\n");
   // Checks the validity of all new simplexes (and repairs)
   while( ! this->newList_.empty() ) {
      if(doDebug_) fprintf(debug_, "\tloop: immunizing %d\n", this->newList_.front() );
      this->resetHandlers();
      this->checkSimplex( this->simplex_[ this->newList_.front() ] );
      this->newList_.pop_front(); // remove checked simplex
      this->reconcile( this->newList_, this->sick_ ); // remove newly deleted
   } // check every new simplex -- even those just made here
   return;
}

/* Reconcile First List */
void bDelTess::reconcile( dei &list, bHex &toRemove ) {
   int *removal = toRemove.getActive();
   int numRemove = toRemove.getNumFlip();
   for( int i=0; i < numRemove; ++i ) {
      for( uint k=0; k < list.size(); ++k ) {
         if( list[k] == removal[i] ) {
            list.erase( list.begin() + k );
         }
      }
   }
}

/* Reset Handlers */
void bDelTess::resetHandlers() {
   int multiplier = this->vrtx_.size() > 80 ? 10 : 6;
   int newSize = this->vrtx_.size() * multiplier;
   this->sick_.resize( newSize );
   this->well_.resize( newSize );
   this->sick_ = 0;
   this->well_ = 0;
   this->newID_.clear();
   this->hullID_.clear();
   return;
}

void bDelTess::validateTet( dei &toValRef ) {
   dei toVal( toValRef );
   this->resetHandlers();
   printf("num sick: %d\n", this->sick_.getNumFlip() );
   for( int i=0; i < (int)toVal.size(); ++i ) {
      if( skip( i ) ) { continue; }
      printf("validating [%d]\n",toVal[i]);
      for( int k=0; k < (int)this->vrtx_.size() - 1; ++k ) {
         if( this->simplID_[i] & (k) ) { continue; } // is point in simplex?
         
         int chn = this->vrtx_[ k ].chn_;
         int pos = this->vrtx_[ k ].pos_;
         this->currPtId_ = i;
         this->currPt_[0] = this->src_[chn]->pnts_[ ( 0 + (pos * 3) ) ];
         this->currPt_[1] = this->src_[chn]->pnts_[ ( 1 + (pos * 3) ) ];
         this->currPt_[2] = this->src_[chn]->pnts_[ ( 2 + (pos * 3) ) ];
         
         int isInside = this->simplex_[ toVal[i] ].inSphere( this->currPt_ );
         if( isInside != 1 ) {
            try{ this->outbreak( NULL, &this->simplex_[toVal[i]] ); }
            catch( const char * e ) { throw e; }
         }
      }
   }
   printf("num sick: %d\n", this->sick_.getNumFlip() );
   
   if( this->sick_.getNumFlip() > 0 ) {
      try{ this->addNewSimplexes(); } // add new simplexes
      catch( int e ) { printf("crap...\n"); } // throws an error if coplanar
      this->removeSimplexes(); // remove sick simplexes
      this->identifyNeighbors(); // find new and border simplex neighbors
   }
   
   return;
}

bool bDelTess::isNew( bSimplex *curr ) {
   return !(this->sick_ & curr->id_);
   return true;
}

/* Find Edges */
void bDelTess::findEdges() {
   //~ printf("[bDelTess] Finding edges...\n");
   if( !(this->edges_.empty()) ) { this->edges_.clear(); }

   bHex edge( this->vrtx_.size() );
   for( uint i=0; i < this->vrtx_.size(); ++i ) {
      this->edges_.push_back( edge );
   } // initialize edges

   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { continue; }

      bHex currID( this->simplID_[i] ); // save ID (temp)
      int *active = currID.getActive(); // get points
      if( currID.getNumFlip() < 4 ) { currID.print(); throw "[bDelTess] Found simplex with out enough bits flipped."; continue; }
      for( uint k=0; k < 4; ++k ) {
         currID ^= active[k]; // remove current point
         this->edges_[ active[k] ] |= currID; // save
      }// loop through points
      active = NULL;
   } // loop through all ids

   // Not needed if we don't include infinity tetrahedra
   //~ for( uint i=0; i < this->edges_.size(); ++i ) {
      //~ this->edges_[i].remove( (uint)0xF, 0 );
   //~ } // remove infinity points

   this->haveEdge_ = true;
   return;
}


/* Verify Tessellation */
bool bDelTess::verify() {
   //~ if( this->isVerified_ ) { return true; }
   //~ printf("[bDelTess] Verifying tessellation...\n");
   if(doDebug_) fprintf(debug_, " -- VERIFICATION -- \n");
   bool validTess = true;

   //~ while( !validTess && attempts < 5 ) {
      //~ printf("validating...%d\n",attempts);
      //~ validTess = true;

      // Test simplex validity
      bool missingPoints = false;
      bool validSimplex = true;
      //~ vaf test( 3 );
      float test[3] = { 0.0, 0.0, 0.0 };
      bHex missingPt( this->simplID_[0] );
      for( uint i=0; i < this->simplex_.size(); ++i ) {
         if( skip( i ) ) { continue; }
         if( this->simplID_[i].getNumFlip() < 4 ) {
            //~ printf("bad: [%d] ",i);this->simplID_[i].print();
            //~ printf("\n");
            //~ for( uint k=0; k < this->simplID_.size(); ++k ) {
               //~ printf("%d:%d::",k, this->simplID_[k].getNumFlip() ); this->simplID_[k].print();
            //~ }

            throw "[bDelTess] Found simplex with out enough bits flipped. Retrying...";
            validTess = false;
         }

         missingPt |= this->simplID_[i]; // accumulate points to test for missing

         for( uint k=4; k < this->vrtx_.size(); ++k ) {
            if( this->simplID_[i] & (int)k ) { continue; } // is point in simplex?

            
            int chn = this->vrtx_[ k ].chn_;
            int pos = this->vrtx_[ k ].pos_;
            test[0] = this->src_[chn]->pnts_[ ( 0 + (pos * 3) ) ];
            test[1] = this->src_[chn]->pnts_[ ( 1 + (pos * 3) ) ];
            test[2] = this->src_[chn]->pnts_[ ( 2 + (pos * 3) ) ];
            short inSph = this->simplex_[i].inSphere( test );

            if( inSph == 1 ) { validSimplex= true; }
            else if( inSph == -1 ) {
               //~ printf("\t>> simplex [%d] pt (%d:%d) inside", i, k, this->vrtx_[k]);
               if(doDebug_) fprintf(debug_, " >> simplex [%d] pt (%d,%d:%d) inside", i, k, this->vrtx_[k].pos_, this->vrtx_[k].chn_);
               validSimplex = false;
            }
            else if( inSph == 0 ) {
               //~ printf("\t>> simplex [%d] on edge ", i);
               if(doDebug_) fprintf(debug_, " >> simplex [%d] on edge ", i);
               validSimplex = false;
            }
            else { printf("\tscrewed"); }

            if( !validSimplex ) {
               validTess = false;
               k = this->vrtx_.size();
               this->invalidS_.push_front( i );
               this->invalidP_.push_front( this->vrtx_[k] );
               //~ printf("\t-- INVALID POINT [%d] -- \n", this->invalidP_.back() );
               if(this->doDebug_) fprintf(debug_, " -- INVALID POINT [%d:%d] -- \n", this->invalidP_.front().pos_, this->invalidP_.front().chn_ );
            }
         } // point loop
      } // simplex loop

      if( !validTess ) { return validTess; }

      // Find missing points
      missingPt.assign( (ulong)0xF, 0 );
      missingPt.flipBits();

      if( !(missingPt.empty()) ) {
         // List the missing
         int *mP = missingPt.getActive();
         int nF = missingPt.getNumFlip();
         for( int i=0; i < nF; ++i ) {
            if( mP[i] > (int)(this->vrtx_.size() - 1) ) { i = nF; }
            else {
               missingPoints = true;
               //~ printf("\t>> point [%d,%d] not included in any simplexes\n",i,this->vrtx_[ mP[i] ]);
               if(doDebug_) fprintf(debug_, ">> point [%d,%d:%d] not included in any simplexes\n",i,this->vrtx_[ mP[i] ].pos_,this->vrtx_[ mP[i] ].pos_);
               this->invalidP_.push_back( this->vrtx_[ mP[i] ] );
            }
         }
         mP = NULL;
      }

      validTess &= !missingPoints;
      //~ ++attempts;
   //~ }
   this->isVerified_ = validTess;
   return validTess;
}

void bDelTess::retry() {
   bool hadEdge = this->haveEdge_;
   bool hadType = this->haveType_;
   bool wasTrim = this->isTrim_;
   bool wasSlim = this->isSlim_;
   this->reset();
   this->tessellate();
   if( wasTrim ) this->trim();
   if( wasSlim ) this->removeExcess();
   if( hadEdge ) this->findEdges();
   if( hadType ) this->findTypes();

   return;
}

/****** To Work With */
void bDelTess::focus( bPoints* focus ) {
   // Identify focus chain
   int chn = 0;
   for( int i=1; i < this->numChains_; ++i ) {
      if( this->src_[i] == focus ) { chn = i; i = this->numChains_; }
   }
   if( chn == 0 ) { return; }
   else { this->focus( chn ); }
   return;
}

void bDelTess::focus( int chn ) {
   // Remove non-focus simplexes
   bool hasFocus = false;
   int* alist;
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( this->skip(i) ) { continue; }
      
      hasFocus = false;
      alist = this->simplID_[i].getActive();
      if( this->vrtx_[ alist[0] ].chn_ == chn ) { hasFocus = true; }
      else if( this->vrtx_[ alist[1] ].chn_ == chn ) { hasFocus = true; }
      else if( this->vrtx_[ alist[2] ].chn_ == chn ) { hasFocus = true; }
      else if( this->vrtx_[ alist[3] ].chn_ == chn ) { hasFocus = true; }
      else { }
         
      if( !hasFocus ) { this->delSimplex( i ); }
      alist = NULL;
   }

   return;
}
void bDelTess::removeExcess() {
   if( ! this->isVerified_ ) { throw "[bDelTess::re] Please validate tessellation"; }
   if( this->isSlim_ ) { return; }
   
   //~ printf("[bDelTess] Removing empty and invalid simplexes...\n");
   bool remove;
   uint pos = 0;
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      remove = false;
      if( this->skip( i ) ) { remove = true; }
      else { continue; }

      if( remove ) {
         if( pos != i ) {
            this->simplex_[i] = this->simplex_[pos];
            this->simplID_[i] = this->simplID_[pos];
         }
         this->delSimplex( pos );
         ++pos;
      }
   }

   //~ printf("num to remove: %d\ttotal num: %u\n", pos, this->simplID_.size());
   while( !(this->simplID_.empty()) && this->simplID_.front().empty() ) {
      //~ printf("removing...%d\n", this->simplID_.size());
      this->simplID_.pop_front();
      this->simplex_.pop_front();
   }

   this->haveType_ = false;
   this->isSlim_ = true;
   //~ printf("Info:\n");
   //~ for( int i=0; i < this->numChains_; ++i ) { 
      //~ if( this->src_[i] == 0 ) { printf("[%d] NULL\n",i); }
      //~ else { printf("[%d] %d :: %s\n", i, this->src_[i]->numPnts_, this->src_[i]->aaSeq_); }
   //~ }
   //~ printf("\n");

   return;
}

void bDelTess::trim( float threshold ) {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   if( this->isTrim_ ) { return; }
   if( this->src_[1]->isInRes_ ) { threshold /= this->src_[1]->res_; }

   //~ printf("[bDelTess] Trimming long edges...\n");
   int nPt = this->size_;
   vector< vector< float > > dist( nPt, vector<float>( nPt, 0.0 ) );
   float pRef[3];
   float pCmp[3];

   // Measure pt distance in all vertices
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { continue; }

      int* list = this->simplID_[i].getActive();
      for( int y=0; y < 4; ++y ) {
         int yP   = list[y]; yP -= 4;
         int yPos = this->vrtx_[ list[y] ].pos_; yPos *= 3;
         int yChn = this->vrtx_[ list[y] ].chn_;

         for( int z=(y+1); z < 4; ++z ) {
            int zP   = list[z]; zP -= 4;
            int zPos = this->vrtx_[ list[z] ].pos_; zPos *= 3;
            int zChn = this->vrtx_[ list[z] ].chn_;

            if( dist[ yP ][ zP ] == 0.0 ) {
               pRef[0] = this->src_[yChn]->pnts_[yPos + 0];
               pRef[1] = this->src_[yChn]->pnts_[yPos + 1];
               pRef[2] = this->src_[yChn]->pnts_[yPos + 2];
               pCmp[0] = this->src_[zChn]->pnts_[zPos + 0];
               pCmp[1] = this->src_[zChn]->pnts_[zPos + 1];
               pCmp[2] = this->src_[zChn]->pnts_[zPos + 2];
               dist[yP][zP] = bPoints::pointDistance( pRef, pCmp ); 
            } // TEST if distance calculated

            if( dist[yP][zP] > threshold ) {
               this->delSimplex( i );
               y = 4;
               z = 4;
            } // DELETE simplex if edges are too long
         } // LOOP upper diagonal
      } // LOOP through vertices
   } // LOOP through simplexes
   
   this->isTrim_ = true;
   this->isSlim_ = false;
   return;
}

void bDelTess::findTypes() {
   if( ! this->isVerified_ ) { throw "[bDelTess::ft] Please validate tessellation"; }
   if( ! this->isSlim_ ) { this->removeExcess(); }
   if( this->haveType_ ) { return; }
   if( !(this->simplTy_.empty()) ) { this->simplTy_.clear(); }
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { this->simplTy_.push_back( -1 ); continue; }
      this->simplTy_.push_back( this->findType( i ) );
   }
   this->haveType_ = true;
   return;
}

/* Type of Tetrahedral */
int bDelTess::findType( int pos ) {
   if( this->haveType_ && this->isVerified_ ) { return this->simplTy_[pos]; }
   
   int* list = this->simplID_[pos].getActive();
   //~ int* plist = new int[4];
   //~ int* plink = new int[4];
   int type = 0;

   //~ /* convert to pt pos */ plist[0] = this->vrtx_[ list[0] ].pos_;
                           //~ plist[1] = this->vrtx_[ list[1] ].pos_;
                           //~ plist[2] = this->vrtx_[ list[2] ].pos_;
                           //~ plist[3] = this->vrtx_[ list[3] ].pos_;
                           //~ plink[0] = this->vrtx_[ list[0] ].chn_;
                           //~ plink[1] = this->vrtx_[ list[1] ].chn_;
                           //~ plink[2] = this->vrtx_[ list[2] ].chn_;
                           //~ plink[3] = this->vrtx_[ list[3] ].chn_;
                           //~ bSort::qsortDbl( plink, plist, 4 );

   //~ bool consec = false;
   
   // Type considerations -- flatten loop for speed
   register int c_org = this->vrtx_[ list[0] ].chn_;
   register int p_one = this->vrtx_[ list[0] ].pos_;
   register int p_two = this->vrtx_[ list[1] ].pos_;
   register bool consec = false;
   
   // Check 0-1
   if( c_org == this->vrtx_[ list[1] ].chn_ ) {
      ++p_one;
      if( p_one == p_two) { ++type; consec = true; }
   }
   
   // Check 1-2
   if( c_org == this->vrtx_[ list[2] ].chn_ ) {
      p_one = this->vrtx_[ list[2] ].pos_;
      ++p_two;
      if( p_one == p_two ) {
         ++type;
         if( consec ) { ++type; }
         consec = true;
      }
      else { consec = false; }
   }
   else { consec = false; }
   
   // Check 2-3
   if( c_org == this->vrtx_[ list[3] ].chn_ ) {
      p_two = this->vrtx_[ list[3] ].pos_;
      ++p_one;
      if( p_one == p_two ) {
         ++type;
         if( consec ) { ++type; }
         consec = true;
      }
      else { consec = false; }
   }
   else { consec = false; }

   
   //~ for( int i=0; i < 3; ++i ) { // loop through all but the last
      //~ int t = plist[i]; // store current value
      //~ int c = plink[i + 1];
      //~ ++t;            // increment the index
      //~ if( consec && t == plist[i+1] && c == plink[i] ) { // check for doubly consecutive indices
         //~ type += 2;
         //~ consec = false;
      //~ }
      //~ else if( t == plist[i+1] && c == plink[i] ) { // check for consecutive indices
         //~ ++type;
         //~ consec = true;
      //~ }
      //~ else { // not consecutive
         //~ consec = false;
      //~ }
   //~ }

   //~ delete [] plist;
   //~ plist = NULL;
   return type;
   
   /* STOPPED CHAIN CONSIDERATIONS */
}


float bDelTess::score() {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   if( !(this->isSlim_) ) { this->removeExcess(); }
   if( !(this->haveType_) ) { this->findTypes(); }
   if( this->haveScore_ ) { return this->score_; }
   if( !(this->simplSc_.empty()) ) { this->simplSc_.clear(); }
   this->score_ = 0.0;
   
   char* res = new char[5];
   res[0] = '\0';
   int *list = NULL;
   int cnt = 0;
   //~ for( int i=0; i < this->numChains_; ++i ) {
      //~ printf("seq: %s\n", this->src_[ i ]->aaSeq_ );
   //~ }
   
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( this->skip(i) ) { continue; }
      
      list = this->simplID_[i].getActive();
      //~ printf("list: %2d\t%2d\t%2d\t%2d\n", list[0], list[1], list[2], list[3]);
      //~ printf("chn:  %2d\t%2d\t%2d\t%2d\n", this->vrtx_[list[0]].chn_, this->vrtx_[list[1]].chn_, this->vrtx_[list[2]].chn_, this->vrtx_[list[3]].chn_);
      //~ printf("pos:  %2d\t%2d\t%2d\t%2d\n", this->vrtx_[list[0]].pos_, this->vrtx_[list[1]].pos_, this->vrtx_[list[2]].pos_, this->vrtx_[list[3]].pos_);
      //~ printf("num:  %2d\t%2d\t%2d\t%2d\n", 
         //~ this->src_[this->vrtx_[list[0]].chn_]->numPnts_,
         //~ this->src_[this->vrtx_[list[1]].chn_]->numPnts_,
         //~ this->src_[this->vrtx_[list[2]].chn_]->numPnts_,
         //~ this->src_[this->vrtx_[list[3]].chn_]->numPnts_);
      //~ printf("seq: %s\n", this->src_[ this->vrtx_[list[0]].chn_ ]->aaSeq_);
      res[0] = this->src_[ this->vrtx_[list[0]].chn_ ]->aaSeq_[ this->vrtx_[list[0]].pos_ ];
      res[1] = this->src_[ this->vrtx_[list[1]].chn_ ]->aaSeq_[ this->vrtx_[list[1]].pos_ ];
      res[2] = this->src_[ this->vrtx_[list[2]].chn_ ]->aaSeq_[ this->vrtx_[list[2]].pos_ ];
      res[3] = this->src_[ this->vrtx_[list[3]].chn_ ]->aaSeq_[ this->vrtx_[list[3]].pos_ ];
      bSort::qsort( res, 4 );
      this->simplSc_.push_back( bSnapp::score( res, this->simplTy_[cnt] ) );
      //~ printf("score: %.2f\t%s\n", this->simplSc_.back(), res);
      
      //~ printf("%c[%d:%d], ",res[0],this->vrtx_[list[0]].pos_,this->vrtx_[list[0]].chn_);
      //~ printf("%c[%d:%d], ",res[1],this->vrtx_[list[1]].pos_,this->vrtx_[list[1]].chn_);
      //~ printf("%c[%d:%d], ",res[2],this->vrtx_[list[2]].pos_,this->vrtx_[list[2]].chn_);
      //~ printf("%c[%d:%d], ",res[3],this->vrtx_[list[3]].pos_,this->vrtx_[list[3]].chn_);
      //~ printf("\n");
      ++cnt;
      this->score_ += this->simplSc_.back();
      list = NULL;

      delete [] res;
      res = NULL;
      res = new char[5];
   }
   delete [] res;
   res = NULL;
   
   this->haveScore_ = true;
   return this->score_;
}


/****** Checking */
bool bDelTess::skip( int pos ) {
   if( this->isSlim_ && this->isVerified_ ) { return false; }
   else if( this->simplID_[pos].empty() ) { return true; }
   else if( this->simplID_[pos] & (bHex::ulong)0xF ) { return true; }
   else {}
   return false;
}

/****** Output */

/* Print Tetrahedral Composition */
void bDelTess::printTetByRes( FILE* op ) {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   //~ printf("[bDelTess] Printing tetrahedrals by residue...\n");

   if( !this->haveType_ ) { this->findTypes(); }

   char* aaList = new char[5];
   memset( aaList, '\0', 5 );
   //~ aaList[4] = '\0';
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { continue; }

      int* list = this->simplID_[i].getActive();
      
      aaList[0] = this->src_[ this->vrtx_[list[0]].chn_ ]->aaSeq_[ this->vrtx_[list[0]].pos_ ];
      aaList[1] = this->src_[ this->vrtx_[list[1]].chn_ ]->aaSeq_[ this->vrtx_[list[1]].pos_ ];
      aaList[2] = this->src_[ this->vrtx_[list[2]].chn_ ]->aaSeq_[ this->vrtx_[list[2]].pos_ ];
      aaList[3] = this->src_[ this->vrtx_[list[3]].chn_ ]->aaSeq_[ this->vrtx_[list[3]].pos_ ];
      bSort::qsort( aaList, 4 );

      fprintf(op, "%s %d\n", aaList, this->simplTy_[i] );
      //~ delete [] aaList;
      //~ aaList = NULL;
      //~ aaList = new char[5];
   }
   delete [] aaList;
   aaList = NULL;
   return;
}

void bDelTess::printTetByPos( FILE* op ) {
   if( ! this->isVerified_ ) { throw "[bDelTess] Please validate tessellation"; }
   //~ printf("[bDelTess] Printing tetrahedrals by sequence position...\n");
   register int* plist = new int[4];
   for( uint i=0; i < this->simplID_.size(); ++i ) {
      if( skip( i ) ) { continue; }

      int* list = this->simplID_[i].getActive();
      plist[0] = this->vrtx_[ list[0] ].pos_;
      plist[1] = this->vrtx_[ list[1] ].pos_;
      plist[2] = this->vrtx_[ list[2] ].pos_;
      plist[3] = this->vrtx_[ list[3] ].pos_;

      // setup continuous numbering
      for( int i=0; i < 4; ++i ) {
         register int chn = this->vrtx_[ list[0] ].chn_;
         if( chn > 1 ) {
            for( int k=1; k < chn; ++k ) {
               plist[i] += this->src_[k]->numPnts_;
            }
         }
      }

      bSort::qsort( plist, 4 );
      fprintf(op, "%d %d %d %d\n", 
         plist[0],
         plist[1],
         plist[2],
         plist[3] );
   }
   delete [] plist;
   plist = NULL;
   return;
}

/* PyMol */
void bDelTess::pymolDelTess( FILE* op, char name[], char color[] ) {
   if( ! this->isVerified_ ) { throw "[bDelTess::pymol] Please validate tessellation"; }

   bool printEdges = true,  printInvalid = false,
        printValid = false, printRemoved = false,
        printInfinity = false;
   //~ if( doDebug_ ) {
      //~ printValid = true;
      //~ printInvalid = true;
      //~ printRemoved = true;
   //~ }

   //~ char colorRed[5] = "ruby";
   char colorG90[7] = "gray90";
   char colorG40[7] = "gray40";
   char colorBlu[5] = "blue";
   char colorGre[6] = "green";

   //~ char* name = new char[13];

   //~ bDocker::_pymolHeader( op, 1 );
   //~ strcpy(name,"tessellation");
   this->pymolPseudoatoms( op, name, color );

   // Print points causing invalid simplexes
   for( int m=0; m < (int)this->invalidP_.size(); ++m ) {
      fprintf(op, "cmd.show(\"dots\",\"%s%d////p%d\")\n", name, this->invalidP_[m].chn_, this->invalidP_[m].pos_ );
   }

   /* Print Invalid */ if( printInvalid ) {
      //~ printf("Printing invalid simplexes...\n");
      for( uint m=0; m < this->invalidS_.size(); ++m ) { // print invalid
         strcpy(name, "nS");
         this->simplex_[ this->invalidS_[m] ].pymolSimplex( op, name, colorBlu );
         this->simplID_[ this->invalidS_[m] ] = 0;
      }
   }

   /* Print Edges */ if( printEdges ) {
      //~ printf("[bDelTess] Printing edges for pymol...\n");
      this->pymolEdges( op, name, color );
   }

   /* Print Simplexes */ if( printValid ) {
      //~ printf("Printing valid simplexes [%ld]...\n", this->simplex_.size() );
      for( uint i=0; i < this->simplex_.size(); ++i ) { // print only valid
         if( skip( i ) ) { continue; }
         strcpy(name, "vS");
         this->simplex_[i].pymolSimplex( op, name, colorG40 );
      }
   }

   /* Print Infinity */ if( printInfinity ) {
      //~ printf("Printing infinity simplexes...\n");
      for( uint i=0; i < this->simplex_.size(); ++i ) { // print only infinity simplexes
         if( skip( i ) ) { continue; }
         strcpy(name, "iS");
         this->simplex_[i].pymolSimplex( op, name, colorG90 );
      }
   }

   /* Print Removed */ if( printRemoved ) {
      //~ printf("Printing removed simplexes [%ld,%ld]...\n", this->removed_.size(), this->removedWhen_.size() );
      for( int m=0; m < 1; ++m) {//(int)removed_.size() ; ++m ) {
         strcpy(name, "rS");
         this->removed_[m].pymolSimplex( op, name, colorGre );
         fprintf(op, "cmd.disable(\"%s%d\")\n", name, this->removed_[m].id_);
      }
   }

   //~ delete [] name;
   //~ printf("done\n");
   return;
}

/* PyMol Points */
void bDelTess::pymolPseudoatoms( FILE* op, char name[], char color[] ) {
   for( int i=1; i < this->numChains_; ++i ) {
      int index = 0;
      for( int k=0; k < this->src_[i]->numPnts_; ++k ) {
         fprintf(op, "cmd.pseudoatom(\"%s\",pos=[", name );
         fprintf(op, "%.2f,", this->src_[i]->pnts_[index]); ++index;
         fprintf(op, "%.2f,", this->src_[i]->pnts_[index]); ++index;
         fprintf(op, "%.2f]", this->src_[i]->pnts_[index]); ++index;
         fprintf(op, ", resn=\"%c\"", this->src_[i]->aaSeq_[k]);
         fprintf(op, ", resi=\"%d\"", k);
         fprintf(op, ", segi=\"1\"");
         fprintf(op, ", chain=\"%d\",name=\"SCC\")\n", i );
      }
      
   }
   fprintf(op, "cmd.color(\"%s\",\"%s\")\n", color, name);
}

/* PyMol Edges */
void bDelTess::pymolEdges( FILE* op, char name[], char color[] ) {
   if( ! this->isVerified_ ) { throw "[bDelTess::pymol:edges] Please validate tessellation"; }
   for( uint i=4; i < this->edges_.size(); ++i ) {
      int *active = this->edges_[i].getActive();
      for( int k=0; k < this->edges_[i].getNumFlip(); ++k ) {
         fprintf(op,"cmd.bond(\"%s//%d/%d/\",\"%s//%d/%d/\")\n",
            name, this->vrtx_[i].chn_, this->vrtx_[i].pos_,
            name, this->vrtx_[ active[k] ].chn_, this->vrtx_[ active[k] ].pos_ );
      }
   }
   //~ fprintf(op,"cmd.color(\"%s\",\"%s\")\n", color, name ); // color the simplex

   return;
}

/****** DEBUG */
void bDelTess::status() {
   if(!doDebug_) return;

   fprintf(debug_, "\n-- STATUS :: overall --\n");
   for( int i=0; i < (int)this->simplex_.size(); ++i ) {
       fprintf(debug_, "%d:", this->simplex_[i].id_);
      if( this->simplID_[i].empty() ) {  fprintf(debug_, "NULL\n"); }
      else {
         this->simplID_[i].print( debug_ );
         for( int k=0; k < 4; ++k ) {
             fprintf(debug_, "\tnghbr: ");
            if( this->simplex_[i].nghbr_[k] == NULL ) {
                fprintf(debug_, "NULL\n");
            }
            else {
               int nid = this->simplex_[i].nghbr_[k]->id_;
                fprintf(debug_, "%d | %d => ", nid, this->simplex_[i].nghbr_[k]->id_);
               for( int m = 0; m < 4; ++m ) {
                  if( this->simplex_[nid].nghbr_[m] == NULL ) {
                      fprintf(debug_, "NULL, ");
                  }
                  else {
                      fprintf(debug_, "%d, ", (this->simplex_[nid].nghbr_[m]->id_));
                  }
               }
                fprintf(debug_, "\n");
            }
         }
      }
   }  fprintf(debug_, "\n");
   // ~DEBUG
}

void bDelTess::status( int s ) {
   if(!doDebug_) return;
   
   printf("\n--STATUS :: simplex [%d:%d]-- \n", s, this->simplex_[s].id_);
   this->simplID_[s].print( debug_ );
   this->simplex_[s].print( debug_ );
   for( int k=0; k < 4; ++k ) {
      printf( "\tnghbr: ");
      if( this->simplex_[s].nghbr_[k] == NULL ) {
         printf( "NULL\n");
      }
      else {
         printf( "%d => ", this->simplex_[s].nghbr_[k]->id_);
         int nid = this->simplex_[s].nghbr_[k]->id_;
         for( int m = 0; m < 4; ++m ) {
            if( this->simplex_[nid].nghbr_[m] == NULL ) {
               printf( "NULL, ");
            }
            else {
               printf( "%d, ", (this->simplex_[nid].nghbr_[m]->id_));
            }
         }
         printf( "\n");
      }
   }
   printf( " ----\n");
   return;   
}