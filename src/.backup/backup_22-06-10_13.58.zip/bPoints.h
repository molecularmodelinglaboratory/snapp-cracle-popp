#ifndef BPOINTS_H
#define BPOINTS_H

#include <vector>
#include <deque>
#include <valarray>
#include <fstream>

#define PI 3.14159265

namespace bStd { class bPoints; };

class bStd::bPoints {
   typedef float* fp;
   
   
   friend class bGrid;
   friend class bDocker;
   friend class bDelTess;
   friend class bSort; // extraneous?
   friend class bSimplex;
   
public:
   bPoints();
   bPoints( const bPoints& );
   ~bPoints( );
   bPoints& operator=( const bPoints& );

   void clear();
   void addPoint( float[], int =(-1) );
   void addPoints( float[], int );

   // Parameter Functions
   void sizeAndSpace( int, const bPoints& );
   void set2SameSpace( const bPoints& );
   void setGridParam( float, float, float, float );
   void setGridParam( float, float, float, float, float );
   int  size( );
   void resize( int );
   void resizeCopy( int );

   // Command Line Arguements
   bool cla( int, char** );

   /* Rotation Functions */
   static bool rotateTheta( float[], int );
   static bool rotatePhi( float[], int );
   static bool rotateThetaPhi( float[], int, int );
   static bool rotatePhiTheta( float[], int, int );

   /* Conversion Functions */
   static bool c2s( float* );
   static bool s2c( float* );

   /* Measurement */
   void _findMinMax();
   void findNearbyPoints( bPoints&, bPoints& );
   static float pointDistance( float*, float* );

   // Protein
   void setSrc( const char[], const char[] =( "../../grid/") );
   bool fileExists( char* );
   bool readPoints( );
   bool readPoints( char* );
   bool readPoints( char*, char* );
      void _saveFilename( char[], char[] );
      void _saveFilenameNoExt( char[], char[] );
      int _readPoints( char*, float* & );
   bool setToDockingSpace( );
   static bool setToNormalSpace( std::deque<bPoints>&, int );
   static bool setToNormalSpace( bPoints& );
      bool _translatePointPlane( );
      bool _changePointSpace( );
   void getSeq();
      static char res3to1( char[] );

   // PyMol
   static void _pymolPoints( FILE*, float*, int, char[] =( "points" ) );//, float*, float );
   static void _pymolPoints( FILE*, float*, int, char[], char[], float );//, float*, float );
   static void _pymolConnectedPoints( FILE*, float*, int, char[] =( "points" ) );//, float*, float );
   static void _pymolConnectedPoints( FILE*, float*, int, char[], char[], float );//, float*, float );
   static void _pymolConnectedPseudoatoms( FILE*, float*, int, char[], char[] );
   static void _pymolPseudoatoms( FILE*, float*, int, char[], char[] );
   
   // Print
   void printPoint( int );
   static void printPoint( int* );
   static void printPoint( float* );
   static void printPoints( float*, int );
   //~ static void printPoint( std::valarray<float>& );
   //~ static void printPoints( std::valarray<float>& );

protected:
   // Flags
   bool havePnts_;
   bool haveTets_;
   bool isInRes_;
   bool isInPos_;
   bool haveMM_;

   // Counters
   int numPnts_;
   int numTets_;
   int capPnts_;

   // Data
   char pntBase_[16];
   char pntFile_[64];
   char tetFile_[64];
   char pntPath_[64];
   float min_[3];
   float max_[3];
   float planeDisplacement_[3]; // amount required to translate to (+) plane
   //~ std::valarray<float> pnts_;
   //~ std::valarray<float> tets_;
   //~ std::vector<float> pnts_;
   //~ std::vector<float> tets_;
   fp pnts_;
   fp tets_;
   char* aaSeq_;

   // Parameters
   float res_; // grid resolution (in angstroms)
   float fit_; // exclusion radius
   float thk_; // inclusion radius
   float offset_;
   float buffer_;

private:

};

/*******************************************************************

      TEMPLATE FUNCTIONS

*******************************************************************/







#endif
