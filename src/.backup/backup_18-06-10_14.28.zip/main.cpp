
//~ #include <cstdio>
//~ #include <vector>
//~ #include <valarray>
//~ #include <iostream>
//~ #include <fstream>
//~ #include <string>
#include <stdio.h>
#include "bDocker.h"
#include "bSimplex.h"
using namespace std;
using namespace bStd;

/*******************************************

   1) Read in protein
      -- recenter: origin in center of protein?
      -- find max (min) for each axis

      _width_i = _length_i + (2*f)/r + (2*t)r

   2) Create exlusion matrix

      _width_em = 1 + (2*f)/r


*******************************************/

int main( int argc, char **argv ) {
   //~ bHex t(72);
   //~ t |= 3;
   //~ t |= 2;
   //~ t |= 4;
   //~ t |= 6;
   
   //~ bSimplex s;
   //~ s.addPnt(1);
   //~ s.addPnt(2);
   //~ s.addPnt(3);
   //~ s.addPnt(4);
   //~ s.print();
   
   //~ t.assign(31,5);
   //~ t.assign(31,62);
   
   //~ int a = 15;
   //~ printf("hi: ");
   //~ printf("%0*d\n",a,2);
   //~ printf(";;\n");
   //~ t.print();
   //~ exit(1);
   
   bDocker d;
   d.cla(argc,argv);
   d.doItAll();
   
   
   //~ valarray<float> prt;
   //~ bGrid g;

	//~ valarray<unsigned long> test(8,10);
	
	//~ for(unsigned int i=0; i<test.size(); ++i) { printf("%d: %ld\n",i,test[i]); }
	//~ cout << endl;
   
	//~ long by = 3;
   //~ test <<= by;
	//~ for(unsigned int i=0; i<test.size(); ++i) { printf("%d: %ld\n",i,test[i]); }
	//~ cout << endl;

   //~ test >>= by;
	//~ for(unsigned int i=0; i<test.size(); ++i) { printf("%d: %ld\n",i,test[i]); }
	//~ cout << endl;

   //~ by *= -1;
   //~ test <<= abs(by);
	//~ for(unsigned int i=0; i<test.size(); ++i) { printf("%d: %ld\n",i,test[i]); }
	//~ cout << endl;

   //~ test >>= abs(by);
	//~ for(unsigned int i=0; i<test.size(); ++i) { printf("%d: %ld\n",i,test[i]); }
	//~ cout << endl;

   
	//~ long fun = 3;
	//~ test *= pow(2.0,fun);
	//~ for(unsigned int i=0; i<test.size(); ++i) { printf("%d: %ld\n",i,test[i]); }
	//~ cout << endl;

	//~ for(unsigned int i=0; i<test.size(); ++i) { test[i] *= pow(2.0,i); printf("%d: %ld\n",i,test[i]); }
	//~ cout << endl;

	//~ exit(1);
	
   //~ g.cla(argc,argv);
   
	//~ switch(argc) {
		//~ case 3: 
			//~ g.readPoints(argv[1],argv[2]);
			//~ break;
		//~ case 2:
			//~ g.readPoints(argv[1]);
			//~ break;
		//~ default:
			//~ printf("Incorrect number of paramters.\n\n");
			//~ exit(1);
			//~ break;
	//~ }
   //~ cout << "hi" << endl;
   //~ g.readPoints();
	//~ g.setToDockingSpace();

	//~ g.initializeGrid();
	//~ g.initializeStamps();
	//~ g.stampPoints();
	//~ g.printPyMol();

	//~ g.debugStampSetup();

	//~ g.setupHammingTable();
	//~ valarray<float> c(3);
	//~ c[0] = 8;
	//~ c[1] = 29;
	//~ c[2] = 30;
	//~ cout << "Nearby: " << g.countNearby(c) << endl;
	
   return 0;
}

