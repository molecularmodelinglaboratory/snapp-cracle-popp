
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

#include "bSys.h"

using namespace std;
using namespace bStd;

/****** Constructors */
bSys::bSys() {
   
}

bSys::~bSys() {
   
}

/****** File Checking */
bool bSys::fileExists( char* file, char* path) {
   int ps = strlen( path );
   int fs = strlen( file );
   char fullname[ ps + fs + 1 ];
   memset( fullname, '\0', ps + fs + 1 );
   memmove( fullname, path, ps );
   memmove( fullname + ps, file, fs );
   return fileExists( fullname );
}

bool bSys::fileExists( char* file ) {
   // modified from <http://www.techbytes.ca/techbyte103.html>
   struct stat info;
   bool exists = false;
   int status;

   /* Get attrib */ status = stat( file, &info );
   /* Does exist */ if( status == 0 && !(info.st_mode & S_IFDIR) ) { exists = true; }
   /* May not    */ else {}
  return exists;
}

bool bSys::dirExists( char* dir ) {
   struct stat info;
   bool exists = false;
   int status;

   /* Get attrib */ status = stat( dir, &info );
   /* Does exist */ if( status == 0 && (info.st_mode & S_IFDIR) ) { exists = true; }
   /* May not    */ else {}
  return exists;
}

/****** File Handling */
bool bSys::removeExt( char* file ) {
   int cnt = 0;
   int size = strlen( file );
   while( file[ size - 1 ] != '.' ) { --size; ++cnt; }
   --size; ++cnt;
   memset( file + size, '\0', cnt );
   return true;
}