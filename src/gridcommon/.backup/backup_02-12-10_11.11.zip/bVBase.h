#ifndef _SLASH
#define _SLASH
#if defined(_WIN32) || defined(_WIN64)
# error WIN not supported yet.
   const char _HOME_[13] = "%UserProfile%";
   const char _SLASH_    = '\\';
#else
   const char _HOME_[6] = "$HOME";
   const char _SLASH_    = '/';
#endif
#endif

#ifndef _MAXBIT
#define _MAXBIT
#if defined(_M_X64) || defined(__amd64__) || defined(_LP64)
   const short _MAXBIT_ = 64;
#else
# error 32-bit not supported yet.
   const short _MAXBIT_ = 32;
#endif
#endif

#ifndef PI
#define PI 3.14159265
#endif

#ifdef _OPENMP
#include <omp.h>
#endif

#include <stdio.h>
#include <stdlib.h>

#ifndef BVBASE_H
#define BVBASE_H


namespace bStd { class bVBase; };

class bStd::bVBase {
   protected:
      
   typedef unsigned short ushort;
   typedef unsigned int   uint;
   typedef unsigned long  ulong;
   
   public:
      
   virtual void pymol( FILE*, char[], char[] =("ruby") ) const =0;
   static  void pymolHeader( FILE*, int=0 );
   virtual void print( FILE* =(stdout) ) const =0;
};


#endif
