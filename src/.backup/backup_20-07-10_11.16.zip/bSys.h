#ifndef BSYS_H
#define BSYS_H

namespace bStd { class bSys; }

class bStd::bSys {

public:
   

   bSys();
   ~bSys();
   
   static bool fileExists( char*, char* );
   static bool fileExists( char* );
   static bool  dirExists( char* );

   static bool removeExt( char* );

};





#endif
