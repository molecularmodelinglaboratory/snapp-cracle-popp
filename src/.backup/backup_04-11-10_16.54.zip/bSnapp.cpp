
#include <fstream>
#include <sstream>
#include <stdio.h>

#include "bSnapp.h"

using namespace std;
using namespace bStd;

/* STATIC */
bool bSnapp::isSet_ = false;
char bSnapp::file_[64] = "./SNAPP_VALUES_BALA.txt";
float bSnapp::snapp_[20][20][20][20][4];

/****** CONSTRUCTOR & DESTRUCTOR */
bSnapp::bSnapp() {
   
}

bSnapp::bSnapp( const bSnapp &rhs ) {
   
}

bSnapp::~bSnapp() {
   
}

/****** READ SNAPP */

void bSnapp::readSnapp( const char file[] ) {
   if( isSet_ ) return;

   // open the file
   ifstream ip;
   ip.open(file, ifstream::in);
   if(!ip) { return; }
   
   // read in the file... not the most efficient, but we need the size
   // -- we read in w/o doing anything to get a cound of the residues
   //~ deque<string> data;
   string bffr;
   char res;
   for( uint i = 0; getline( ip, bffr ); ++i ) { 
      istringstream ss(bffr);
      int v[4];
      ss >> res; v[0] = res2num( res );
      ss >> res; v[1] = res2num( res );
      ss >> res; v[2] = res2num( res );
      ss >> res; v[3] = res2num( res );
      //~ = { res2num( ss >> res ), res2num( ss >> res ),
                   //~ res2num( ss >> res ), res2num( ss >> res ) };
      ss >> snapp_[ v[0] ][ v[1] ][ v[2] ][ v[3] ][0];
      ss >> snapp_[ v[0] ][ v[1] ][ v[2] ][ v[3] ][1];
      ss >> snapp_[ v[0] ][ v[1] ][ v[2] ][ v[3] ][2];
      ss >> snapp_[ v[0] ][ v[1] ][ v[2] ][ v[3] ][3];
      ss >> snapp_[ v[0] ][ v[1] ][ v[2] ][ v[3] ][4];
   }
   ip.close();

   isSet_ = true;
   return;
}



float bSnapp::score( char res[4], int type ) {
   int v[4] = { res2num( res[0] ), res2num( res[1] ),
                res2num( res[2] ), res2num( res[3] ) };
   return score( v, type );
}

float bSnapp::score( int res[4], int type ) {
   if( !isSet_ ) readSnapp();
   return snapp_[ res[0] ][ res[1] ][ res[2] ][ res[3] ][ type ];
}

int bSnapp::res2num( char res ) {
   int num = -1;
   res = toupper( res );
   switch( res ) {
      case 'A': num =  0; break; case 'B': num = -1; break;
      case 'C': num =  1; break; case 'D': num =  2; break;
      case 'E': num =  3; break; case 'F': num =  4; break;
      case 'G': num =  5; break; case 'H': num =  6; break;
      case 'I': num =  7; break; case 'J': num = -1; break;
      case 'K': num =  8; break; case 'L': num =  9; break;
      case 'M': num = 10; break; case 'N': num = 11; break;
      case 'O': num = -1; break; case 'P': num = 12; break;
      case 'Q': num = 13; break; case 'R': num = 14; break;
      case 'S': num = 15; break; case 'T': num = 16; break;
      case 'U': num = -1; break; case 'V': num = 17; break;
      case 'W': num = 18; break; case 'X': num = -1; break;
      case 'Y': num = 19; break; case 'Z': num = -1; break;
      default:  num = -1; break;
   };
   return num;
}