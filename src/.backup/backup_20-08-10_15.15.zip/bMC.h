#ifndef BMC_H
#define BMC_H

#include <deque>
#include <map>

#include "bHex.h"
#include "bDelTess.h"
#include "bGrid.h"
#include "bPoints.h"

namespace bStd { class bMC; class bMC_MetTable; };

typedef unsigned int uint;
typedef unsigned long ulong;
typedef unsigned short ushort;

class bStd::bMC {
   typedef std::deque< ulong > del;
   typedef std::deque< bHex > deH;
   typedef std::deque< bPoints > deP;
   typedef std::deque< bDelTess > deT;
   
   
private:


   //~ std::deque<bHex>

   uint pepLen_;
   deH xId_;
   deH yId_;
   deH zId_;
   del dtId_;
   
   
   bool  havePerturbSchema_;
   int** perturbSchema_;
   int   numOpt_;
   int   perturbRangeMin_[3];
   int   perturbRangeMax_[3];

   float threshold_;
   ulong numIter_;
   deP   confPe_;
   del   confId_;
   deP   confNb_;
   deT   confDt_;

   bGrid* grd_;



public: 
   bMC( bGrid* =(NULL) );
   bMC( const bMC& );
   ~bMC();
   
   bool metropolis( bDelTess& );
   ulong savePepId( const bPoints* );
   
   void setupPerturb( const int[3], const int[3] );
   void perturb( bPoints&, const bPoints& );

   void pymol( FILE*, char[], char[] );
};

/****************************** MetTable */
class bStd::bMC_MetTable{
   
private:
   float* delt_;
   float* prob_;
   ushort size_;

public:
   bMC_MetTable();
   ~bMC_MetTable();

   float operator[]( float );

   void read( char[] );

   
};

#endif
