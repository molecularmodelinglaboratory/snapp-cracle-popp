
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

#include "bSys.h"

using namespace std;
using namespace bStd;

/****** Constructors */
bSys::bSys() {
   
}

bSys::~bSys() {
   
}

/****** File Checking */
bool bSys::fileExists( char* file, char* path) {
   int ps = strlen( path );
   int fs = strlen( file );
   char fullname[ ps + fs + 1 ];
   memset( fullname, '\0', ps + fs + 1 );
   memmove( fullname, path, ps );
   memmove( fullname + ps, file, fs );
   return fileExists( fullname );
}

bool bSys::fileExists( char* file ) {
   // modified from <http://www.techbytes.ca/techbyte103.html>
   struct stat info;
   bool exists = false;
   int status;

   /* Get attrib */ status = stat( file, &info );
   /* Does exist */ if( status == 0 && !(info.st_mode & S_IFDIR) ) { exists = true; }
   /* May not    */ else {}
  return exists;
}

bool bSys::dirExists( char* dir ) {
   struct stat info;
   bool exists = false;
   int status;

   /* Get attrib */ status = stat( dir, &info );
   /* Does exist */ if( status == 0 && (info.st_mode & S_IFDIR) ) { exists = true; }
   /* May not    */ else {}
  return exists;
}

/****** File Handling */
bool bSys::removeExt( char* file ) {
   int cnt = 0;
   int size = strlen( file );
   while( file[ size - 1 ] != '.' ) { --size; ++cnt; }
   --size; ++cnt;
   memset( file + size, '\0', cnt );
   return true;
}

bool bSys::multicat( char* &save, const char* c1, const char* c2, const char* c3, const char* c4 ) {
   char* temp = NULL;
   uint s0 = 0;
   uint s1 = (c1 == NULL) ? 0 : strlen( c1 );
   uint s2 = (c2 == NULL) ? 0 : strlen( c2 );
   uint s3 = (c3 == NULL) ? 0 : strlen( c3 );
   uint s4 = (c4 == NULL) ? 0 : strlen( c4 );
   uint ss = s1; ss += s2; ss += s3; ss += s4; ++ss;
   if( save != NULL ) {
      s0 = strlen( save );
      ss += s0;
      temp = new char[ s0 + 1 ];
      memmove( temp, save, s0 ); temp[ s0 ] = '\0';
      delete [] save; save = NULL;
   }
   save = new char[ ss ];
   memset( save, '\0', ss );
   if( s0 ) { memmove( save, temp, s0 );}
   if( s1 ) { memmove( save + s0, c1, s1 ); s1 += s0; }
   if( s2 ) { memmove( save + s1, c2, s2 ); s2 += s1; }
   if( s3 ) { memmove( save + s2, c3, s3 ); s3 += s2; }
   if( s4 ) { memmove( save + s3, c4, s4 ); }
   
   if( temp != NULL ) {
      delete [] temp;
      temp = NULL;
   }
   return (ss > 0) ? true : false;
}