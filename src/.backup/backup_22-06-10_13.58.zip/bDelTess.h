#ifndef BDELTESS_H
#define BDELTESS_H

#include <valarray>
#include <deque>
//~ #include <map>
#include <stdio.h>
#include "bPoints.h"
#include "bSimplex.h"
#include "bHex.h"
#include "MersenneTwister.h"

namespace bStd { class bDelTess; };

class bStd::bDelTess {
   typedef std::valarray<float> vaf;
   typedef std::deque<short> des;
   typedef std::deque<int> dei;
   typedef std::deque<bHex> deh;
   typedef bHex::uint uint;
   typedef bHex::ulong ulong;
   //~ typedef std::map<char[4], char> mc3c;
   //~ typedef std::pair<char[4], char> pc3c;
   
   private:
      
      // Self
      std::deque<bHex>     edges_;
      std::deque<short>    vrtx_;
      std::deque<bSimplex> simplex_;
      std::deque<bHex>     simplID_;
      std::deque<int>      simplTy_;

      // Sources
      bPoints *            src_;
      vaf                  infPt_;
      std::deque<short>    toAdd_;

      // Information (constantly changing)
      //~ static mc3c aa3to1_;
      vaf               currPt_;
      int               currPtId_;
      bHex              sick_;
      bHex              well_;
      std::deque<bHex>  newID_;
      std::deque<int>   newList_;
      std::deque<int>   hullID_;
      std::deque<int>   open_;

      // Flags
      bool haveType_;
      bool haveEdge_;
      bool isTrim_;
      bool isSlim_;
      bool isVerified_;

      // debugging
      int recur_;
      std::deque<int> invalidS_;
      std::deque<int> invalidP_;
      std::deque<bSimplex> removed_;
      std::deque<int> removedWhen_;

      // Extras
      MTRand rndNum_;
      FILE* debug_;
      bool doDebug_;
   
   protected:
   
   public:
      
      // Constructors
      bDelTess();
      bDelTess( const bDelTess& );
      ~bDelTess();
      void clear();
   
      // Setup
      void setSrc( bPoints& );
      void randomizePts();
      int  getRandomNumber( const int );
      void defineAA3to1();
   
      // Simplex Manipulation
      int addSimplex( const int [] );
      int addSimplex( bHex & );
      void delSimplex( const int );
   
      // Tessellation
      void tessellate();
      void checkPoint( int );
      void checkSimplex( bSimplex& );
      void outbreak( bSimplex*, bSimplex* );
         void infectedHull( bSimplex* );
         void noInfection( bSimplex*, bSimplex* );
      void treat();
         void addNewSimplexes();
         void identifyNeighbors();
         void removeSimplexes();
      void immunize();
         void reconcile( dei&, bHex& );
      void resetHandlers();
      bool isNew( bSimplex* );
      
      // Finalization
      bool verify();
      void findEdges();
      void validateTet( dei & );
      void removeExcess();
      void trim( float =( (float)10.0 ) );
      bool skip( int );

      // Output
      void printTetByRes( FILE* );
      void printTetByPos( FILE* );
      void pymolDelTess( FILE*, char[], char[] =("ruby") );
      void pymolEdges( FILE*, char[], char[] );
      void status();
      void status( int );
   
      // Not Fully Tested
      void findType();
      int  findType( int );
};

#endif
