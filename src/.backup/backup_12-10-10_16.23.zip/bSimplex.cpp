
#include <omp.h>
double omp_get_wtime(void);


#include <stdio.h>
#include <valarray>
#include "bSimplex.h"
#include "bHex.h"
using namespace std;
using namespace bStd;

/* Static Declarations */
short bSimplex::count_ = 0;
slice bSimplex::cSlc_[3] = { // coordinate slices [x,y,z]
   slice( 1, 4, 5 ),
   slice( 2, 4, 5 ),
   slice( 3, 4, 5 ) };

slice bSimplex::pSlc_[4]= {  // point slices [3x1]
   slice( 1, 3, 1 ),
   slice( 6, 3, 1 ),
   slice( 11, 3, 1 ),
   slice( 16, 3, 1 ) };

slice bSimplex::sSlc_[4] = { // simplex slices [5x1]
   slice( 0, 5, 1 ),
   slice( 5, 5, 1 ),
   slice( 10, 5, 1 ),
   slice( 15, 5, 1 ) };

/**/
/****** Constructors */
/* Default */
bSimplex::bSimplex() {
   for( int i=0; i < 5; ++i ) {
      this->vrtx_[i] = 0;
      this->det_[i] = 0;
   }
   for( int i=5; i < 20; ++i ) { this->vrtx_[i] = 0; }
   for( int i=0; i < 4; ++i ) { this->nghbr_[i] = NULL; }
}

/* Copy */
bSimplex::bSimplex( const bSimplex &rhs ) {

   this->id_ = rhs.id_;
   for( int i=0; i < 5; ++i )  { this->det_[i] = rhs.det_[i]; }
   for( int i=0; i < 20; ++i ) { this->vrtx_[i] = rhs.vrtx_[i]; }
   for( int i=0; i < 4; ++i )  { this->nghbr_[i] = (rhs.nghbr_[i] == NULL) ? NULL : rhs.nghbr_[i]; }

}

/* Destructor */
bSimplex::~bSimplex() {
   for( int i=0; i < 4; ++i ) { this->nghbr_[i] = NULL; }
   //~ --bSimplex::count_;
}

/**/
/****** Assignment Operators */
bSimplex& bSimplex::operator=( const bSimplex &rhs ) {
   if( this == &rhs ) { return *this; }

   //~ printf("old|new: %4d | %4d\n", this->id_, rhs.id_);
   this->id_ = rhs.id_;
   for( int i=0; i < 5; ++i )  { this->det_[i] = rhs.det_[i]; }
   for( int i=0; i < 20; ++i ) { this->vrtx_[i] = rhs.vrtx_[i]; }
   for( int i=0; i < 4; ++i )  { this->nghbr_[i] = (rhs.nghbr_[i] == NULL) ? NULL : rhs.nghbr_[i]; }

   return *this;
}

bSimplex& bSimplex::operator=( const vaf &rhs ) {
   
   // Save point coordinates
   //~ int vrtIndx = 0;
   //~ int rhsIndx = 0;
   //~ for( int i=0; i < 4; ++i ) {
      //~ vrtIndx = i * 5;
      //~ this->vrtx_[vrtIndx] = 1.0;
      //~ ++vrtIndx;
      //~ for( int k=1; k < 4; ++k ) {
         //~ this->vrtx_[vrtIndx] = rhs[rhsIndx];
         //~ ++vrtIndx;
         //~ ++rhsIndx;
      //~ }
   //~ }
   
   // Calculate p_q
   //~ vaf dbl( rhs );
   //~ dbl *= dbl;
   //~ for( int i=0; i < 4; ++i ) {
      //~ vrtx_[i*5+4] = vaf(dbl[ slice( i*3, 3, 1 ) ]).sum();
   //~ }
   
   return *this;
}
bSimplex& bSimplex::operator=( const float* rhs ) {
   // Unrolled the loops -- not dynamic and called often enough.
   //~ this->setup( rhs );
   // Save point coordinates
   this->vrtx_[0]  = 1.0; this->vrtx_[1]  = rhs[0]; this->vrtx_[2]  = rhs[1];  this->vrtx_[3]  = rhs[2];
   this->vrtx_[5]  = 1.0; this->vrtx_[6]  = rhs[3]; this->vrtx_[7]  = rhs[4];  this->vrtx_[8]  = rhs[5];
   this->vrtx_[10] = 1.0; this->vrtx_[11] = rhs[6]; this->vrtx_[12] = rhs[7];  this->vrtx_[13] = rhs[8];
   this->vrtx_[15] = 1.0; this->vrtx_[16] = rhs[9]; this->vrtx_[17] = rhs[10]; this->vrtx_[18] = rhs[11];

   // Calculate p_q
   float a = 0.0;
   a = rhs[0]; a *= a; this->vrtx_[4] = a;
   a = rhs[1]; a *= a; this->vrtx_[4] += a;
   a = rhs[2]; a *= a; this->vrtx_[4] += a;
   
   a = rhs[3]; a *= a; this->vrtx_[9] = a;
   a = rhs[4]; a *= a; this->vrtx_[9] += a;
   a = rhs[5]; a *= a; this->vrtx_[9] += a;

   a = rhs[6]; a *= a; this->vrtx_[14] = a;
   a = rhs[7]; a *= a; this->vrtx_[14] += a;
   a = rhs[8]; a *= a; this->vrtx_[14] += a;

   a = rhs[9];  a *= a; this->vrtx_[19] = a;
   a = rhs[10]; a *= a; this->vrtx_[19] += a;
   a = rhs[11]; a *= a; this->vrtx_[19] += a;

   return *this;
}

/**/
/****** Conditional Operators */
/* Equal */
bool bSimplex::operator==( const bSimplex &rhs ) {   
   //~ valarray<bool> eqTest(this->vrtx_ == rhs.vrtx_);
   bool isEqual = true;
   for( int i=0; i < 5 && isEqual; ++i ) {
      isEqual &= (this->det_[i] == rhs.det_[i]);
   }
   return isEqual;
}

/* Not Equal */
bool bSimplex::operator!=( const bSimplex &rhs ) {
   return !( *this == rhs );
}

/* In Sphere */
short bSimplex::inSphere( const vaf &testPt ) {
   vaf test( 1.0, 5 );
   
   if( testPt.size() == 3 ) { 
      test[slice( 1, 3, 1 )] = testPt;
      vaf tmp( testPt );
      tmp *= tmp;
      test[4] = tmp.sum();
   }
   else { test = testPt; }
   
   for( int i=0; i < 5; ++i ) {
      test[i] *= this->det_[i];
   }
   float sum = test.sum();
   
   if( sum < 0 ) { return -1; }
   else if( sum > 0 ) { return 1; }
   else {}
   return 0;
}

short bSimplex::inSphere( const float* testPt ) {
   //~ vaf test( 1.0, 5 );
   float test[5] = { 1.0, testPt[0], testPt[1], testPt[2], 0.0 };
   double r = testPt[0]; r *= r; test[4] += (float)r;
          r = testPt[1]; r *= r; test[4] += (float)r;
          r = testPt[2]; r *= r; test[4] += (float)r;

   r = 0.0;
   test[0] *= this->det_[0]; r += test[0];
   test[1] *= this->det_[1]; r += test[1];
   test[2] *= this->det_[2]; r += test[2];
   test[3] *= this->det_[3]; r += test[3];
   test[4] *= this->det_[4]; r += test[4];
   
   //~ printf("insphere: %.2f\n",r);

   if( r < 0 ) { return 1; }
   else if( r > 0 ) { return -1; }
   else {}
   return 0;
}

/**/
/****** Setup */
/* Construct Simplex, Given Coordinates */
void bSimplex::setup( const float* pnts ) {
   double start;
   double end;
   //~ start = omp_get_wtime();
   //~ end = omp_get_wtime();
   //~ printf_s("Work took %f sec. time.\n", end-start);

//~ start = omp_get_wtime();
   //~ *this = pnts;
   //~ this->id_ = count_; // Setup ID
   //~ ++count_;
   
   //~ try{ this->orient(); } // make sure we have CCW (+) orientation
   //~ catch( const char* e ) { throw e; }
   //~ this->calcDet(pnts);
//~ end = omp_get_wtime();
//~ printf("Work took %f sec. time.\n", end-start);

   //~ printf("Old Det:");
   //~ for( int i=0; i < 5; ++i ) {
      //~ printf("\t%.2f,", this->det_[i]);
   //~ }
   //~ printf("\n");
//~ return;
//~ start = omp_get_wtime();
   // Setup 5x5
   float mat[25];
   // Initialize homology coordinate
   mat[0] = 1.0; mat[5] = 1.0; mat[10] = 1.0; mat[15] = 1.0;
   
   // Copy over array
   mat[1] = pnts[0]; mat[2] = pnts[1]; mat[3] = pnts[2];
   mat[6] = pnts[3]; mat[7] = pnts[4]; mat[8] = pnts[5];
   mat[11] = pnts[6]; mat[12] = pnts[7]; mat[13] = pnts[8];
   mat[16] = pnts[9]; mat[17] = pnts[10]; mat[18] = pnts[11];
   
   // Calculate distance coord
   float a = 0.0;
   a = pnts[0]; a *= a; mat[4] = a;
   a = pnts[1]; a *= a; mat[4] += a;
   a = pnts[2]; a *= a; mat[4] += a;
   
   a = pnts[3]; a *= a; mat[9] = a;
   a = pnts[4]; a *= a; mat[9] += a;
   a = pnts[5]; a *= a; mat[9] += a;

   a = pnts[6]; a *= a; mat[14] = a;
   a = pnts[7]; a *= a; mat[14] += a;
   a = pnts[8]; a *= a; mat[14] += a;

   a = pnts[9];  a *= a; mat[19] = a;
   a = pnts[10]; a *= a; mat[19] += a;
   a = pnts[11]; a *= a; mat[19] += a;
   
   // Set last coord
   mat[20] = 1.0; mat[21] = 1.0; mat[22] = 1.0; mat[23] = 1.0; mat[24] = 1.0;
   
   //~ int cnt = 0;
   //~ for( int i=0; i < 25; ++i ) {
      //~ printf("\t%8.2f",mat[i]);
      //~ if( ++cnt == 5 ) { printf("\n"); cnt = 0; }
   //~ }



   try{ this->orient(mat); } // make sure we have CCW (+) orientation
   catch( const char* e ) { throw e; }
//~ end = omp_get_wtime();
//~ printf("Work took %f sec. time.\n", end-start);

   //~ printf("New Det:");
   //~ for( int i=0; i < 5; ++i ) {
      //~ printf("\t%.2f,", this->det_[i]);
   //~ }
   //~ printf("\n\n");
   //~ if( count_ == 10 ) exit(1);

   return;
}

/****** ORIENT ******
throw: 0, same point; 1, co-planar */
void bSimplex::orient( float* pts ) {
   float minx = pts[1];
   float miny = pts[2];
   float minz = pts[3];
   
   bool swap = false;
   int row = 0;
   for( unsigned int i=1; i< 4; ++i ) {
      if( i == row ) { continue; }
      swap = false;

      int xX = i; xX *= 5; ++xX;
      int yX = xX; ++yX;
      int zX = yX; ++zX;
      //~ printf("xyx: %d | %d | %d\n", xX, yX, zX );

      if( miny > pts[yX] ) { swap = true;
         //~ printf("SWAP miny|pnts: [ %8.2f, %8.2f ]\n", miny, pts[yX]);
      }
      else if( miny == pts[yX] ) {
         if( minx > pts[xX] ) { swap = true; }
         else if( minx == pts[xX] ) {
            if( minz > pts[zX] ) { swap = true; }
            else if( minz == pts[zX] ) {
               printf("...same points: [min:0] %.2f, %.2f, %.2f   [vtx:%d] %.2f, %.2f, %.2f\n", minx, miny, minz,i, pts[xX], pts[yX], pts[zX]);
               throw 0;
            }
            else { }
         }
         else { }
      }
      else {
         //~ printf("NO SWAP miny|pnts: [ %8.2f, %8.2f ]\n", miny, pts[yX]);
      }

      if( swap ) {
         minx = pts[xX];
         miny = pts[yX];
         minz = pts[zX];
         row = i;
      }
   }
   
   if( row != 0 ) { this->swapRow( pts, 0, row, 5 ); }
   ++row;
   

   this->detByMinors( this->det_, pts, 5 );


   // co planar
   //~ float d21[3] = { pts[6], pts[7], pts[8] },
         //~ d31[3] = { pts[11], pts[12], pts[13] },
         //~ d43[3] = { pts[16], pts[17], pts[18] };
   //~ d21[0] -= pts[1]; d21[1] -= pts[2]; d21[2] -= pts[3];
   //~ d31[0] -= pts[1]; d31[1] -= pts[2]; d31[2] -= pts[3];
   //~ d43[0] -= pts[11]; d43[1] -= pts[12]; d43[2] -= pts[13];
   //~ float cp1[3] = { d21[1], d21[0], d21[0] },
         //~ cp2[3] = { d21[2], d21[2], d21[1] };
   //~ cp1[0] *= d43[2];
   //~ cp1[1] *= d43[2];
   //~ cp1[2] *= d43[1];
   
   //~ cp2[0] *= d43[1];
   //~ cp2[1] *= d43[0];
   //~ cp2[2] *= d43[0];
   
   //~ cp1[0] -= cp2[0];
   //~ cp1[1] -= cp2[1];
   //~ cp1[2] -= cp2[2];
   
   //~ d31[0] *= cp1[0];
   //~ d31[1] *= cp1[1];
   //~ d31[2] *= cp1[2];
   
   //~ d31[0] += d31[1];
   //~ d31[0] += d31[2];
   
   // check for swap
   if( this->det_[4] > 0 ) {
      this->swapRow( pts, 1, 2 );
      this->detByMinors( this->det_, pts, 5 );
   }
   
   if( this->det_[4] == 0 ) {
      printf("coplanar: %.2f\n",this->det_[4]);
      printf("\ndet[{{");
      int cnt = 0;
      for( int i=0; i < 25; ++i ) {
         printf("%8.2f,",pts[i]);
         if( ++cnt == 5 ) { printf("},\n{"); cnt = 0; }
      }
      printf("}]\n");
      float d = 0.0;
      for( int i=0; i < 5; ++i ) {
         printf("%8.2f,",this->det_[i]);
         d += this->det_[i];
      }
      printf("det: %.2f\n",d);
      
      throw 1;
      throw "[bSimplex] Unknown...co-planar?\n";
   }
   //~ else {}
      
   //~ for( int i=0; i < 5; ++i ) {
      //~ det_[i] *= -1.0;
      //~ det[i] *= mat[ matX ];
      //~ ++matX;
   //~ }

   
   return;
}

/* Re-Orient to Right-Handed Screw */
void bSimplex::orient() {
   // find minimum y coordinate
   float minx = this->vrtx_[1];
   float miny = this->vrtx_[2];
   float minz = this->vrtx_[3];
   
   //~ print(stdout);
   bool swap = false;
   int row = 0;
   for( int i=1; i < 4; ++i ) {
      if( i == row ) { continue; }
      int indx = i*5 + 2;
      swap = false;
      
      if( miny > this->vrtx_[ indx ] ) {
         //~ printf("SWAP miny|vrtx: [ %8.2f, %8.2f ]\n", miny, vrtx_[indx]);
         swap = true;
      }
      else if( miny == this->vrtx_[ indx ] ) {
         if( minx > this->vrtx_[ indx - 1 ] ) {
            swap = true;
         }
         else if( minx == this->vrtx_[ indx - 1] ) {
            if( minz > this->vrtx_[ indx + 1 ] ) {
               swap = true;
            }
            else if( minz == this->vrtx_[ indx + 1 ] ) {
               this->print();
               printf("...same points: [min] %.2f, %.2f, %.2f   [vtx] %.2f, %.2f, %.2f\n", minx, miny, minz, this->vrtx_[indx-1], this->vrtx_[indx], this->vrtx_[indx+1]);
               this->print();
               throw "[bSimplex] Same points in tetrahedral?\n";
            }
            else{}
         }
         else{}
      }
      else{ }//printf("NO SWAP miny|pnts: [ %8.2f, %8.2f ]\n", miny,vrtx_[indx]); }
      
      if( swap ) {
         miny = this->vrtx_[ indx ];
         minx = this->vrtx_[ indx - 1 ];
         minz = this->vrtx_[ indx + 1 ];
         row = i;
      }
   }
   
   // swap these rows
   if( row != 0 ) { this->swapRow( this->vrtx_, 0, row, 5 ); }
   ++row; // = 1
   
   vaf pts( this->vrtx_, 20 );
   vaf mat( 1.0, 16 );
   for( int i=0; i < 4; ++i ) {
      mat[ slice( i*4 + 1, 3, 1 ) ] = pts[ pSlc_[i] ];
   }
   vaf detV( 4 );
   //~ float det = detByGauss( mat, 4 );
   detByMinors( detV, mat, 4 );
   //~ printf("{ %8.2f, %8.2f, %8.2f, %12.2f }\n", vrtx_[1], vrtx_[2], vrtx_[3], vrtx_[4]);
   //~ printf("{ %8.2f, %8.2f, %8.2f, %12.2f }\n", vrtx_[6], vrtx_[7], vrtx_[8], vrtx_[9]);
   //~ printf("{ %8.2f, %8.2f, %8.2f, %12.2f }\n", vrtx_[11], vrtx_[12], vrtx_[13], vrtx_[14]);
   //~ printf("{ %8.2f, %8.2f, %8.2f, %12.2f }\n", vrtx_[16], vrtx_[17], vrtx_[18], vrtx_[19]);
   float det = detV.sum();
   printf("det = %.2f\n", det);
   if( det < 0 ) {
      //~ printf("\tswapped!\n");
      swapRow( this->vrtx_, 1, 2, 5 );
   }
   else if( det < 0.0001 && det > 0.0 ) {
      this->print();
      printf("coplanar: %.2f\n",det);
      throw "[bSimplex] Unknown...co-planar?\n";
   }
   else if( det > 0 ) {
      
   }
   else {}
   return;
}

/**/
/****** Calculation Methods */
/* Determinant */
void bSimplex::calcDet( const float* test, bool byMinor ) {
   
   
   //~ double start;
//~ double end;
//~ start = omp_get_wtime();
//~ end = omp_get_wtime();
//~ printf_s("Work took %f sec. time.\n", end-start);

   

   

   
   //~ int ctr = 0;
   //~ for( int i=0; i < 12; ++i ) {
      //~ printf("\t %.2f,", test[i]);
      //~ if( ++ctr == 3 ) { printf("\n"); ctr = 0; }
   //~ }
   
   /***** VALARRAY *****/

   // map vertices onto 5x5 determinant matrix
   vaf prtMat( this->vrtx_, 20 );
   vaf detMat( 1.0, 25 ); // 5x5
   detMat[ slice( 0, 20, 1 ) ] = prtMat;
   
   //~ ctr = 0;
   //~ for( int i=0; i < 25; ++i ) {
      //~ printf("\t %.2f,", detMat[i]);
      //~ if( ++ctr == 5 ) { printf("\n"); ctr = 0; }
   //~ }

   // temp valarray for calculations
   vaf det( 5 );
//~ start = omp_get_wtime();

   // calculate the determinant
   if( byMinor ) { // by minors
      this->detByMinors( det, detMat, 5 );
      for( int i=0; i < 5; ++i ) {
         this->det_[i] = det[i];
      }
   }
   else { // by Gauss
      // break down into four matrices
      // calculate det for each
   }
//~ end = omp_get_wtime();
//~ printf("Work took %f sec. time.\n", end-start);
   return;

   printf("Old Det:");
   for( int i=0; i < 5; ++i ) {
      printf("\t%.2f,", this->det_[i]);
   }
   printf("\n");

   
   /****** FLOAT *****/
   float* detMatF = new float[25];
   for( int i=0; i < 25; ++i ) {
      detMatF[i] = detMat[i];
   }
   int ctr = 0;
   printf("ARRAY [%d x %d]\n",5,5);
   for( int i=0; i < 25; ++i ) {
      printf("\t %.2f,", detMatF[i]);
      if( ++ctr == 5 ) { printf("\n"); ctr = 0; }
   }
//~ start = omp_get_wtime();

   // Calculate the determinant
   if( byMinor ) {
      this->detByMinors( this->det_, detMatF, 5 );
   }
   else {
   }
//~ end = omp_get_wtime();
//~ printf("Work took %f sec. time.\n", end-start);


   delete [] detMatF;
   detMatF = NULL;
   
   //~ return;
   printf("New Det:");
   for( int i=0; i < 5; ++i ) {
      printf("\t%.2f,", this->det_[i]);
   }
   printf("\n");

   
   
   exit(1);
   
   return;
}

void bSimplex::detByMinors( float* det, const float* mat, int dim ) {
   if( dim < 3 ) {
      det[0] = (mat[0] * mat[3]); // ad - bc
      det[1] = -(mat[1] * mat[2]);
      return;
   }

   // SETUP MINORS
   int minDim = dim - 1;
   
   float minMat[ minDim * minDim ];
   float minDet[ minDim ];
   //~ vaf minMat( 0.0, minDim * minDim );
   //~ vaf minDet( 0.0, minDim );
   //~ valarray<bool> detMsk( false, dim );
   
   // CALCULATE MINORS -- RECURSIVE!!
   int minX = 0, matX = 0;
   for( int i=0; i < dim; ++i ) {
      matX = 0; minX = 0;
      for( int k=0; k < minDim; ++k ) {
         for( int m=0; m < dim; ++m ) {
            if( m == i ) { ++matX; continue; }
            minMat[ minX ] = mat[ matX ];
            ++minX; ++matX;
         }
      }
      
   //~ int ctr = 0;
   //~ printf("ARRAY [%d x %d]\n",dim,dim);
   //~ for( int z=0; z < dim * dim; ++z ) {
      //~ printf("\t %.2f,", mat[z]);
      //~ if( ++ctr == dim ) { printf("\n"); ctr = 0; }
   //~ }
   
   //~ ctr = 0;
   //~ printf("ARRAY [%d x %d]\n",minDim,minDim);
   //~ for( int z=0; z < minDim * minDim; ++z ) {
      //~ printf("\t %.2f,", minMat[z]);
      //~ if( ++ctr == minDim ) { printf("\n"); ctr = 0; }
   //~ }printf("\n");
      
      detByMinors( minDet, minMat, minDim );
      det[i] = 0.0;
      for( int k=0; k < minDim; ++k ) {
         det[i] += minDet[k];
      }
   }

   // ADJUST MINOR DETERMINANTS (i.e., mult by -1 if needed)
   matX = dim; matX *= minDim;
   for( int i=0; i < dim; ++i ) {
      if( !(i & 1) ) { det[i] *= -1.0; }
      det[i] *= mat[ matX ];
      ++matX;
   }

   return;
}

/* Determinant by Minors */
void bSimplex::detByMinors( vaf &det, vaf &mat, int dim ) {
   if( dim < 3 ) {
      det[0] = (mat[0] * mat[3]); // ad - bc
      det[1] = -(mat[1] * mat[2]);
      return;
   }

   // SETUP MINORS
   int minDim = dim - 1;
   vaf minMat( 0.0, minDim * minDim );
   vaf minDet( 0.0, minDim );
   valarray<bool> detMsk( false, dim );
   
   // CALCULATE MINORS -- RECURSIVE!!
   for( int i=0; i<dim; ++i ) {
      
      // initialize minor
      std::valarray<bool> minMsk( 1,mat.size() ); // declare mask
      minMsk[ slice(i,dim,dim) ] = 0; // set masked column
      minMsk[ slice( dim*minDim, dim, dim ) ]; // set masked row (always the last)
      minMat = mat[ minMsk ];
      
      // recursively calculate the minor
      detByMinors( minDet, minMat, minDim );
      det[i] = minDet.sum();
   }
   
   // ADJUST MINOR DETERMINANTS (i.e., mult by -1 if needed)
   int isOdd = dim & 1; // 1 if odd, 0 if even
   for( int i=isOdd; i < dim; i += 2 ) {
      det[i] *= -1.0;
   }
   det *= vaf( mat[ slice( dim*minDim, dim, 1 ) ]);
   
   return;
}

/* Determinant by Gaussian */
float bSimplex::detByGauss( vaf &matRef, int dim ) {
   float det = 1.0;
   int row = dim, col = dim;
   int i = 0, j = 0;
   vaf mat( matRef );
   vaf tmp1( 0.0, dim );
   vaf tmp2( 0.0, dim );
   
   while( i < row && j < col ) {
      int maxi = i;
      
      for( int k=i+1; k < row; ++k ) {
         if( abs(mat[ k*col+j ]) > abs(mat[ maxi*col+j ]) ) {
            maxi = k;
         }
      }
      
      if( mat[ maxi*col+j ] != 0 ) {
         if(i != maxi) { swapRow( mat, i, maxi, col ); }
         tmp1 = mat[ slice( i*col, col, 1 ) ];
         tmp1 /= mat[ i*col+j ];
         for( int l=i+1; l < row; ++l ) {
            tmp2 = tmp1;
            tmp2 *= mat[ l*col+j ];
            mat[ slice( l*col, col, 1 ) ] -= tmp2;
         }
         ++i;
      }
      ++j;
   }
   
   for( int k=0; k < dim; ++k ) {
      det *= mat[k*col + k];
   }
   
   return det;
}

/* Swap Row -- needed for detByGauss */
void bSimplex::swapRow( vaf &d, int a, int b, int s ) {
   if( a == b ) { return; }
   vaf temp( 0.0, s);
   a *= s;
   b *= s;
   temp = d[ slice(a,s,1) ];
   d[ slice(a,s,1) ] = d[ slice(b,s,1) ];
   d[ slice(b,s,1) ] = temp;
   return;
}


/* Swap Row -- array */
void bSimplex::swapRow( float mat[], int a, int b, int dim ) {
   if( a == b ) { return; }
   float temp = 0.0;
   int aI = a * dim, bI = b * dim;
   for( int i=0; i < dim; ++i ) {
      temp = mat[ aI ];
      mat[ aI ] = mat[ bI ];
      mat[ bI ] = temp;
      ++aI;
      ++bI;
   }
   return;
}

void bSimplex::swapRow( float mat[], int a, int b ) {
   if( a == b ) { return; }
   register int aX = a, bX = b, cX = 0;
   aX *= 5; bX *= 5; ++aX; ++bX; cX = aX;
   float temp[4] = { mat[cX], mat[++cX], mat[++cX], mat[++cX] };
   mat[aX] = mat[bX];
   mat[++aX] = mat[++bX];
   mat[++aX] = mat[++bX];
   mat[++aX] = mat[++bX];
   mat[bX] = temp[3];
   mat[--bX] = temp[2];
   mat[--bX] = temp[1];
   mat[--bX] = temp[0];
   return;
}

/**/
/****** Internals */

/**/
/****** Output */
/* Print */
void bSimplex::print( FILE* op ) {
   
   //~ int index = 0;
   //~ for( int i=0; i < 4; ++i ) {
      //~ fprintf(op, "[");
      //~ for( int k=0; k < 5; ++k ) {
         //~ fprintf(op, "%#2.2f, ",this->vrtx_[index]);
         //~ ++index;
      //~ }
      //~ fprintf(op, "]\n");
   //~ }
   
   fprintf(op, "%xu |", this->id_);
   for( int i=0; i < 5; ++i ) {
      fprintf(op, "%#2.2f ", this->det_[i]);
   } fprintf(op, "|\n");
   
   return;
}

void bSimplex::printDet( vaf &det ) {
   printf("det: ");
   for( uint i=0; i < det.size(); ++i ) {
      printf("%.2f, ", det[i]);
   }
   printf(" = %.2f\n", det.sum() );
   return;
}

void bSimplex::pymolSimplex( FILE *op, char name[], char color[], int chain ) {
   for( int i=1; i < 20; i += 3 ) {    // print each atom
      fprintf(op,"cmd.pseudoatom(\"%s%d\",pos=[", name, this->id_);
      fprintf(op,"%.2f,", this->vrtx_[i]); ++i;
      fprintf(op,"%.2f,", this->vrtx_[i]); ++i;
      fprintf(op,"%.2f]", this->vrtx_[i]);
      fprintf(op,",chain=\"%d\"", chain);
      fprintf(op,",name=\"%d\")\n", ((i-3)/5) );
   }
      
   for( int i=0; i < 4; ++i ) {        // print each bond
      for( int k=i+1; k < 4; ++k ) { 
         fprintf(op,"cmd.bond(\"%s%d////%d\",\"%s%d////%d\")\n",
            name, this->id_, i,
            name, this->id_, k );
      }
   }

   fprintf(op,"cmd.color(\"%s\",\"%s%d\")\n",color, name, this->id_); // color the simplex
   return;
}

void bSimplex::printMatrix( vaf &mat, int dim ) {
   int index = 0;
   printf("[");
   for( int i=0; i < dim; ++i ) {
      //~ printf("{");
      for( int k=0; k < dim; ++k ) {
         printf("%.2f",mat[index]);
         if( k == dim - 1 && i == dim - 1 ) { printf("]\n"); }
         else if( k == dim - 1 ) { printf("; "); }
         else { printf(" "); }
         ++index;
      }
   }
   return;
}


