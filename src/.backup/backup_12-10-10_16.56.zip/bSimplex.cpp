
#include <omp.h>
double omp_get_wtime(void);


#include <stdio.h>
#include <stdlib.h>
#include "bSimplex.h"
#include "bHex.h"
using namespace std;
using namespace bStd;

/* Static Declarations */
short bSimplex::count_ = 0;

/**/
/****** Constructors */
/* Default */
bSimplex::bSimplex() {
   for( int i=0; i < 5; ++i ) {
      //~ this->vrtx_[i] = 0;
      this->det_[i] = 0;
   }
   //~ for( int i=5; i < 20; ++i ) { this->vrtx_[i] = 0; }
   for( int i=0; i < 4; ++i ) { this->nghbr_[i] = NULL; }
}

/* Copy */
bSimplex::bSimplex( const bSimplex &rhs ) {

   this->id_ = rhs.id_;
   for( int i=0; i < 5; ++i )  { this->det_[i] = rhs.det_[i]; }
   //~ for( int i=0; i < 20; ++i ) { this->vrtx_[i] = rhs.vrtx_[i]; }
   for( int i=0; i < 4; ++i )  { this->nghbr_[i] = (rhs.nghbr_[i] == NULL) ? NULL : rhs.nghbr_[i]; }

}

/* Destructor */
bSimplex::~bSimplex() {
   for( int i=0; i < 4; ++i ) { this->nghbr_[i] = NULL; }
   //~ --bSimplex::count_;
}

/**/
/****** Assignment Operators */
bSimplex& bSimplex::operator=( const bSimplex &rhs ) {
   if( this == &rhs ) { return *this; }

   //~ printf("old|new: %4d | %4d\n", this->id_, rhs.id_);
   this->id_ = rhs.id_;
   for( int i=0; i < 5; ++i )  { this->det_[i] = rhs.det_[i]; }
   //~ for( int i=0; i < 20; ++i ) { this->vrtx_[i] = rhs.vrtx_[i]; }
   for( int i=0; i < 4; ++i )  { this->nghbr_[i] = (rhs.nghbr_[i] == NULL) ? NULL : rhs.nghbr_[i]; }

   return *this;
}

bSimplex& bSimplex::operator=( const float* rhs ) {
   // Unrolled the loops -- not dynamic and called often enough.
   this->setup( rhs );
   // Save point coordinates
   //~ this->vrtx_[0]  = 1.0; this->vrtx_[1]  = rhs[0]; this->vrtx_[2]  = rhs[1];  this->vrtx_[3]  = rhs[2];
   //~ this->vrtx_[5]  = 1.0; this->vrtx_[6]  = rhs[3]; this->vrtx_[7]  = rhs[4];  this->vrtx_[8]  = rhs[5];
   //~ this->vrtx_[10] = 1.0; this->vrtx_[11] = rhs[6]; this->vrtx_[12] = rhs[7];  this->vrtx_[13] = rhs[8];
   //~ this->vrtx_[15] = 1.0; this->vrtx_[16] = rhs[9]; this->vrtx_[17] = rhs[10]; this->vrtx_[18] = rhs[11];

   // Calculate p_q
   //~ float a = 0.0;
   //~ a = rhs[0]; a *= a; this->vrtx_[4] = a;
   //~ a = rhs[1]; a *= a; this->vrtx_[4] += a;
   //~ a = rhs[2]; a *= a; this->vrtx_[4] += a;
   
   //~ a = rhs[3]; a *= a; this->vrtx_[9] = a;
   //~ a = rhs[4]; a *= a; this->vrtx_[9] += a;
   //~ a = rhs[5]; a *= a; this->vrtx_[9] += a;

   //~ a = rhs[6]; a *= a; this->vrtx_[14] = a;
   //~ a = rhs[7]; a *= a; this->vrtx_[14] += a;
   //~ a = rhs[8]; a *= a; this->vrtx_[14] += a;

   //~ a = rhs[9];  a *= a; this->vrtx_[19] = a;
   //~ a = rhs[10]; a *= a; this->vrtx_[19] += a;
   //~ a = rhs[11]; a *= a; this->vrtx_[19] += a;

   return *this;
}

/**/
/****** Conditional Operators */
/* Equal */
bool bSimplex::operator==( const bSimplex &rhs ) {   
   //~ valarray<bool> eqTest(this->vrtx_ == rhs.vrtx_);
   bool isEqual = true;
   for( int i=0; i < 5 && isEqual; ++i ) {
      isEqual &= (this->det_[i] == rhs.det_[i]);
   }
   return isEqual;
}

/* Not Equal */
bool bSimplex::operator!=( const bSimplex &rhs ) {
   return !( *this == rhs );
}

short bSimplex::inSphere( const float* testPt ) {
   //~ vaf test( 1.0, 5 );
   float test[5] = { 1.0, testPt[0], testPt[1], testPt[2], 0.0 };
   double r = testPt[0]; r *= r; test[4] += (float)r;
          r = testPt[1]; r *= r; test[4] += (float)r;
          r = testPt[2]; r *= r; test[4] += (float)r;

   r = 0.0;
   test[0] *= this->det_[0]; r += test[0];
   test[1] *= this->det_[1]; r += test[1];
   test[2] *= this->det_[2]; r += test[2];
   test[3] *= this->det_[3]; r += test[3];
   test[4] *= this->det_[4]; r += test[4];
   
   //~ printf("insphere: %.2f\n",r);

   if( r < 0 ) { return 1; }
   else if( r > 0 ) { return -1; }
   else {}
   return 0;
}

/**/
/****** Setup */
/* Construct Simplex, Given Coordinates */
bool bSimplex::setup( const float* pnts ) {
   //~ double start;
   //~ double end;

   // Temporary array for determinant calculation
   float mat[25];
   
   // Initialize homology coordinate
   mat[0] = 1.0; mat[5] = 1.0; mat[10] = 1.0; mat[15] = 1.0;
   
   // Copy over array
   mat[1] = pnts[0]; mat[2] = pnts[1]; mat[3] = pnts[2];
   mat[6] = pnts[3]; mat[7] = pnts[4]; mat[8] = pnts[5];
   mat[11] = pnts[6]; mat[12] = pnts[7]; mat[13] = pnts[8];
   mat[16] = pnts[9]; mat[17] = pnts[10]; mat[18] = pnts[11];
   
   // Calculate distance coord
   float a = 0.0;
   a = pnts[0]; a *= a; mat[4]  = a; a = pnts[1];  a *= a; mat[4]  += a; a = pnts[2];  a *= a; mat[4]  += a;
   a = pnts[3]; a *= a; mat[9]  = a; a = pnts[4];  a *= a; mat[9]  += a; a = pnts[5];  a *= a; mat[9]  += a;
   a = pnts[6]; a *= a; mat[14] = a; a = pnts[7];  a *= a; mat[14] += a; a = pnts[8];  a *= a; mat[14] += a;
   a = pnts[9]; a *= a; mat[19] = a; a = pnts[10]; a *= a; mat[19] += a; a = pnts[11]; a *= a; mat[19] += a;

   // Set last coord
   mat[20] = 1.0; mat[21] = 1.0; mat[22] = 1.0; mat[23] = 1.0; mat[24] = 1.0;

   try{ this->orient(mat); } // make sure we have CCW (+) orientation
   catch( const char* e ) { throw e; }
//~ end = omp_get_wtime();
//~ printf("Work took %f sec. time.\n", end-start);

   bool valid = this->orient(mat);
   this->detByMinors( this->det_, mat, 5 );
   return valid;
}

/****** ORIENT ******
throw: 0, same point; 1, co-planar */
bool bSimplex::orient( float* pts ) {
   float minx = pts[1];
   float miny = pts[2];
   float minz = pts[3];

   bool swap = false;
   int row = 0;
   for( unsigned int i=1; i< 4; ++i ) {
      if( i == row ) { continue; }
      swap = false;

      int xX = i; xX *= 5; ++xX;
      int yX = xX; ++yX;
      int zX = yX; ++zX;
      //~ printf("xyx: %d | %d | %d\n", xX, yX, zX );

      if( miny > pts[yX] ) { swap = true;
         //~ printf("SWAP miny|pnts: [ %8.2f, %8.2f ]\n", miny, pts[yX]);
      }
      else if( miny == pts[yX] ) {
         if( minx > pts[xX] ) { swap = true; }
         else if( minx == pts[xX] ) {
            if( minz > pts[zX] ) { swap = true; }
            else if( minz == pts[zX] ) {
               printf("...same points: [min:0] %.2f, %.2f, %.2f   [vtx:%d] %.2f, %.2f, %.2f\n", minx, miny, minz,i, pts[xX], pts[yX], pts[zX]);
               exit(1);
            }
            else {}
         }
         else {}
      }
      else {
         //~ printf("NO SWAP miny|pnts: [ %8.2f, %8.2f ]\n", miny, pts[yX]);
      }

      if( swap ) {
         minx = pts[xX];
         miny = pts[yX];
         minz = pts[zX];
         row = i;
      }
   }

   if( row != 0 ) { this->swapRow( pts, 0, row, 5 ); }
   ++row;

   this->detByMinors( this->det_, pts, 5 );

   // check for swap
   if( this->det_[4] > 0 ) {
      this->swapRow( pts, 1, 2 );
      //~ this->detByMinors( this->det_, pts, 5 );
   }

   // Check for co-planar
   bool notCoPlanar = true;
   if( this->det_[4] == 0 ) {
      notCoPlanar = false;
      //~ printf("coplanar: %.2f\n",this->det_[4]);
      //~ printf("\ndet[{{");
      //~ int cnt = 0;
      //~ for( int i=0; i < 25; ++i ) {
         //~ printf("%8.2f,",pts[i]);
         //~ if( ++cnt == 5 ) { printf("},\n{"); cnt = 0; }
      //~ }
      //~ printf("}]\n");
      //~ float d = 0.0;
      //~ for( int i=0; i < 5; ++i ) {
         //~ printf("%8.2f,",this->det_[i]);
         //~ d += this->det_[i];
      //~ }
      //~ printf("det: %.2f\n",d);
   }
   //~ else {}
      
   //~ for( int i=0; i < 5; ++i ) {
      //~ det_[i] *= -1.0;
      //~ det[i] *= mat[ matX ];
      //~ ++matX;
   //~ }

   return notCoPlanar;
}

void bSimplex::detByMinors( float* det, const float* mat, int dim ) {
   if( dim < 3 ) {
      det[0] = (mat[0] * mat[3]); // ad - bc
      det[1] = -(mat[1] * mat[2]);
      return;
   }

   // SETUP MINORS
   int minDim = dim - 1;
   float minMat[ minDim * minDim ];
   float minDet[ minDim ];

   // CALCULATE MINORS -- RECURSIVE!!
   int minX = 0, matX = 0;
   for( int i=0; i < dim; ++i ) {
      matX = 0; minX = 0;
      for( int k=0; k < minDim; ++k ) {
         for( int m=0; m < dim; ++m ) {
            if( m == i ) { ++matX; continue; }
            minMat[ minX ] = mat[ matX ];
            ++minX; ++matX;
         }
      }
      detByMinors( minDet, minMat, minDim );
      det[i] = 0.0;
      for( int k=0; k < minDim; ++k ) {
         det[i] += minDet[k];
      }
   }

   // ADJUST MINOR DETERMINANTS (i.e., mult by -1 if needed)
   matX = dim; matX *= minDim;
   for( int i=0; i < dim; ++i ) {
      if( !(i & 1) ) { det[i] *= -1.0; }
      det[i] *= mat[ matX ];
      ++matX;
   }

   return;
}

/* Swap Row -- array */
void bSimplex::swapRow( float mat[], int a, int b, int dim ) {
   if( a == b ) { return; }
   float temp = 0.0;
   int aI = a * dim, bI = b * dim;
   for( int i=0; i < dim; ++i ) {
      temp = mat[ aI ];
      mat[ aI ] = mat[ bI ];
      mat[ bI ] = temp;
      ++aI;
      ++bI;
   }
   return;
}

void bSimplex::swapRow( float mat[], int a, int b ) {
   if( a == b ) { return; }
   register int aX = a, bX = b, cX = 0;
   aX *= 5; bX *= 5; ++aX; ++bX; cX = aX;
   float temp[4] = { mat[cX], mat[++cX], mat[++cX], mat[++cX] };
   mat[aX] = mat[bX];
   mat[++aX] = mat[++bX];
   mat[++aX] = mat[++bX];
   mat[++aX] = mat[++bX];
   mat[bX] = temp[3];
   mat[--bX] = temp[2];
   mat[--bX] = temp[1];
   mat[--bX] = temp[0];
   return;
}

/**/
/****** Internals */

/**/
/****** Output */
/* Print */
void bSimplex::print( FILE* op ) {
   
   //~ int index = 0;
   //~ for( int i=0; i < 4; ++i ) {
      //~ fprintf(op, "[");
      //~ for( int k=0; k < 5; ++k ) {
         //~ fprintf(op, "%#2.2f, ",this->vrtx_[index]);
         //~ ++index;
      //~ }
      //~ fprintf(op, "]\n");
   //~ }
   
   fprintf(op, "%xu |", this->id_);
   for( int i=0; i < 5; ++i ) {
      fprintf(op, "%#2.2f ", this->det_[i]);
   } fprintf(op, "|\n");
   
   return;
}





