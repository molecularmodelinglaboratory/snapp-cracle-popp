
#include <deque>
#include <map>
#include <fstream>
#include <sstream>

#include <string.h>
#include <stdio.h>

#include "bMC.h"
#include "bCalc.h"
#include "bHex.h"
#include "bDelTess.h"
#include "bGrid.h"
#include "bPoints.h"


using namespace std;
using namespace bStd;

bMC::bMC( bGrid* g ) : 
   havePerturbSchema_(false), perturbSchema_(NULL), numOpt_(0), threshold_(0.0), numIter_(1000), grd_(g)
{
   this->perturbRangeMin_[0] = -2;
   this->perturbRangeMin_[1] = -2;
   this->perturbRangeMin_[2] = -2;
   this->perturbRangeMax_[0] = 2;
   this->perturbRangeMax_[1] = 2;
   this->perturbRangeMax_[2] = 2;
}

bMC::bMC( const bMC& rhs ) : 
   havePerturbSchema_(false), perturbSchema_(NULL), numOpt_(0)
{
   this->confPe_ = rhs.confPe_;
   this->confDt_ = rhs.confDt_;
}

bMC::~bMC() {
   if( this->perturbSchema_ != NULL ) {
      for( int i=0; i < this->numOpt_; ++i ) {
         if( this->perturbSchema_[i] != NULL ) {
            delete [] this->perturbSchema_[i];
            this->perturbSchema_[i] = NULL;
         }
      }
      delete [] this->perturbSchema_;
      this->perturbSchema_ = NULL;
   }
   this->confPe_.clear();
}

bool bMC::metropolis( bDelTess& dt ) {
   
   //~ deque<bDelTess> keepDt;
   //~ deque<bPoints> keepPe;
   //~ deque<bPoints> keepNb;
   //~ deque<ulong> keepId;
   
   float scoreToBeat = dt.score();
   
   this->pepLen_ = dt.src_[2]->size();

   // Find tessellations above the threshold   
   if( dt.score() < this->threshold_ ) { return false; }
   else {
      this->confDt_.push_back( dt );
      this->confPe_.push_back( *(dt.src_[2]) );
      this->confId_.push_back( this->savePepId( dt.src_[2] ) );
   }
   bHex::printHex( this->confId_.back() ); printf("\n");
   //~ exit(1);
   

   // Setup Perturb
   int min[3] = { -3, -3, -3 }, max[3] = { 3, 3, 3 };
   this->setupPerturb( min, max );

   //~ dt.src_[0]->print();
   //~ dt.src_[1]->print();
   //~ dt.src_[2]->print();
   
   // Randomly Perturb
   bPoints* dtsrc[2] = { dt.src_[1], NULL };
   printf("ready to perturb...\n");
   for( uint i=0; i < this->numIter_; ++i ) {
      //~ printf("iter %u\n", i);
      bPoints cp;
      bPoints nb;
      this->perturb( cp, *dt.src_[2] );
      ulong id = this->savePepId( &cp );
      if( id == 0 ) { --i; continue; }
      //~ cp.findNearbyPoints( *dt.src_[1], nb );
      //~ dtsrc[0]->print(); printf("\n");
      dtsrc[1] = &cp;
      //~ dtsrc[0] = &nb;
      
      //~ dtsrc[0]->print();
      //~ dtsrc[1]->print();
      bDelTess dtp;
      try {
         dtp.tessellateStd( dtsrc, 2, 2 );
      }
      catch( const char* e ) { printf("[bMC] %s\n",e); }
      if( scoreToBeat < dtp.score() ) {
         printf("o|n: %.2f | %.2f\n", scoreToBeat, dtp.score());
         //~ if( id != 0 ) {
            confId_.push_back( id );
            confDt_.push_back( dtp );
            confPe_.push_back( cp );
         //~ }
         //~ else { --i; }
      }
   }
   
      // Ensure perturbation is unique
   
      // Find Nearby
   
      // Check if nearby are different (i.e., can we use the same tessellation)
      // ==> test this extensively, might be a shortcut...might not
   
      // Tessellate & Score
   
      // Evaluate by Metropolis criterion
   
      // Save if valid
   confPe_.pop_front();
   confDt_.pop_front();
   //~ this->confPe_ = keepPe;
   //~ this->confDt_ = keepDt;
   
   return true;
}


ulong bMC::savePepId( const bPoints* pepSrc ) {
   //~ printf("here\n");
   float* pep = pepSrc->pnts_;
   int size = this->pepLen_; size *= 16;
   bHex xid( size );
   bHex yid( size );
   bHex zid( size );
   
   uint index = 0;
   ulong mask  = 0xFFFF;
   ulong coord = 0;
   uint slide = 0;
   for( uint i=0; i < this->pepLen_; ++i ) {
      coord = pep[index];
      //~ bHex::printHex( coord ); printf(": %lu\n",coord);
      coord &= mask;
      //~ bHex::printHex( coord ); printf(": %lu\n",coord);
      xid.assign( coord, slide );
      ++index;
      
      coord = pep[index];
      coord &= mask;
      yid.assign( coord, slide );
      ++index;

      coord = pep[index];
      coord &= mask;
      zid.assign( coord, slide );
      ++index;
      slide += 16;
   }

   // Verify unique
   

   bool xu = true, yu = true, zu = true;
   ulong dtid = 0;
   ulong i = 0, s = xId_.size();
   while( i < s && xid != xId_[i] ) { ++i; }
   if( i == s ) { xId_.push_back( xid ); }
   //~ else { xu = false; }
//~ printf("i: %u\n",i);
   //~ if( xId_[i] == xid ) { xId_[i].printHex(); xid.printHex(); }
   i &= 0xFFFFF; dtid = i;
   //~ bHex::printHex( dtid ); printf(": %lu\n",dtid);
   
   i = 0; s = yId_.size();
   while( i < s && yid != yId_[i] ) { ++i; }
   if( i == s ) { yId_.push_back( yid ); }
   //~ else { yu = false; }
//~ printf("i: %u\n",i);
   i &= 0xFFFFF; i <<= 20; dtid |= i;
   //~ bHex::printHex( dtid ); printf(": %lu\n",dtid);
   
   i = 0; s = zId_.size();
   while( i < s && zid != zId_[i] ) { ++i; }
   if( i == s ) { zId_.push_back( zid ); }
   //~ else { zu = false; }
//~ printf("i: %u\n",i);
   i &= 0xFFFFF; i <<= 40; dtid |= i;
   //~ bHex::printHex( dtid ); printf(": %lu\n",dtid);
   
   for( i = 0; i < this->confId_.size(); ++i ) {
      if( dtid == this->confId_[i] ) {
         //~ pepSrc->print();
         //~ xid.printHex();
         //~ yid.printHex();
         //~ zid.printHex();
         //~ bHex::printHex( dtid ); printf("\n");
         //~ bHex::printHex( this->confId_[i] ); printf("\n");
         
         dtid = 0; break;
      }
   }
   //~ if( !xu && !yu && !zu ) { dtid = 0; }

   
   //~ exit(1);
   return dtid;
}

void bMC::setupPerturb( const int min[3], const int max[3] ) {
   int range[3] = { max[0] - min[0], max[1] - min[1], max[2] - min[2] };
   ++range[0]; ++range[1]; ++range[2];
   
   this->numOpt_ = range[0]; this->numOpt_ *= range[1]; this->numOpt_ *= range[2]; --this->numOpt_;
   
   this->perturbSchema_ = new int* [this->numOpt_];
   int x = 0;
   for( int i=min[0]; i <= max[0]; ++i ) {
      for( int k=min[1]; k <= max[1]; ++k ) {
         for( int m=min[2]; m <= max[2]; ++m ) {
            this->perturbSchema_[x] = new int [3];
            this->perturbSchema_[x][0] = i;
            this->perturbSchema_[x][1] = k;
            this->perturbSchema_[x][2] = m;
            ++x;
         }
      }
   }
   //~ printf("seg: %d : %d\n",x,numOpt_);
   
   this->perturbRangeMin_[0] = min[0]; this->perturbRangeMin_[1] = min[1]; this->perturbRangeMin_[2] = min[2];
   this->perturbRangeMax_[0] = max[0]; this->perturbRangeMax_[1] = max[1]; this->perturbRangeMax_[2] = max[2];
   this->numOpt_ = x;
   this->havePerturbSchema_ = true;
   return;
}

void bMC::perturb( bPoints &mod, const bPoints &old ) {
   if( !this->havePerturbSchema_ ) { this->setupPerturb( this->perturbRangeMin_, this->perturbRangeMax_); }
   
   mod = old;
   
   float ptrb[3] = { 0.0, 0.0, 0.0 };
   int whichPnt = 0;
   int whichPtb = 0;
   do {
      whichPnt = bCalc::getRandomNumber( mod.numPnts_ );
      whichPtb = bCalc::getRandomNumber( this->numOpt_ );
      
      whichPnt *= 3;
      ptrb[0] = mod.pnts_[whichPnt]; ++whichPnt;
      ptrb[1] = mod.pnts_[whichPnt]; ++whichPnt;
      ptrb[2] = mod.pnts_[whichPnt];
      
      ptrb[0] += this->perturbSchema_[ whichPtb ][0];
      ptrb[1] += this->perturbSchema_[ whichPtb ][1];
      ptrb[2] += this->perturbSchema_[ whichPtb ][2];
      
   } while( !this->grd_->isaGridPoint( ptrb ) );

   mod.pnts_[whichPnt] = ptrb[2]; --whichPnt;
   mod.pnts_[whichPnt] = ptrb[1]; --whichPnt;
   mod.pnts_[whichPnt] = ptrb[0];
   whichPnt /= 3;
   //~ printf("perturb: %d | %d [ %d, %d, %d ]\n",whichPnt, whichPtb, perturbSchema_[ whichPtb ][0], perturbSchema_[ whichPtb ][1], perturbSchema_[ whichPtb ][2] );
   //~ printf("num: %d\n",mod.numPnts_);

   //~ old.print();
   //~ mod.print();
   return;
}

void bMC::pymol( FILE* op, char name[], char color[] ) {
   char nameFull[32];
   char scr[7];
   memset( nameFull, '\0', 32 );
   for( uint i=0; i < this->confPe_.size(); ++i ) {
      sprintf( nameFull, "%s_conf%02d", name, i );
      sprintf( scr, "%.2f", this->confDt_[i].score() );
      this->confPe_[i].setToNormalSpace();
      this->confPe_[i].pymolConnectedPseudoatoms( op, nameFull, color, 1, scr );
      sprintf( nameFull, "%s_dt", nameFull );
      //~ this->confDt_[i].pymolDelTess( op, nameFull, color );
   }
}

/******************************************************* bMC_MetTable */

bMC_MetTable::bMC_MetTable() :
   delt_(NULL), prob_(NULL)
{}

bMC_MetTable::~bMC_MetTable() {
   if( this->delt_ != NULL ) { delete [] this->delt_; this->delt_ = NULL; }
   if( this->prob_ != NULL ) { delete [] this->prob_; this->prob_ = NULL; }
}

float bMC_MetTable::operator[]( float find ) {
   if( this->delt_ == NULL || this->prob_ == NULL ) { throw "[bMC::MT] Please identify a Metropolis table"; }
   
   ushort end = this->size_;
   ushort med = end; med >>= 1;
   ushort beg = 0;
   
   ushort at = end;
   bool found = false;
   
   for( uint i=0; i < 4 && (beg != med || end != med); ++i ) {
      if( this->delt_[med] > find ) {
         beg = med; med >>= 1; med += beg;
      }
      else if( this->delt_[med] < find ) {
         end = med; med >>= 1;
      }
      else { at = med; i = 2; found = true;}
   }
   
   for( ushort i=beg; i < end && !found; ++i ) { if( find <= this->delt_[i] ) { at = i; found = true; } }
   //~ if( at > 0 ) { --at; }
   return this->prob_[at];
}

void bMC_MetTable::read( char file[] ) {
   // open the file
   ifstream ip;
   ip.open(file, ifstream::in);
   if(!ip) { return; }

   // Read in data
   deque<string> data;
   string bffr;
   uint i = 0;
   for( i = 0; getline( ip, bffr ); ++i ) { data.push_back(bffr); }
   ip.close();

   // Resize data structures
   if( this->delt_ != NULL ) { delete [] this->delt_; this->delt_ = NULL; }
   if( this->prob_ != NULL ) { delete [] this->prob_; this->prob_ = NULL; }
   this->delt_ = new float[i];
   this->prob_ = new float[i];

   // loop through each line and save the coordinates
   for( i = 0; i < data.size(); ++i ) {
      istringstream ss(data[i]);
      ss >> this->delt_[i];
      ss >> this->prob_[i];
   }
   return;
}