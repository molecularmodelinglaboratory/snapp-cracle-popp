#include <deque>
#include <fstream>
#include <sstream>
#include <string>
#include <string.h>
#include <stdio.h>
#include "bCentroid.h"
using namespace std;
using namespace bStd;

bCentroid::bCentroid() {
   
}
bCentroid::bCentroid( char base[], char path[] ) {
   strcpy( this->fileBase_, base );
   strcpy( this->filePath_, path );
}
bCentroid::bCentroid( const bCentroid &rhs ) {
   
}

bCentroid::~bCentroid() {
   
}

void bCentroid::setSrc( char base[], char path[] ) {
   strcpy( this->fileBase_, base );
   strcpy( this->filePath_, path );
   return;
}

bool bCentroid::pdb2Centroids() { return pdb2Centroids( this->fileBase_, this->filePath_ ); }
bool bCentroid::pdb2Centroids( char fileBase[], char filePath[] ) {
   
   // Open the file
   ifstream ip;
   char* file = new char[96];
   strcpy( file, filePath );
   strcat( file, fileBase );
   if( memcmp( file + strlen(file) - 4, ".pdb", 4 ) != 0 ) strcat( file, ".pdb" );
   ip.open(file, ifstream::in);
   //~ printf("file: %s\n", file);
   if(!ip) { throw "[bCentroid] Bad file."; return false; }

   // Storage
   deque<float>  centroids;
   deque<string> residues;
   deque<uint>   posResidues;
   deque<uint>   chainLoc;
   string bffr;

   // Read (in order)
   string type;
   int    posAtom;
   string atom;
   string res;
   char   chain;
   int    posRes;
   float  coord[3] = { 0.0, 0.0, 0.0 };

   // Data handling
   float  centr[3] = { 0.0, 0.0, 0.0 };
   int    prevPos = 0;
   bool   prevCa = false;
   bool   prevCCarbonyl = false;
   int    cntAtom = 0;
   //~ int    cntRes = 0;
   char   currChain = '0';

   // Line by line
   for( uint i = 0; getline( ip, bffr ); ++i ) { 
      istringstream ss( bffr );
      
      // Skip unless it's an atom
      ss >> type;
      if( type.compare("ATOM") ) { continue; }
      //~ printf("line: %s\n", bffr.c_str());
      
      // Read up to coordinates
      ss >> posAtom;
      ss >> atom;
      ss >> res;
      ss >> chain;
      ss >> posRes;
      
      //~ printf("%s ", type.c_str());
      //~ printf("%d ", posAtom);
      //~ printf("%s ", atom.c_str());
      //~ printf("%s ", res.c_str());
      //~ printf("%c ", chain);
      //~ printf("%d ", posRes);
      
      // Check for backbone N (new residue, handle at Ca)
      if( !atom.compare("N") && posRes != prevPos ) {
         prevPos = posRes;
         //~ printf("\t\tNITROGEN!\n");
         continue;
      }

      // Check for C-alpha (new residue!)
      else if( !atom.compare("Ca") || !atom.compare("CA") ) {
         //~ printf("\t\tALPHA CARBON!");

         // Check for new chain
         if( chain != currChain ) {
            chainLoc.push_back( residues.size() );
         }
         
         // Save the residue
         residues.push_back( res );
         posResidues.push_back( posRes );
         prevCa = true;
         
         if( cntAtom != 0 ) {
            // Calculate the centroid, save, & reset
            centr[0] /= cntAtom;
            centr[1] /= cntAtom;
            centr[2] /= cntAtom;
            centroids.push_back( centr[0] );
            centroids.push_back( centr[1] );
            centroids.push_back( centr[2] );
            centr[0] = 0.0;
            centr[1] = 0.0;
            centr[2] = 0.0;
            cntAtom = 0;
         }
      }

      // Check for backbone C
      else if( !atom.compare("C") && prevCa ) {
         prevCa = false;
         prevCCarbonyl = true;
         //~ printf("\t\tCARBONYL!\n");
         continue;
      }

      // Check for backbone C
      else if( !atom.compare("O") && prevCCarbonyl ) {
         prevCCarbonyl = false;
         //~ printf("\t\tCARBONYL!\n");
         continue;
      }

      // Ignore extra carboxylate atom
      else if( !atom.compare("OXT") ) {
         continue;
      }

      else {}
      //~ printf("\n");

      // Weight
      float weight = 1.0;
         
      //~ found = atom.find("C");
      //~ printf("%s: C %lu\n",atom.c_str(), found);
      //~ if( atom.find("C") != string::npos ) { weight = 12.0; }
      //~ else if( atom.find("N") != string::npos ) { weight = 14.0; }
      //~ else if( atom.find("O") != string::npos ) { weight = 16.0; }
      //~ else if( atom.find("S") != string::npos ) { weight = 32.0; }
      //~ else {}

      // Save the coordinates
      cntAtom += weight;
      ss >> coord[0];
      ss >> coord[1];
      ss >> coord[2];
      coord[0] *= weight;
      coord[1] *= weight;
      coord[2] *= weight;
         
      //~ printf("%.2f, %2.f, %.2f\t%d\n", coord[0], coord[1], coord[2], weight );
      centr[0] += coord[0];
      centr[1] += coord[1];
      centr[2] += coord[2];
      
   }
   ip.close();
   
   // Save last centroid
   //~ residues.push_back( res );
   //~ posResidues.push_back( posRes );
   prevCa = true;
   
   if( cntAtom != 0 ) {
      // Calculate the centroid, save, & reset
      centr[0] /= cntAtom;
      centr[1] /= cntAtom;
      centr[2] /= cntAtom;
      centroids.push_back( centr[0] );
      centroids.push_back( centr[1] );
      centroids.push_back( centr[2] );
   }

   // Print centroids
   bool haveCent = centroids.size() > 0 ? true : false;
   if( haveCent ) {
      int size = strlen(file);
      //~ printf("file: %s\n", file);
      //~ memset( file + size - 4, '\0', 4 );
      //~ printf("file: %s\n", file);
      //~ char fout[96];
      //~ memset( fout, '\0', 96 );
      //~ printf("file: %s\n", fout);
      //~ memmove( fout, file, size );
      //~ printf("file: %s\n", fout);
      //~ memmove( fout + size - 4, ".out", 4 );
      //~ printf("file: %s\n", fout);
      memmove( file + size - 4, ".out", 4 );
      //~ strcpy( file, filePath );
      //~ strcat( file, fileBase );
      //~ strcat( file, ".out" );
      printf("file: %s\n", file);
      FILE* op = fopen( file, "w" );
      for( uint i=0; i < centroids.size(); ++i ) {
         fprintf( op, "%.3f ", centroids[i] );
         ++i; fprintf( op, "%.3f ", centroids[i] );
         ++i; fprintf( op, "%.3f\n", centroids[i] );
      }
      fclose( op );
      
      // Print sequence
      //~ strcpy( file, filePath );
      //~ strcat( file, fileBase );
      memmove( file + size - 4, ".seq", 4 );
      printf("file: %s\n", file);
      //~ strcat( file, ".seq.test" );
      //~ printf("size: %lu\n", residues.size());
      op = fopen( file, "w" );
      for( uint i=0; i < residues.size(); ++i ) {
         //~ printf("%s %d\n", residues[i].c_str(), posResidues[i] );
         fprintf( op, "%s %d\n", residues[i].c_str(), posResidues[i] );
      }
      fclose( op );
   }
            //~ printf("here\n");

   delete [] file;
   file = NULL;
   return haveCent;
}

void bCentroid::dt2Centroids( bDelTess &dt ) { dt2Centroids( this->fileBase_, this->filePath_, dt ); return; }
void bCentroid::dt2Centroids( char base[], char path[], bDelTess &dt ) {
   
   deque<float> centroids;
   float centroid[3] = { 0.0, 0.0, 0.0 };
   for( uint i=0; i < dt.simplex_.size(); ++i ) {
      if( dt.skip( i ) ) { continue; }
      
      centroid[0] = dt.simplex_[i].vrtx_[1];
      centroid[0] += dt.simplex_[i].vrtx_[6];
      centroid[0] += dt.simplex_[i].vrtx_[11];
      centroid[0] += dt.simplex_[i].vrtx_[16];
      
      centroid[1] = dt.simplex_[i].vrtx_[2];
      centroid[1] += dt.simplex_[i].vrtx_[7];
      centroid[1] += dt.simplex_[i].vrtx_[12];
      centroid[1] += dt.simplex_[i].vrtx_[17];
      
      centroid[2] = dt.simplex_[i].vrtx_[3];
      centroid[2] += dt.simplex_[i].vrtx_[8];
      centroid[2] += dt.simplex_[i].vrtx_[13];
      centroid[2] += dt.simplex_[i].vrtx_[18];
      
      centroid[0] /= 4;
      centroid[1] /= 4;
      centroid[2] /= 4;
      
      centroids.push_back( centroid[0] );
      centroids.push_back( centroid[1] );
      centroids.push_back( centroid[2] );
   }
   
   // Print centroids
   char file[64];
   strcpy( file, path );
   strcat( file, base );
   strcat( file, "_CENTROIDS.out.test" );
   FILE* op = fopen( file, "w" );
   for( uint i=0; i < centroids.size(); ++i ) {
      fprintf( op, "%.4f ", centroids[i] );
      ++i; fprintf( op, "%.4f ", centroids[i] );
      ++i; fprintf( op, "%.4f\n", centroids[i] );
   }
   fclose( op );
   
   return;
}
