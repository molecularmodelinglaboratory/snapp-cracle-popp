#include <iostream>
#include <fstream>
#include <cmath>
#include <valarray>
#include <string>
#include <sstream>
#include "bGrid.h"
#include <iomanip>
#include <string.h>
using namespace std;

/* Templates */
template< typename T, std::size_t N > inline
std::size_t size( T(&)[N] ) { return N ; }

/*
   Constructors and Destructors
*/
bGrid::bGrid() : residueCount_(0), res_(1), fit_(4), thk_(1) {
   for(unsigned int i = 0; i < size(min_); ++i) {
      min_[i] = 1000.0;
      max_[i] = -1000.0;
   }
}
bGrid::~bGrid() {}

/*
   Read in Protein from File
*/
void bGrid::readProtein(char *file) {
   printf("File: %s\n",file);

   ifstream ip;
	ip.open(file, ifstream::in);
	saveFilename(file);

   // read in the file... not the most efficient, bleh
   vector<string> data;
   string bffr;
   for(int i = 0; getline(ip,bffr); ++i) {
      data.push_back(bffr);
      ++residueCount_;
   }
	ip.close();

   cout << "count: " << residueCount_ << endl;

   // resize the array and prepare the stream
   // -- this is an unfortunate side effect of using the valarray
   // => it clears everything upon resize =/
   this->prt_.resize(residueCount_*3);

   // loop through each line and save the coordinates
   for(unsigned int i = 0; i < data.size(); ++i) {
      istringstream ss(data[i]);
      float flt;

      for(int j = 0; ss >> flt; ++j) {
         prt_[(i*3) + j] = flt;

         // check for min | max
         if(flt  < min_[j]) {
            //cout << "old: " << min_[j] << "\t" << j << endl;
            min_[j] = flt;
            //cout << "MIN: " << min_[j] << endl << endl;
         }
         else if(flt  > max_[j]) {
            //cout << "old: " << max_[j] << "\t" << j << endl;
            max_[j] = flt;
            //cout << "MAX: " << max_[j] << endl << endl;
         }
         else{}
      }
   }

	//~ // Testing Max and Min
	//~ cout << "\nStarting elements\n";
	//~ for(int i=0; i < 3; ++i) {
		//~ cout << min_[i] << " : ";
		//~ cout << max_[i] << " : ";
		//~ cout << max_[i] - min_[i] << endl;
	//~ }

}

/*
   Recenter protein completely within positive boundaries
*/
void bGrid::translateProtein() {

   // create slices
   slice xs = slice(0,residueCount_,3);
   slice ys = slice(1,residueCount_,3);
   slice zs = slice(2,residueCount_,3);

   //~ float xmin = (valarray<float>(prt_[xs])).min();
   //~ float ymin = (valarray<float>(prt_[ys])).min();
   //~ float zmin = (valarray<float>(prt_[zs])).min();

	//~ cout << "compare: " << xmin << " : " << min_[0] << endl;
	//~ cout << "compare: " << ymin << " : " << min_[1] << endl;
	//~ cout << "compare: " << zmin << " : " << min_[2] << endl;

   float layer = fit_ + thk_;
   float a[3] = {
      min_[0] - layer,
      min_[1] - layer,
      min_[2] - layer,
   };

   // adjust
   prt_[xs] = valarray<float>(prt_[xs]) - a[0];
   prt_[ys] = valarray<float>(prt_[ys]) - a[1];
   prt_[zs] = valarray<float>(prt_[zs]) - a[2];

   //cout << "x: " << x.min() << "\tM: " << x.max() << "\t" << x.max() - x.min() << endl;
   //cout << "y: " << y.min() << "\tM: " << y.max() << "\t" << y.max() - y.min() << endl;
   //cout << "z: " << z.min() << "\tM: " << z.max() << "\t" << z.max() - z.min() << endl;
}


/*
   Print protein points
*/
void bGrid::printProtein() { this->printProtein(std::cout); }
void bGrid::printProtein(ostream &out) {
   for(int i = 0; i < residueCount_; ++i) {
      out << "[" << i << "]\t";
      for(unsigned int j = 0; j < prt_.size() / residueCount_; ++j) {
         int index = (i*3)+j;
         out << "(" << j << ":" << index << ") " << prt_[index] << "\t";
      }
      out << endl;
   }
}

/*
   Initialize Grid
*/
void bGrid::initializeGrid() {
   // create slices
   slice xs = slice(0,residueCount_,3);
   slice ys = slice(1,residueCount_,3);
   slice zs = slice(2,residueCount_,3);

	// note: there was somoething weird going on when using the
	//   float min_ and max_. This was due to very tiny numbers
	//   from dividing the protein points by the resolution
	//   (i.e. the points don't fit exactly on the grid)
	// To adjust this, we use ints to declare the grid to auto-
	// matically get the floor (i.e. round down to closest res)
	// Since the threshold is large enough...hopefully won't
	// be a problem. If so, we can just add one to the max --
	// this will put it in the right frame.

   // find min
   int min[3] ={ (valarray<float>(prt_[xs])).min(),
      (valarray<float>(prt_[ys])).min(),
      (valarray<float>(prt_[zs])).min()
   };

   // find max
   int max[3] ={ (valarray<float>(prt_[xs])).max(),
      (valarray<float>(prt_[ys])).max(),
      (valarray<float>(prt_[zs])).max()
   };

   // add buffer zone
   int buffer = (fit_ + thk_);
   for(int i=0; i < 3; ++i) {
      min_[i] = min[i] - buffer;
      max_[i] = max[i] + buffer;
	}
	
	if(max_[2]/res_ > 63) {
		cout << "Insufficient memory for requested resolution." << endl;
		exit(1);
	}
	
   // initialize grid
	// -- the min should be 0 on all accounts
	// -- add 1 since max is the last index, not the size
   grd_.resize( (max_[0] - min_[0] + 1) * (max_[1] - min_[1] + 1) / res_, 0x0);
   tmp_.resize( (max_[0] - min_[0] + 1) * (max_[1] - min_[1] + 1) / res_, 0x0);

	//~ // Testing Max and Min
	//~ cout << "\nEnding elements\n";
	//~ for(int i=0; i < 3; ++i) {
		//~ cout << min_[i] << " : ";
		//~ cout << max_[i] << " : ";
		//~ cout << max_[i] - min_[i] << endl;
	//~ }

	//~ // Tests for range of protein
	//~ for(int i=0; i < prt_.size()/3; ++i) {
		//~ float x = valarray<float>(prt_[xs])[i];
		//~ float y = valarray<float>(prt_[ys])[i];
		//~ float z = valarray<float>(prt_[zs])[i];

		//~ cout << x << " : ";
		//~ cout << y << " : ";
		//~ cout << z << " : ";

		//~ if( (x < (min_[0]+10)) || (y < (min_[1]+10)) || (z < (min_[2]+10)) ) {
			//~ cout << "Less than!!";
		//~ }

		//~ if( (z > (max_[2]-10)) || (y > (max_[1]-10)) || (x > (max_[0]-10)) ) {
			//~ cout << "More than!!";
		//~ }

		//~ cout << endl;
	//~ }

}



/*
   Initialize Exclusion Matrix
*/
void bGrid::initializeExclusion() {
   // calculate number of points across the exclusion
	int radius = (fit_ / res_);
	
	this->initializeStamp(radius,exc_,exsl_);
	return;
	
	// These are the old indexes -- made for mapping to an exclusion box
	//~ exsl_[index][slc] = (i+1) + (k*diamet) + k*max_[1];
	//~ exsl_[index][++slc] = (k+1) * diamet - i + k*max_[1];
	//~ exsl_[index][++slc] = (i*diamet) + (k +1) + k*max_[1];
	//~ exsl_[index][++slc] = (i+1) * diamet - k + k*max_[1];
	//~ exsl_[index][++slc] = (diamet - (i+1)) * diamet + (1+k) + k*max_[1];
	//~ exsl_[index][++slc] = (diamet-i) * diamet - k + k*max_[0 ];
	//~ exsl_[index][++slc] = diamet*(diamet-1) + i + 1 - (k*diamet) + k*max_[0];
	//~ exsl_[index][++slc] = (diamet-k) * diamet - i + k*max_[0];
	//~ exsl -=1;
}
void bGrid::initializeInclusion() {
   // calculate number of points across the exclusion
	int radius = ((thk_ + fit_) / res_);
	
	this->initializeStamp(radius,inc_,insl_);
	return;
}

/*
   Initialize Stamp
*/
void bGrid::initializeStamp(int radius, std::valarray<unsigned long long> &stamp, std::vector< valarray<size_t> > &stampSlice) {
	// calculate number of points across the exclusion
	// radius from calling function: int radius = (fit_ / res_);
   int diamet = 2 * radius;

	// initialize bins
	int binCnt = 0;
	for(int i = 0; i <= (radius); ++i) {
		binCnt += i;
	}

	// resize! (and fill in with ones)
   stamp.resize(binCnt, 0);//(pow(2,diamet) - 1));
	stampSlice.resize(binCnt);

	// loop through each outer layer of the grid
	int index = 0;
	for(int k = 0; k < (radius); ++k) {

		// loop through each unique position on the outer layer
		for(int i = k; i < (radius); ++i) {

			// initialize the valarray
			stampSlice[index].resize(8);
			int slc = 0;

			// calculate each of the eight points
			// note: these are mapped to the grid, not to the small box of the
			// exclusion. MEANING: we only need to add the x dimension (usually i
			// in our implementation) to the indirect arrays to get the
			// appropriate index on the grid.
			int n = max_[0];
			int p = 2*radius - 1;
			stampSlice[index][slc] = i + (k*n);
			stampSlice[index][++slc] = (p-i) + (k*n);
			stampSlice[index][++slc] = (i*n) + k;
			stampSlice[index][++slc] = (i*n) + (p-k);
			stampSlice[index][++slc] = (p-i)*n + k;
			stampSlice[index][++slc] = (p-i)*n + (p-k);
			stampSlice[index][++slc] = (p-k)*n + i;
			stampSlice[index][++slc] = (p-k)*n + (p-i);

			++index;
		}
	}

	// setup the middle point
	valarray<float> mid( (((float)diamet -1)/2) , 3);
	
	// go through each point in the exclusion matrix...for the unique bins
	index = 0;
	float scaledLength = radius - res_;
	for(int k = 0; k < radius; ++k) {
		for(int i = k; i < radius; ++i) {
			for(int z = 0; z < radius; ++z) {
				// create temp valarray for the point
				float tmp[] = {(float)k, (float)i, (float)z};
				valarray<float> gpt(tmp,3);

				// check the distance
				if(pointDistance(mid,gpt) < scaledLength) {
					stamp[index] |= (unsigned long long)pow(2.0,z);
					stamp[index] |= (unsigned long long)pow(2.0,(diamet-1-z));
				}
			}
			++index;
		}
	}
}

float bGrid::pointDistance(valarray<float> &a, valarray<float> &b) {

	//~ for(int i = 0; i < 3; ++i)
		//~ cout << "\t" << a[i];
	//~ cout << endl;
	//~ for(int i = 0; i < 3; ++i)
		//~ cout << "\t" << b[i];
	//~ cout << endl;

	valarray<float> c = a-b;
	c *= c;
	//~ for(int i = 0; i < 3; ++i)
		//~ cout << "\t" << c[i];
	//~ cout << endl << sqrt( c.sum() ) << endl << endl;

	return sqrt( c.sum() );
}

void bGrid::excludePoints() {
	// Correction from middle of box to center
   int correction = (fit_/res_) - 1;
	this->stampPoints(correction,exc_,exsl_,grd_);
	return;
}

void bGrid::includePoints() {
	// Correction from middle of box to center
   int correction = ((thk_ + fit_)/res_) - 1;
	cout << correction << endl;
	this->stampPoints(correction,inc_,insl_,tmp_);
	
	// Reconcile the inclusion and exclusion
	grd_ = grd_ ^ tmp_;

	return;

	// Proof that temp DOES contain valid points
	//~ for(int k=0; k<=max_[1]; ++k) {
		//~ for(int i=0; i<=max_[0]; ++i) {
			//~ int index = k*max_[0] + i;
			//~ for(int z=0; z<=max_[2]; ++z) {
				//~ bool t =  tmp_[index] & (unsigned long long)pow(2.0,z);
				//~ cout << t << " ";
			//~ }
			//~ cout << endl;
		//~ }
		//~ cout << endl;
	//~ }
	
	return;
}

void bGrid::stampPoints(int correction, std::valarray<unsigned long long> &stamp, std::vector< valarray<size_t> > &stampSlice, std::valarray<unsigned long long> &paper) {

	// Corection: given from calling function
   //~ int correction = (fit_/res_) - 1;

	// displacement and depth of exclusion grid
	int position = 0;
	unsigned long long depth = 0;

	// Resize the protein to the proper resolution
	// -- we initialized the grid to the resolution
	prt_ /= res_;

	// shift point from the center box to the corner
	prt_ -=  correction;

	// create slices
   slice xs = slice(0,residueCount_,3);
   slice ys = slice(1,residueCount_,3);
   slice zs = slice(2,residueCount_,3);

	// Loop through protein points
	for(unsigned int i=0; i<prt_.size()/3; ++i) { // 1;++i) { //

		// a little ugly due to valarray implementation
		int index = i*3;
		int x = prt_[index];
		int y = prt_[++index];
		int z= prt_[++index];

		// correct according to previous displacement
		int displacement = position;
		position = (y*(max_[0]) + x);
		displacement = position - displacement;

      int perspective = depth;
		depth = z;
		perspective = depth - perspective;

		// Loop through exclusion slice, displace each, and EXCLUDE
		// -- might it be faster to simply multiply rather than test?
		for(int g=0; g<stamp.size(); ++g) {

			stampSlice[g] += displacement;
         stamp[g] *= pow(2.0,perspective);
			
			//~ cout << i << ":";
			//~ cout << g << " :: ";
			//~ cout << stamp[g] << "\t";
			
			// EXCLUDE POINTS!!
			paper[stampSlice[g]] = stamp[g] | valarray<unsigned long long>(paper[stampSlice[g]]);

		}  // end loop through exclusion space
		
		cout << endl;

	} // end loop through points

	// Reset protein to original location
	prt_ +=  correction;
	prt_ *= res_;

}

/*
	Print Grid

	Major problem with the exclusion -- we only have a small slice!
	Use the slices we made to map it to a new valarray
*/
void bGrid::print3dExcl(ostream &out) {
	int length = 2*(fit_/res_);
	valarray<unsigned long long> toPrnt(length*length);
	for(unsigned int i=0; i < exc_.size(); ++i) {
		toPrnt[exsl_[i]] = exc_[i];
		//out << exc_[i] << endl;
	}

	//~ for(unsigned int i=0; i<toPrnt.size(); ++i) {
		//~ cout << i << ":" << toPrnt[i] << endl;
	//~ }

	print3dGrid(out, toPrnt, length, length);
}
void bGrid::print3dIncl(ostream &out) {
	int length = 2*((thk_+fit_)/res_);
	cout << length << endl;
	valarray<unsigned long long> toPrnt(length*length);
	for(unsigned int i=0; i < inc_.size(); ++i) {
		toPrnt[insl_[i]] = inc_[i];
		//out << exc_[i] << endl;
	}

	//~ for(unsigned int i=0; i<toPrnt.size(); ++i) {
		//~ cout << i << ":" << toPrnt[i] << endl;
	//~ }

	print3dGrid(out, toPrnt, length, length);
}

void bGrid::print3dGrid(ostream &out, valarray<unsigned long long> &grid, int x) { this->print3dGrid(out,grid,x,x); }
void bGrid::print3dGrid(ostream &out, valarray<unsigned long long> &grid, int x, int d) {
	for(unsigned int k=0; k < (grid.size()/x); ++k) {
		for(int i=0; i < x; ++i) {

			//~ out << k << ":";
			//~ out << i << ":";
			//~ out << grid[k*x+i] << ":";

			for(int z = 0; z < d; ++z) {
				unsigned long long a = pow(2.0,z);
				//int q = k*x+i;
				//int p = a & grid[q];
				//cout << q << "\t" << p << ":" << a << "\t "<< grid[q] << endl;

				//~ cout << k << ":";
				//~ cout << i << ":";
				//~ cout << z << ":";
				//~ cout << (p>0) << "\t";

				switch(a & grid[k*x + i]) {
					case 0:	out << " " << 0;
						break;
					default: out << " " << 1;
						break;
				}
			}
			cout << endl;
		}
		cout << endl;
	}
}

void bGrid::printSingleHex(ostream &out,unsigned long long &one,int z) {
	for(int i=0; i<z; ++i) {
		unsigned long long a = pow(2.0,i);
		//~ out << a << " : ";
		//~ out << i << " : ";

		if(a & one) {
			out << 1;
		}
		else {
			out << 0;
		}
	}
	out << endl;
}

/*
	Create PyMol Python Script
*/
void bGrid::printPyMol() {

	// creat the filename
	strcat(prtFile_,"_grid.py");
	cout << "Writing to: " << prtFile_ << endl;

	// open the file and check
	FILE *op = fopen(prtFile_, "w");
	if(!op) {
		cout << prtFile_ << " did not open!\n" << endl;
	}


	// Write header
	fprintf(op,"from pymol import cmd\n");
	fprintf(op,"\n");
	fprintf(op,"cmd.hide(\"everything\")\n");
	fprintf(op,"cmd.show(\"cartoon\")\n");
	fprintf(op,"cmd.set('transparency','0.3')\n");
	fprintf(op,"from pymol.cgo import *\n");
	fprintf(op,"from pymol import cmd\n");
	fprintf(op,"\n");

	
		
	// Write temp points
	//~ fprintf(op,"temp = [\n");
	//~ fprintf(op,"\tCOLOR, 0.0, 0.0, 1.0,\n");
	//~ for(int k=0; k<=max_[1]; ++k) {
		//~ for(int i=0; i<=max_[0]; ++i) {
			//~ int index = k*max_[0] + i;
			//~ for(int z=0; z<=max_[2]; ++z) {
				//~ if((tmp_[index] & (unsigned long long)pow(2.0,z))) {
					//~ fprintf(op,"\tSPHERE, %d, %d, %d, %.2f,\n",
						//~ i, k, z, 0.1);
				//~ }
			//~ }
		//~ }
	//~ }
	//~ fprintf(op,"\t]\n");
	//~ fprintf(op,"cmd.load_cgo(temp,'tmp')\n\n");
	
   // Write origin
	fprintf(op,"origin = [\n");
	fprintf(op,"\tCOLOR, 0.0, 1.0, 0.0,\n");
	fprintf(op,"\tSPHERE, %.2f, %.2f, %.2f, %.2f,\n",0.0,0.0,0.0, 1.0);
	fprintf(op,"\tSPHERE, %.2f, %.2f, %.2f, %.2f,\n",0.0,max_[1],0.0, 0.5);
	fprintf(op,"\tSPHERE, %.2f, %.2f, %.2f, %.2f,\n",max_[0],0.0,0.0, 0.5);
	fprintf(op,"\tSPHERE, %.2f, %.2f, %.2f, %.2f,\n",max_[0],max_[1],0.0, 0.5);
	fprintf(op,"\t]\n");
	fprintf(op,"cmd.load_cgo(origin,'origin')\n");

	// Write protein points
	fprintf(op,"protein = [\n");
	fprintf(op,"\tCOLOR, 1.0, 0.0, 0.0,\n");
	for(int i=0; i<prt_.size()/3; ++i) {
		int index = i*3;
		fprintf(op,"\tSPHERE, %.2f, %.2f, %.2f, %.2f,\n",
			prt_[index], prt_[index+1], prt_[index+2], 0.2);
	}
	fprintf(op,"\t]\n");
	fprintf(op,"cmd.load_cgo(protein,'protein')\n");

	// Adjust grid points from resolution to angstroms
	// Wait...bad idea...good chance we've already
	// filled up all available bits...
	//	-- better do this individually =/
	//		grd_ *= res_;

	// Write grid points
	fprintf(op,"grid = [\n");
	fprintf(op,"\tCOLOR, 0.0, 0.0, 1.0,\n");
	for(int k=0; k<=max_[1]; ++k) {
		for(int i=0; i<=max_[0]; ++i) {
			int index = k*max_[0] + i;
			for(int z=0; z<=max_[2]; ++z) {
				if((grd_[index] & (unsigned long long)pow(2.0,z))) {
					fprintf(op,"\tSPHERE, %d, %d, %d, %.2f,\n",
						i, k, z, 0.1);
				}
			}
		}
	}
	fprintf(op,"\t]\n");
	fprintf(op,"cmd.load_cgo(grid,'grid')\n\n");




      // Attempts to speed things up
   ///fprintf(op,"cmd.set('orthoscopic','on')\n");
   //fprintf(op,"cmd.set('depth_cue','1')\n");
   //fprintf(op,"select cgo01, (all) and not ( (all) within 8 of cgo01) )");
   //fprintf(op,"hide everything, cgo01");
   //fprintf(op,"cmd.ray()");

	// Close the file handle
	fclose(op);

   // Run the command
   // ('cuz windows sucks...)
   //system("pymolwin -r \"D:\\My Dropbox\\grid\\1AWQ_alone_grid.py\"");
}

void bGrid::saveFilename(char* file) {
	prtFile_ = (char*)malloc(sizeof(char)*64);
	strncpy(prtFile_,file,strrchr(file,'.')-file);
	return;
}


